import 'package:flutter/material.dart';

String getDateTimeString(DateTime dateTime) {
  DateTime dateTimeSplit = DateTime.parse(dateTime.toString().split(' ')[0]);
  String dateTimeString = '';
  String month = '';
  String amPM = dateTime.hour > 12 ? 'PM' : 'AM';
  String minutes = dateTime.minute < 10 ? '0${dateTime.minute}' : '${dateTime.minute}';
  String hours = dateTime.hour == 0
      ? '12'
      : dateTime.hour % 12 < 10
          ? '0${dateTime.hour % 12}'
          : '${dateTime.hour % 12}';
  String time = '$hours:$minutes';
  DateTime now = DateTime.parse(DateTime.now().toString().split(' ')[0]);
  if (now.isAfter(dateTimeSplit)) {
    if (now.day - dateTime.day == 1) {
      dateTimeString = 'Yesterday';
    } else {
      switch (dateTime.month) {
        case 1:
          month = 'Jan';
          break;
        case 2:
          month = 'Feb';
          break;
        case 3:
          month = 'Mar';
          break;
        case 4:
          month = 'Apr';
          break;
        case 5:
          month = 'May';
          break;
        case 6:
          month = 'Jun';
          break;
        case 7:
          month = 'Jul';
          break;
        case 8:
          month = 'Aug';
          break;
        case 9:
          month = 'Sep';
          break;
        case 10:
          month = 'Oct';
          break;
        case 11:
          month = 'Nov';
          break;
        case 12:
          month = 'Dec';
          break;
      }
      dateTimeString = '$month ${dateTime.day} ${dateTime.year}';
    }
  }
  if (dateTimeString.isEmpty) {
    dateTimeString = '$time $amPM';
  }
  return dateTimeString;
}

String getBatchDate(DateTime date) {
  String month = '';
  switch (date.month) {
    case 1:
      month = 'Jan';
      break;
    case 2:
      month = 'Feb';
      break;
    case 3:
      month = 'Mar';
      break;
    case 4:
      month = 'Apr';
      break;
    case 5:
      month = 'May';
      break;
    case 6:
      month = 'Jun';
      break;
    case 7:
      month = 'Jul';
      break;
    case 8:
      month = 'Aug';
      break;
    case 9:
      month = 'Sep';
      break;
    case 10:
      month = 'Oct';
      break;
    case 11:
      month = 'Nov';
      break;
    case 12:
      month = 'Dec';
      break;
  }
  return '$month ${date.day} ${date.year}';
}

String getBatchEndingDate(DateTime date) {
  String month = '';
  DateTime endingDate = date.add(const Duration(days: 21));
  switch (endingDate.month) {
    case 1:
      month = 'January';
      break;
    case 2:
      month = 'February';
      break;
    case 3:
      month = 'March';
      break;
    case 4:
      month = 'April';
      break;
    case 5:
      month = 'May';
      break;
    case 6:
      month = 'June';
      break;
    case 7:
      month = 'July';
      break;
    case 8:
      month = 'August';
      break;
    case 9:
      month = 'September';
      break;
    case 10:
      month = 'October';
      break;
    case 11:
      month = 'November';
      break;
    case 12:
      month = 'December';
      break;
  }
  return '${endingDate.day} $month ${endingDate.year}';
}

String getAfter30Date(DateTime date) {
  String month = '';
  DateTime endingDate = date.add(const Duration(days: 51));
  switch (endingDate.month) {
    case 1:
      month = 'January';
      break;
    case 2:
      month = 'February';
      break;
    case 3:
      month = 'March';
      break;
    case 4:
      month = 'April';
      break;
    case 5:
      month = 'May';
      break;
    case 6:
      month = 'June';
      break;
    case 7:
      month = 'July';
      break;
    case 8:
      month = 'August';
      break;
    case 9:
      month = 'September';
      break;
    case 10:
      month = 'October';
      break;
    case 11:
      month = 'November';
      break;
    case 12:
      month = 'December';
      break;
  }
  return '${endingDate.day} $month ${endingDate.year}';
}

num getMetricBMI(num height, num weight) {
  return weight / ((height / 100) * (height / 100));
}

num getImperialBMI(num height, num weight) {
  return (weight * 703) / (height * height);
}

String getBMIResultString(num bmi) {
  if (bmi < 18.5) {
    return 'underweight';
  } else if (18.5 <= bmi && bmi <= 24.9) {
    return 'normal';
  } else if (25.0 <= bmi && bmi <= 29.9) {
    return 'Overweight';
  } else if (30.0 <= bmi && bmi <= 39.9) {
    return 'obese';
  } else if (bmi >= 40.0) {
    return 'morbidly_obese';
  } else {
    return '';
  }
}

Color getBMIResultColor(num bmi) {
  if (bmi < 18.5) {
    return Colors.blue;
  } else if (18.5 <= bmi && bmi <= 24.9) {
    return Colors.green;
  } else if (25.0 <= bmi && bmi <= 29.9) {
    return Colors.yellow;
  } else if (30.0 <= bmi && bmi <= 39.9) {
    return Colors.orange;
  } else if (bmi >= 40.0) {
    return Colors.red;
  } else {
    return Colors.black;
  }
}

String getDateString(DateTime dateTime, {bool withYear = true, bool fullMonth = false, bool withSuffix = false}) {
  // String dateTimeString;
  String month = '';
  switch (dateTime.month) {
    case 1:
      month = fullMonth ? 'January' : 'Jan';
      break;
    case 2:
      month = fullMonth ? 'February' : 'Feb';
      break;
    case 3:
      month = fullMonth ? 'March' : 'Mar';
      break;
    case 4:
      month = fullMonth ? 'April' : 'Apr';
      break;
    case 5:
      month = 'May';
      break;
    case 6:
      month = fullMonth ? 'June' : 'Jun';
      break;
    case 7:
      month = fullMonth ? 'July' : 'Jul';
      break;
    case 8:
      month = fullMonth ? 'August' : 'Aug';
      break;
    case 9:
      month = fullMonth ? 'September' : 'Sep';
      break;
    case 10:
      month = fullMonth ? 'October' : 'Oct';
      break;
    case 11:
      month = fullMonth ? 'November' : 'Nov';
      break;
    case 12:
      month = fullMonth ? 'December' : 'Dec';
      break;
  }
  String sfx = '';
  if (withSuffix) {
    int end = dateTime.day % 10;
    if (dateTime.day > 13 || dateTime.day < 10) {
      if (end == 1) {
        sfx = 'st';
      } else if (end == 2) {
        sfx = 'nd';
      } else if (end == 3) {
        sfx = 'rd';
      } else {
        sfx = 'th';
      }
    } else {
      sfx = 'th';
    }
  }
  return '$month ${dateTime.day}$sfx${withYear ? ' ${dateTime.year}' : ''}';
}

bool isToday(DateTime date) {
  final now = DateTime.now();
  return (now.day == date.day && now.month == date.month && now.year == date.year);
}
