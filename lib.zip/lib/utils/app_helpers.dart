import 'package:flutter/material.dart';

import '../components/announcements_bottom_sheet.dart';
import '../controller/app_state_controller.dart';
import '../models/announcement_model.dart';
import '../services/firestore_helper.dart';

Future<void> getAnnouncements(BuildContext context, {bool isFirst = false}) async {
  final AppStateController _controller = AppStateController.controller;
  List<Announcement> announcements;
  announcements = await FirestoreHelper.getTodayAnnouncements(_controller.userModel.value.userBatch!.currentDay, _controller.userModel.value.userQuestionnaire!, _controller.appLocale.value);
  if (announcements.isNotEmpty || !isFirst) {
    showModalBottomSheet(
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25),
            topRight: Radius.circular(25),
          ),
        ),
        context: context,
        builder: (context) {
          return AnnouncementsBottomSheet(_controller.userModel.value.fName, announcements: announcements);
        });
  }
}
