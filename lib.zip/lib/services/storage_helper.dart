import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:http/http.dart';
import 'package:path_provider/path_provider.dart';

import '../constants.dart';

class StorageHelper {
  static final FirebaseStorage _storage = FirebaseStorage.instanceFor(bucket: 'gs://d-detox-29cdb.appspot.com');
  static final Reference _userProfilesRef = _storage.ref().child('user_profile_images');
  static final Reference _forumsRef = _storage.ref().child('forums');

  /// return the local storage location for this app
  static Future<String> imagesLocation() async {
    Directory? appDir = Platform.isIOS ? await getApplicationSupportDirectory() : await getExternalStorageDirectory();
    String location = appDir!.path + '/images/';
    return location;
  }

  /// checks if the image is present in Local Storage under the given [imageName]
  /// otherwise downloads from the given url and save's it locally.
  static Future<File?> checkImageIsPresent({required String imageName, required String url}) async {
    File? image = await getLocalRecipeImage(imageName);
    // if (image == null) {
    //   image = await downloadRecipeImage(imageName: imageName, url: url);
    // }
    return image ?? await downloadRecipeImage(imageName: imageName, url: url);
  }

  /// Get's an image from the local storage with the given imageName
  static Future<File?> getLocalRecipeImage(imageName) async {
    String localPath = await imagesLocation();
    String filePath = '$localPath$imageName';
    File? temp;
    if (File.fromUri(Uri.parse(filePath)).existsSync()) {
      temp = File.fromUri(Uri.parse(filePath));
    } else {
      temp = null;
    }
    return temp;
  }

  /// Save's the given image locally with the given imageName
  static Future<void> saveRecipeImageLocally({required String imageName, required File image}) async {
    String localPath = await imagesLocation();
    String filePath = '$localPath$imageName';
    Directory(localPath).createSync(recursive: true);
    File temp = File(filePath);
    temp.writeAsBytesSync(image.readAsBytesSync());
  }

  /// Delete's local image from storage
  static Future<void> deleteImageLocally(String imageName) async {
    String localPath = await imagesLocation();
    String filePath = '$localPath$imageName';
    File(filePath).deleteSync();
  }

  ///   Downloads the image from the given url and save's it locally with the given imageName
  static Future<File?> downloadRecipeImage({required String url, required String imageName}) async {
    String localPath = await imagesLocation();
    String filePath = '$localPath$imageName';
    Directory(localPath).createSync(recursive: true);
    File? profileImage = File(filePath);
    try {
      Response response = await get(Uri.parse(url));
      profileImage.writeAsBytesSync(response.bodyBytes);
    } catch (e) {
      profileImage = null;
    }
    return profileImage;
  }

  ///   Uploads the given image or override the image if exist with the same name then returns its downloadURL
  static Future<String> uploadRecipeImage({required String imageName, required File imageFile}) async {
    UploadTask upTask = _storage.ref().child(imageName).putFile(imageFile);
    TaskSnapshot taskSnapshot = await Future.value(upTask);
    String imgUrl = await taskSnapshot.ref.getDownloadURL();
    return imgUrl;
  }

  ///   Delete the Recipe image from Firebase Storage with the given name
  static Future<void> deleteRecipeImageFirestore(String imageName) async {
    try {
      await _storage.ref().child(imageName).delete();
    } catch (e) {
      print(e);
    }
  }

  static Future<String> uploadProfileImage({required String imageName, required File imageFile}) async {
    UploadTask upTask = _userProfilesRef.child(imageName).putFile(imageFile);
    TaskSnapshot taskSnapshot = await Future.value(upTask);
    String imgUrl = await taskSnapshot.ref.getDownloadURL();
    return imgUrl;
  }

  static Future<void> deleteProfileImageByNameFirestore(String imageName) async {
    try {
      await _userProfilesRef.child(imageName).delete();
      print('deleted image with name: $imageName');
    } catch (e) {
      print(e);
    }
  }

  static Future<void> deleteProfileImageByUrlFirestore(String imageUrl) async {
    try {
      await FirebaseStorage.instance.refFromURL(imageUrl).delete();
      print('deleted image with url: $imageUrl');
    } catch (e) {
      print(e);
    }
  }

  //                Forum

  static Future<String> uploadPostImage({ required String imageName, required File imageFile}) async {
    UploadTask upTask = _forumsRef.child(kForumId).child(imageName).putFile(imageFile);
    TaskSnapshot taskSnapshot = await Future.value(upTask);
    String imgUrl = await taskSnapshot.ref.getDownloadURL();
    return imgUrl;
  }
}
