import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:detox_app/models/post_model.dart';
import 'package:detox_app/services/storage_helper.dart';

import '../constants.dart';
import '../models/announcement_model.dart';
import '../models/batch_model.dart';
import '../models/method_practice_model.dart';
import '../models/paid_user.dart';
import '../models/questionnaire_model.dart';
import '../models/recipe_model.dart';
import '../models/shopping_item_model.dart';
import '../models/user_model.dart';

class FirestoreHelper {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final CollectionReference _usersRef = _firestore.collection('users');
  static final CollectionReference _paidUsersRef = _firestore.collection('paidUsers');
  static CollectionReference recipesRef = _firestore.collection('recipes');
  static CollectionReference batchesRef = _firestore.collection('batches');
  static CollectionReference methodsRef = _firestore.collection('methods');
  static CollectionReference practicesRef = _firestore.collection('practices');
  static CollectionReference announcementsRef = _firestore.collection('announcements');
  static CollectionReference shoppingListRef = _firestore.collection('shoppingList');
  static CollectionReference forumRef = _firestore.collection('forums');

//                  User Operations

  ///  Saves a user data to Firestore
  static Future<void> saveUserFirestore(UserModel user) async {
    await _usersRef.doc(user.userID).set(user.toMap());
  }

  ///  Fetches a User's data and returns a UserModel Object or null if there is no data present
  static Future<UserModel?> getUserFirestore(String userID) async {
    DocumentSnapshot userData = await _usersRef.doc(userID).get();
    return userData.data() != null ? UserModel.fromMap(userData.data() as Map<String, dynamic>) : null;
  }

  ///  Get's all the users from Firestore
  static Future<List<UserModel>> getAllUsersFirestore() async {
    List<UserModel> usersList = [];
    QuerySnapshot usersSnapshots = await _usersRef.get();
    for (var userData in usersSnapshots.docs) {
      usersList.add(UserModel.fromMap(userData.data() as Map<String, dynamic>));
    }
    return usersList;
  }

  /// Delete a user's data after his batch has been expired
  static Future<void> deleteUserFirestore(String id) async {
    await _usersRef.doc(id).delete();
  }

  ///  Saves a Paid User data to Firestore. Don't use this other than for testing
  static Future<void> savePaidUser(PaidUser paidUser) async {
    await _paidUsersRef.add(paidUser.toMap());
  }

  ///  Fetches a PaidUser's data and returns a PaidUser Object or null if there is no data present
  static Future<PaidUser?> getPaidUserFirestore(String countryCode, String number) async {
    QuerySnapshot userData = await _paidUsersRef.where('countryCode', isEqualTo: countryCode).where('number', isEqualTo: number).get();
    PaidUser? paidUser;
    for (var element in userData.docs) {
      paidUser = PaidUser.fromMap(element.data() as Map<String, dynamic>);
    }
    return paidUser;
  }

  ///  Get's all the paid users from Firestore
  static Future<List<PaidUser>> getAllPaidUsersFirestore() async {
    List<PaidUser> paidUsersList = [];
    QuerySnapshot usersSnapshots = await _paidUsersRef.get();
    for (var userData in usersSnapshots.docs) {
      paidUsersList.add(PaidUser.fromMap(userData.data() as Map<String, dynamic>));
    }
    return paidUsersList;
  }

  ///  Deletes a Paid User data from Firestore. Use this after the batch has expired
  static Future<void> deletePaidUserFirestore(String countryCode, String number) async {
    QuerySnapshot userData = await _paidUsersRef.where('countryCode', isEqualTo: countryCode).where('number', isEqualTo: number).get();
    QueryDocumentSnapshot? userDocument;
    for (var element in userData.docs) {
      userDocument = element;
    }
    if (userDocument != null) {
      await _paidUsersRef.doc(userDocument.id).delete();
      print('paid user with number: ${PaidUser.fromMap(userDocument.data() as Map<String, dynamic>).phone} deleted');
    }
  }

//                  Questionnaire Operations

  // ///   Saves user Questionnaire to firebase
  // static Future<void> saveUserQuestionnaireFirestore(Questionnaire questionnaire) async {
  //   await _questionnaireRef.doc(questionnaire.userID).set(questionnaire.toMap());
  // }
  //
  // ///  Fetches a User's data and returns a UserModel Object or null if there is no data present
  // static Future<Questionnaire> getUserQuestionnaireFirestore(String userID) async {
  //   DocumentSnapshot questionnaireData = await _questionnaireRef.doc(userID).get();
  //   return questionnaireData.data() != null ? Questionnaire.fromMap(questionnaireData.data()) : null;
  // }

  //                  Recipes Operations

  ///   Gets the Documents Reference for a new recipe
  static DocumentReference getNewRecipeDoc() {
    return recipesRef.doc();
  }

  ///   Get all the recipes from Firestore
  static Future<List<Recipe>> getAllRecipesFirestore() async {
    List<Recipe> recipes = [];
    QuerySnapshot recipesSnapshots = await recipesRef.get();
    for (var recipeData in recipesSnapshots.docs) {
      recipes.add(Recipe.fromMap(recipeData.data() as Map<String, dynamic>));
    }
    return recipes;
  }

  ///   Updates the Recipe from Firestore with given the Recipe
  static Future<void> updateRecipeFirestore(Recipe recipe) async {
    await recipesRef.doc(recipe.id).set(recipe.toMap());
  }

  ///   Deletes the Recipe from Firestore with given id
  static Future<void> deleteRecipeFirestore(String id) async {
    await recipesRef.doc(id).delete();
  }

  //                  Cleansing Batch Operations

  ///   Get all the Batches from Firestore
  static Future<List<Batch>> getAllBatchesFirestore() async {
    List<Batch> batches = [];
    QuerySnapshot batchesSnapshots = await batchesRef.get();
    for (var batchData in batchesSnapshots.docs) {
      batches.add(Batch.fromMap(batchData.data() as Map<String, dynamic>));
    }
    return batches;
  }

  ///   Gets the Documents Reference for a new batch
  static DocumentReference getNewBatchDoc() {
    return batchesRef.doc();
  }

  ///   Deletes the Batch from Firestore with given id
  static Future<void> deleteBatchFirestore(String id) async {
    await batchesRef.doc(id).delete();
  }

//                  Methods Operations

  ///   Get all the methods from Firestore
  static Future<List<MethodPractice>> getAllMethodsFirestore() async {
    List<MethodPractice> methods = [];
    QuerySnapshot methodsSnapshots = await methodsRef.get();
    for (var methodData in methodsSnapshots.docs) {
      methods.add(MethodPractice.fromMap(methodData.data() as Map<String, dynamic>));
    }
    return methods;
  }

  ///   Gets the Documents Reference for a new method
  static DocumentReference getNewMethodDoc() {
    return methodsRef.doc();
  }

  ///   Deletes the Method from Firestore with given id
  static Future<void> deleteMethodFirestore(String id) async {
    await methodsRef.doc(id).delete();
  }

  ///   Updates the Method from Firestore with given the Method
  static Future<void> updateMethodFirestore(MethodPractice method) async {
    await methodsRef.doc(method.id).set(method.toMap());
  }

  //                  Practice Operations

  ///   Get all the practices from Firestore
  static Future<List<MethodPractice>> getAllPracticesFirestore() async {
    List<MethodPractice> practices = [];
    QuerySnapshot practicesSnapshots = await practicesRef.get();
    for (var practiceData in practicesSnapshots.docs) {
      practices.add(MethodPractice.fromMap(practiceData.data() as Map<String, dynamic>));
    }
    return practices;
  }

  ///   Gets the Documents Reference for a new practice
  static DocumentReference getNewPracticeDoc() {
    return practicesRef.doc();
  }

  ///   Deletes the Practice from Firestore with given id
  static Future<void> deletePracticeFirestore(String id) async {
    await practicesRef.doc(id).delete();
  }

  ///   Updates the Practice from Firestore with given the Practice
  static Future<void> updatePracticeFirestore(MethodPractice practice) async {
    await practicesRef.doc(practice.id).set(practice.toMap());
  }

  //                  Announcement Operations

  ///   Get all the announcements from Firestore
  static Future<List<Announcement>> getAllAnnouncementsFirestore() async {
    List<Announcement> announcements = [];
    QuerySnapshot announcementSnapshots = await announcementsRef.get();
    for (var announcementData in announcementSnapshots.docs) {
      announcements.add(Announcement.fromMap(announcementData.data() as Map<String, dynamic>));
    }
    return announcements;
  }

  ///   Gets the list of announcement for the given day
  static Future<List<Announcement>> getTodayAnnouncements(int day, Questionnaire questionnaire, String locale) async {
    List<Announcement> todayAnnouncements = [];
    QuerySnapshot querySnapshot = await announcementsRef.where('days', arrayContains: day).where('locale', isEqualTo: locale).get();
    for (var element in querySnapshot.docs) {
      Announcement announcement = Announcement.fromMap(element.data() as Map<String, dynamic>);
      for (String announcementCategory in announcement.categories) {
        if (questionnaire.hasDiabetes) {
          if (announcementCategory == diabetes && announcement.locale == locale) {
            todayAnnouncements.add(announcement);
            break;
          }
        } else {
          if (questionnaire.purpose.contains(announcementCategory) && announcement.locale == locale) {
            todayAnnouncements.add(announcement);
            break;
          }
        }
      }
    }
    return todayAnnouncements;
  }

  ///   Gets the list of announcement before the batch starts
  static Future<List<Announcement>> getBeforeStartedAnnouncements(String locale) async {
    List<Announcement> todayAnnouncements = [];
    QuerySnapshot querySnapshot = await announcementsRef.where('availableThroughout', isEqualTo: true).where('locale', isEqualTo: locale).get();
    for (var element in querySnapshot.docs) {
      todayAnnouncements.add(Announcement.fromMap(element.data() as Map<String, dynamic>));
    }
    return todayAnnouncements;
  }

  ///   Gets the Documents Reference for a new announcement
  static DocumentReference getNewAnnouncementDoc() {
    return announcementsRef.doc();
  }

  ///   Deletes the Announcement from Firestore with given id
  static Future<void> deleteAnnouncementFirestore(String id) async {
    await announcementsRef.doc(id).delete();
  }

  ///   Updates the Announcement from Firestore with given the Announcement
  static Future<void> updateAnnouncementFirestore(Announcement announcement) async {
    await announcementsRef.doc(announcement.id).set(announcement.toMap());
  }

  //                  Shopping List Operations

  ///   Get all the shopping list items from Firestore
  static Future<List<ShoppingItem>> getAllShoppingItemsFirestore() async {
    List<ShoppingItem> shoppingList = [];
    QuerySnapshot shoppingListSnapshots = await shoppingListRef.get();
    for (var shoppingItemData in shoppingListSnapshots.docs) {
      shoppingList.add(ShoppingItem.fromMap(shoppingItemData.data() as Map<String, dynamic>));
    }
    return shoppingList;
  }

  ///   Gets the Documents Reference for a new shopping list item
  static DocumentReference getNewShoppingItemDoc() {
    return shoppingListRef.doc();
  }

  ///   Deletes the shopping item from Firestore with given id
  static Future<void> deleteShoppingItemFirestore(String id) async {
    await shoppingListRef.doc(id).delete();
  }

  ///   Updates the Announcement from Firestore with given the Announcement
  static Future<void> updateShoppingItemFirestore(ShoppingItem shoppingItem) async {
    await shoppingListRef.doc(shoppingItem.id).set(shoppingItem.toMap());
  }

  //                          Forum

  static DocumentReference getNewPostDoc() {
    return forumRef.doc(kForumId).collection('posts').doc();
  }

  static Future<void> deletePost(Post post) async {
    try {
      StorageHelper.deleteProfileImageByUrlFirestore(post.postImgUrl);
      await forumRef.doc(kForumId).collection('posts').doc(post.id).collection('comments').get().then((cd) {
        for (var comment in cd.docs) {
          forumRef.doc(kForumId).collection('posts').doc(post.id).collection('comments').doc(comment.id).delete();
        }
      });
      forumRef.doc(kForumId).collection('posts').doc(post.id).delete();
    } catch (e) {
      print(e);
      print('Error deleting post: ${post.id}');
    }
  }

  static Future<void> deleteForum() async {
    try {
      await forumRef.doc(kForumId).collection('posts').get().then((pd) async {
        for (var post in pd.docs) {
          Post p;
          try {
            p = Post.fromMap(post.data());
            if (p.userImgUrl.isNotEmpty) {
              await StorageHelper.deleteProfileImageByUrlFirestore(p.userImgUrl);
            }
          } catch (e) {
            print(e);
          }
          forumRef.doc(kForumId).collection('posts').doc(post.id).collection('comments').get().then((cd) async {
            for (var comment in cd.docs) {
              await forumRef.doc(kForumId).collection('posts').doc(post.id).collection('comments').doc(comment.id).delete();
            }
          });
          await forumRef.doc(kForumId).collection('posts').doc(post.id).delete();
        }
      });
      await forumRef.doc(kForumId).delete();
    } catch (e) {
      print(e);
      print('Error deleting forum: $kForumId');
    }
  }

  static DocumentReference getNewCommentDoc(String postId) {
    return forumRef.doc(kForumId).collection('posts').doc(postId).collection('comments').doc();
  }
}
