import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../components/empty_app_bar.dart';
import '../components/language_selector_dropdown.dart';
import '../components/main_button.dart';
import '../constants.dart';
import '../screens/home_screen.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({Key? key}) : super(key: key);
  @override
  _WelcomeScreenState createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  late YoutubePlayerController _controller;

  @override
  void initState() {
    _controller = YoutubePlayerController(
      flags: const YoutubePlayerFlags(autoPlay: true),
      initialVideoId: YoutubePlayer.convertUrlToId('https://youtu.be/Y4qkSZ9RSqM')!,
    );
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  Widget getOption(String key) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      margin: const EdgeInsets.all(6),
      decoration: kSelectedBoxDecoration,
      child: Text(
        key,
        style: kSelectedTextStyle.copyWith(fontSize: 15),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return YoutubePlayerBuilder(
      onEnterFullScreen: () {
        if (_controller.value.isPlaying) {
          _controller.play();
        }
      },
      onExitFullScreen: () {
        if (_controller.value.isPlaying) {
          _controller.play();
        }
      },
      player: YoutubePlayer(
        progressIndicatorColor: kAppColor,
        controller: _controller,
        showVideoProgressIndicator: true,
      ),
      builder: (BuildContext context, Widget player) {
        return Scaffold(
          appBar: const EmptyAppBar(kAppColor),
          body: NotificationListener<OverscrollIndicatorNotification>(
            onNotification: (OverscrollIndicatorNotification scrollEndNotification) {
              scrollEndNotification.disallowGlow();
              return true;
            },
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 20),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 10, right: 10, top: 20),
                        child: LanguageSelectorDropdown(),
                      ),
                      Hero(
                        tag: 'Logo',
                        child: Image.asset(
                          '$assets/detox_logo.png',
                          height: 200,
                          width: 200,
                        ),
                      ),
                      const SizedBox(width: 80),
                    ],
                  ),
                  const SizedBox(height: 15),
                  SizedBox(
                    width: size.width * 0.9,
                    child: Text(
                      'welcome_scr_hdng'.tr,
                      textAlign: TextAlign.center,
                      style: kHeading1Style.copyWith(color: kAppColor),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 15, bottom: 25),
                    width: size.width * 0.9,
                    alignment: Alignment.center,
                    child: player,
                  ),
                  MainButton(
                      width: 150,
                      title: 'start_program'.tr,
                      onTap: () {
                        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const HomeScreen()));
                      }),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
