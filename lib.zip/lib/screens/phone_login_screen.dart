import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:geocoding/geocoding.dart' as geo;
import 'package:get/get.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:location/location.dart';

import '../components/custom_drop_down.dart';
import '../components/custom_text_field.dart';
import '../components/empty_app_bar.dart';
import '../components/language_selector_dropdown.dart';
import '../components/main_button.dart';
import '../components/show_dialog.dart';
import '../constants.dart';
import '../data/countries_data.dart';
import 'otp_screen.dart';

class PhoneLoginScreen extends StatefulWidget {
  const PhoneLoginScreen({Key? key}) : super(key: key);
  @override
  _PhoneLoginScreenState createState() => _PhoneLoginScreenState();
}

class _PhoneLoginScreenState extends State<PhoneLoginScreen> {
  String _phoneNumber = '';
  String? _phoneErrorText;
  String _dialingCode = '';
  String _country = '';
  String? _codeErrorText;
  Map<String, String> _countryData = {};
  bool _signUpFlag = true;

  _numberValidator() {
    if (_dialingCode.isEmpty) {
      _codeErrorText = 'cntry_err'.tr;
    } else {
      _codeErrorText = null;
    }
    if (_phoneNumber.isEmpty) {
      _phoneErrorText = 'phone_err'.tr;
    } else if (_phoneNumber.length < 5) {
      _phoneErrorText = 'phone_short_err'.tr;
    } else {
      _phoneErrorText = null;
    }
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    if (mounted) {
      try {
        _detectCountryName();
      } catch (e) {
        print('error detecting country: ${e.toString()}');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: const EmptyAppBar(kAppColor),
      body: SafeArea(
        child: NotificationListener<OverscrollIndicatorNotification>(
          onNotification: (overScroll) {
            overScroll.disallowGlow();
            return true;
          },
          child: SingleChildScrollView(
            child: Container(
              height: size.height - MediaQuery.of(context).viewPadding.top,
              width: size.width,
              padding: const EdgeInsets.symmetric(vertical: 5),
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const SizedBox(height: 10),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 10, right: 10, top: 20),
                            child: LanguageSelectorDropdown(),
                          ),
                          Hero(
                            tag: 'Logo',
                            child: Image.asset(
                              '$assets/detox_logo.png',
                              height: 160,
                              width: 160,
                            ),
                          ),
                          const SizedBox(width: 80),
                        ],
                      ),
                      const SizedBox(height: 15),
                      Text(
                        _signUpFlag ? 'sign_up'.tr : 'login'.tr,
                        style: kHeading1Style,
                      ),
                      const Divider(
                        color: kAppColor,
                        indent: 20,
                        thickness: 0.3,
                        endIndent: 20,
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    child: Row(
                      children: <Widget>[
                        Text(
                          'entr_num'.tr,
                          style: const TextStyle(
                            fontWeight: FontWeight.w500,
                            color: Colors.black,
                            letterSpacing: 1.1,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                  CustomDropDown<Map<String, String>?>(
                    height: 45,
                    width: size.width * 0.85,
                    selectedItem: _countryData,
                    items: COUNTRIES_DATA,
                    borderColor: _codeErrorText != null ? Colors.red : null,
                    onChanged: (value) {
                      _countryData = value!;
                      _country = value['name']!;
                      _dialingCode = value['dialingCode']!;
                      if (_codeErrorText != null) {
                        _numberValidator();
                      }
                    },
                    selectedItemBuilder: (context, countryInfo, value) {
                      return _countryData.isEmpty
                          ? Text(
                              'slct_country'.tr,
                              style: kHintStyle.copyWith(color: _codeErrorText != null ? Colors.red : kDarkGrey),
                            )
                          : Text(
                              '${_countryData['name']} (${_countryData['dialingCode']})',
                              style: const TextStyle(fontSize: 16, color: kAppColor),
                            );
                    },
                    popUpItemBuilder: (context, value, isSelected) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Text(
                          '${value!['name']} (${value['dialingCode']})',
                          style: const TextStyle(fontSize: 17, color: kDarkGrey, fontWeight: FontWeight.w300),
                        ),
                      );
                    },
                    prefix: Container(
                      height: 20,
                      width: 20,
                      padding: const EdgeInsets.all(11),
                      child: SvgPicture.asset(
                        '$assets/icon-earth.svg',
                        color: _codeErrorText != null ? Colors.red.shade300 : kAppColor.withAlpha(200),
                      ),
                    ),
                    showSearchBox: true,
                    contentPadding: const EdgeInsets.all(0),
                    searchBoxContentPadding: const EdgeInsets.only(left: 15, right: 15, top: 5),
                    searchBoxHintText: 'srch_countries'.tr,
                  ),
                  Container(
                    padding: const EdgeInsets.only(left: 25),
                    height: 20,
                    width: size.width * 0.85,
                    child: Text(
                      _codeErrorText ?? '',
                      style: const TextStyle(height: 1.4, color: Colors.red, fontSize: 10),
                    ),
                  ),
                  CustomTextField(
                    height: 55,
                    width: size.width * 0.85,
                    contentPadding: const EdgeInsets.only(left: 20, right: 20, bottom: 5),
                    labelText: 'phone_num'.tr,
                    helperText: '',
                    hintText: null,
                    errorText: _phoneErrorText,
                    keyboardType: TextInputType.phone,
                    textInputAction: TextInputAction.done,
                    obscureText: false,
                    suffix: null,
                    onChanged: (value) {
                      _phoneNumber = value;
                      if (_phoneErrorText != null) {
                        _numberValidator();
                      }
                    },
                    onEditingComplete: () {
                      FocusScope.of(context).unfocus();
                    },
                  ),
                  const SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: MainButton(
                        title: 'next'.tr,
                        onTap: () async {
                          _numberValidator();
                          if (_codeErrorText == null && _phoneErrorText == null) {
                            if (await InternetConnectionChecker().hasConnection) {
                              Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => OTPScreen(code: _dialingCode, phone: _phoneNumber, country: _country)));
                            } else {
                              showDialog(
                                  context: context,
                                  builder: (_) => ShowDialog(
                                        alertMessage: 'no_conn_err'.tr,
                                      ));
                            }
                          }
                        }),
                  ),
                  const SizedBox(height: 10),
                  const Expanded(child: SizedBox()),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        _signUpFlag ? 'alrdy_hav_acc'.tr : 'need_acc'.tr,
                        style: const TextStyle(
                          fontSize: 14,
                          color: kGrey,
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          _signUpFlag = !_signUpFlag;
                          setState(() {});
                        },
                        child: Container(
                          padding: const EdgeInsets.all(5),
                          color: Colors.white,
                          child: Text(
                            _signUpFlag ? 'login'.tr : 'sign_up'.tr,
                            style: kTextActionStyle,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  _detectCountryName() async {
    try {
      Location _location = Location();
      bool _serviceEnabled;
      PermissionStatus _permissionGranted;
      LocationData _locationData;

      _serviceEnabled = await _location.serviceEnabled();
      if (!_serviceEnabled) {
        _serviceEnabled = await _location.requestService();
        if (!_serviceEnabled) {
          return;
        }
      }

      _permissionGranted = await _location.hasPermission();
      if (_permissionGranted == PermissionStatus.denied) {
        _permissionGranted = await _location.requestPermission();
        if (_permissionGranted != PermissionStatus.granted) {
          return;
        }
      }
      _location.changeSettings(accuracy: LocationAccuracy.low);

      _locationData = await _location.getLocation();

      if (_locationData.latitude != null && _locationData.longitude != null) {
        await _getCountryName(_locationData.latitude!, _locationData.longitude!);
      } else {
        _detectCountryName();
      }
    } catch (e) {
      _detectCountryName();
    }
  }

  _getCountryName(double lat, double lng) async {
    try {
      List<geo.Placemark> addresses = await geo.placemarkFromCoordinates(lat, lng);
      for (var element in COUNTRIES_DATA) {
        if (element['countryCode']!.toLowerCase() == addresses.first.isoCountryCode!.toLowerCase()) {
          setState(() {
            _countryData = element;
            _dialingCode = element['dialingCode']!;
            _country = element['name']!;
          });
        }
      }
    } on PlatformException catch (e) {
      _getCountryName(lat, lng);
    } catch (e) {
      print('error getting country: ${e.toString()}');
    }
  }
}
