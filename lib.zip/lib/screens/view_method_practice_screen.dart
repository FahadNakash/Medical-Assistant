import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/method_practice_model.dart';
import '../settings/preferences.dart';

class ViewMethodPracticeScreen extends StatefulWidget {
  const ViewMethodPracticeScreen(this.methodPractice, {Key? key}) : super(key: key);
  final MethodPractice methodPractice;

  @override
  _ViewMethodPracticeScreenState createState() => _ViewMethodPracticeScreenState();
}

class _ViewMethodPracticeScreenState extends State<ViewMethodPracticeScreen> {
  final AppStateController _appController = AppStateController.controller;
  late YoutubePlayerController _controller;
  late bool isSaved;

  @override
  void initState() {
    super.initState();
    _controller = YoutubePlayerController(
      flags: const YoutubePlayerFlags(autoPlay: false),
      initialVideoId: YoutubePlayer.convertUrlToId(widget.methodPractice.videoUrl) ?? '',
    );
    isSaved = _appController.watchedVideos.contains(widget.methodPractice.id);
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return YoutubePlayerBuilder(
      onEnterFullScreen: () {
        if (_controller.value.isPlaying) {
          _controller.play();
        }
      },
      onExitFullScreen: () {
        if (_controller.value.isPlaying) {
          _controller.play();
        }
      },
      player: YoutubePlayer(
        progressIndicatorColor: kAppColor,
        controller: _controller,
        showVideoProgressIndicator: true,
        onReady: () {
          if (!isSaved) {
            _controller.addListener(() {
              int percent80 = (_controller.metadata.duration.inSeconds * 0.8).truncate();
              if (percent80 != 0) {
                if (_controller.value.position.inSeconds >= percent80) {
                  saveToWatchedVideo();
                }
              }
            });
          }
        },
      ),
      builder: (BuildContext context, Widget player) {
        return Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            iconTheme: const IconThemeData(color: Colors.white),
            backgroundColor: kAppColor,
            title: Text(
              widget.methodPractice.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white),
            ),
          ),
          body: SizedBox(
            height: size.height,
            width: size.width,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: kAppColor, width: 2.5),
                    ),
                    margin: const EdgeInsets.only(left: 10, right: 10, top: 20, bottom: 20),
                    height: size.width * 0.5,
                    width: size.width,
                    child: player,
                  ),
                  Container(
                    margin: const EdgeInsets.only(left: 10, right: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'description'.tr,
                          style: kHeading2Style,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                          child: Text(
                            widget.methodPractice.description,
                            textAlign: TextAlign.center,
                            textDirection: _appController.appLocale.value == kEnglishLocale ? TextDirection.ltr : TextDirection.rtl,
                            style: Theme.of(context).textTheme.subtitle1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void saveToWatchedVideo() {
    if (!_appController.watchedVideos.contains(widget.methodPractice.id)) {
      isSaved = true;
      _appController.watchedVideos.add(widget.methodPractice.id);
      Preferences.saveWatchedVideos(_appController.watchedVideos.toList());
    }
  }
}
