import 'package:detox_app/models/post_recipe.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants.dart';
import '../controller/app_state_controller.dart';

class ViewPostRecipeScreen extends StatelessWidget {
  ViewPostRecipeScreen({required this.recipe, Key? key}) : super(key: key);
  final PostRecipe recipe;
  final AppStateController _controller = AppStateController.controller;

  List<Widget> drawIngredientsColumn(PostRecipe recipe) {
    List<Widget> ingredientsColumnList = <Widget>[];
    if (recipe.ingredients.isNotEmpty) {
      for (String ingredient in recipe.ingredients) {
        ingredientsColumnList.add(Container(
          margin: kRecipeMargin,
          padding: kRecipePadding,
          decoration: kSelectedBoxDecoration,
          child: Text(
            ingredient,
            style: kSelectedTextStyle,
            textAlign: TextAlign.center,
            textDirection: _controller.appLocale.value == kEnglishLocale ? TextDirection.ltr : TextDirection.rtl,
          ),
        ));
      }
    }
    return ingredientsColumnList;
  }

  List<Widget> drawRecipeSteps(PostRecipe recipe) {
    List<Widget> stepsColumnList = <Widget>[];
    if (recipe.steps.isNotEmpty) {
      for (int i = 0; i < recipe.steps.length; i++) {
        stepsColumnList.add(Container(
          margin: kRecipeMargin,
          padding: kRecipePadding,
          decoration: kSelectedBoxDecoration,
          child: Column(
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    'steps'.trArgs(['${i + 1}']),
                    textDirection: _controller.appLocale.value == kEnglishLocale ? TextDirection.rtl : TextDirection.ltr,
                    style: const TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Text(
                recipe.steps[i],
                textDirection: _controller.appLocale.value == kEnglishLocale ? TextDirection.ltr : TextDirection.rtl,
                textAlign: TextAlign.center,
                style: kSelectedTextStyle,
              )
            ],
          ),
        ));
      }
    }
    return stepsColumnList;
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        iconTheme: const IconThemeData(color: kAppColor),
        backgroundColor: Colors.white,
        title: Text(
          recipe.title,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          textDirection: _controller.appLocale.value == kEnglishLocale ? TextDirection.ltr : TextDirection.rtl,
          style: const TextStyle(color: kAppColor),
        ),
      ),
      body: Container(
        height: size.height,
        width: size.width,
        padding: const EdgeInsets.symmetric(horizontal: 15),
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 30),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'req_ingred'.tr,
                      style: kBodyStyle.copyWith(fontWeight: FontWeight.w500),
                    ),
                    Text('total'.trArgs([recipe.ingredients.length.toString()])),
                  ],
                ),
              ),
              Container(
                width: size.width,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: kAppColor.withAlpha(20),
                  borderRadius: kEnabledBorderRadius,
                ),
                child: Wrap(
                  alignment: WrapAlignment.center,
                  children: drawIngredientsColumn(recipe),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'req_steps'.tr,
                      style: kBodyStyle.copyWith(fontWeight: FontWeight.w500),
                    ),
                    Text('total'.trArgs([recipe.steps.length.toString()])),
                  ],
                ),
              ),
              Container(
                width: size.width,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: kAppColor.withAlpha(20),
                  borderRadius: kEnabledBorderRadius,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: drawRecipeSteps(recipe),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
