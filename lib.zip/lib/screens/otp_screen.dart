import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:pinput/pin_put/pin_put.dart';
import 'package:url_launcher/url_launcher.dart';

import '../components/confirmation_dialog.dart';
import '../components/empty_app_bar.dart';
import '../components/language_selector_dropdown.dart';
import '../components/main_button.dart';
import '../components/show_dialog.dart';
import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/paid_user.dart';
import '../models/user_model.dart';
import '../services/firestore_helper.dart';
import '../settings/preferences.dart';
import 'home_screen.dart';
import 'phone_login_screen.dart';
import 'terms_conditions_screen.dart';

class OTPScreen extends StatefulWidget {
  const OTPScreen({required this.code, required this.phone, required this.country, Key? key}) : super(key: key);
  final String phone;
  final String code;
  final String country;

  @override
  _OTPScreenState createState() => _OTPScreenState();
}

class _OTPScreenState extends State<OTPScreen> {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  final AppStateController _appController = AppStateController.controller;
  late TextEditingController _pinPutController;
  late FocusNode _pinPutFocusNode;
  String _verificationCode = '';
  int? _resendTime;
  String? _pinCode;
  Timer? _timer;
  bool _showIndicator = false;
  @override
  void initState() {
    _pinPutFocusNode = FocusNode();
    _pinPutController = TextEditingController();
    _verifyPhone();
    super.initState();
  }

  void startTimer() {
    _resendTime = 60;
    _timer = Timer.periodic(const Duration(seconds: 1), (time) {
      if (_resendTime != 0) {
        setState(() {
          _resendTime = _resendTime! - 1;
        });
      } else {
        _timer?.cancel();
      }
    });
  }

  @override
  void dispose() {
    _pinPutFocusNode.dispose();
    _pinPutController.dispose();
    _timer?.cancel();
    _timer = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: const EmptyAppBar(kAppColor),
      body: NotificationListener<OverscrollIndicatorNotification>(
        onNotification: (OverscrollIndicatorNotification indicatorNotification) {
          indicatorNotification.disallowGlow();
          return true;
        },
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 10),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10, top: 20),
                    child: LanguageSelectorDropdown(),
                  ),
                  Hero(
                    tag: 'Logo',
                    child: Image.asset(
                      '$assets/detox_logo.png',
                      height: 160,
                      width: 160,
                    ),
                  ),
                  const SizedBox(width: 80),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                'verifying'.tr + ('(${widget.code}) ${widget.phone}'),
                textAlign: TextAlign.center,
                style: const TextStyle(color: kDarkGrey, fontSize: 28, fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 5),
              SizedBox(
                width: size.width * 0.8,
                child: Text(
                  'otp_sub_heading'.tr,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: kDarkGrey),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 25, left: 20, right: 20),
                child: PinPut(
                  fieldsCount: 6,
                  textStyle: const TextStyle(fontSize: 30, fontWeight: FontWeight.w500, color: kAppColor),
                  eachFieldWidth: 40,
                  eachFieldHeight: 55,
                  focusNode: _pinPutFocusNode,
                  controller: _pinPutController,
                  submittedFieldDecoration: pinFollowingDecoration,
                  selectedFieldDecoration: pinSelectedDecoration,
                  followingFieldDecoration: pinFollowingDecoration,
                  pinAnimationType: PinAnimationType.fade,
                  onChanged: (String pin) {
                    setState(() {
                      _pinCode = pin;
                      _showIndicator = false;
                    });
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 20, top: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                      onTap: _resendTime == null
                          ? null
                          : () {
                              if (_resendTime == 0) {
                                _verifyPhone();
                              }
                            },
                      child: Container(
                        color: Colors.white,
                        padding: const EdgeInsets.all(5),
                        child: _resendTime == null
                            ? const Text('')
                            : Text(
                                _resendTime == 0 ? 'resend_code'.tr : _resendTime.toString() + ' s',
                                style: const TextStyle(color: kAppColor, fontWeight: FontWeight.w500),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
              _showIndicator
                  ? Column(
                      children: [
                        const SizedBox(
                          height: 25,
                          width: 25,
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation(kAppColor),
                            strokeWidth: 1,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'pls_wait'.tr,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: kAppColor,
                          ),
                        ),
                      ],
                    )
                  : _pinCode?.length == 6
                      ? MainButton(
                          title: 'verify'.tr,
                          onTap: () async {
                            if (_pinCode == null || _pinCode == '') {
                              FocusScope.of(context).unfocus();
                              showDialog(
                                  context: context,
                                  builder: (_) => ShowDialog(
                                        title: 'error'.tr,
                                        alertMessage: 'pin_err_txt'.tr,
                                      ));
                            } else {
                              await _handleLoginRequest(PhoneAuthProvider.credential(verificationId: _verificationCode, smsCode: _pinCode!));
                            }
                          },
                        )
                      : Container(
                          width: 110,
                          height: 35,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(borderRadius: kEnabledBorderRadius, border: Border.all(color: kAppColor.withAlpha(70))),
                          child: Text(
                            'verify'.tr,
                            style: TextStyle(
                              color: kAppColor.withAlpha(100),
                              fontWeight: FontWeight.w500,
                              fontSize: 18,
                            ),
                          ),
                        ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleLoginRequest(PhoneAuthCredential credential) async {
    if (await InternetConnectionChecker().hasConnection) {
      setState(() {
        _showIndicator = true;
      });
      _timer?.cancel();
      try {
        final UserCredential userCred = await _firebaseAuth.signInWithCredential(credential);
        if (userCred.user != null) {
          UserModel? user = await FirestoreHelper.getUserFirestore(userCred.user!.uid);
          if (user != null) {
            if (user.userBatch != null) {
              if (user.userBatch!.isAvailableAfter) {
                _appController.setUser(user);
                await Preferences.saveUserSession(user);
                Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const HomeScreen()));
              } else {
                await FirestoreHelper.deletePaidUserFirestore(user.dialingCode, user.phoneNo);
                // await FirestoreHelper.deleteUserFirestore(user.userID);
                // if (user.userImgName.isNotEmpty) {
                //   await StorageHelper.deleteProfileImageByNameFirestore(user.userImgName);
                // }
                await showDialog(
                    context: context,
                    builder: (_) => ShowDialog(
                          alertMessage: 'program_end_msg'.tr,
                        ));
                Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
              }
            }
          } else {
            // user = UserModel(userID: userCred.user.uid, phoneNo: widget.phone, dialingCode: widget.code, country: widget.country, joiningDate: DateTime.now());
            user = UserModel();
            user.userID = userCred.user!.uid;
            user.phoneNo = widget.phone;
            user.dialingCode = widget.code;
            user.country = widget.country;
            user.joiningDate = DateTime.now();
            _appController.setUser(user);
            Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => TermsConditionsScreen()));
          }
        }
      } catch (e) {
        print('login error' + e.toString());
        FocusScope.of(context).unfocus();
        if (e.toString().contains('[cloud_firestore/unavailable]')) {
          await showDialog(
              context: context,
              builder: (_) => ShowDialog(
                    title: 'error'.tr,
                    alertMessage: 'unhealthy_conn_err'.tr,
                  ));
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
        } else if (e.toString().contains('[firebase_auth/session-expired]')) {
          await showDialog(
              context: context,
              builder: (_) => ShowDialog(
                    title: 'error'.tr,
                    alertMessage: 'otp_sms_expr'.tr,
                  ));
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
        } else {
          await showDialog(
              context: context,
              builder: (_) => ShowDialog(
                    title: 'error'.tr,
                    alertMessage: 'otp_request_err'.tr,
                  ));
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
        }
        setState(() {
          _showIndicator = false;
        });
      }
    } else {
      await showDialog(
          context: context,
          builder: (_) => ShowDialog(
                alertMessage: 'no_conn_err'.tr,
              ));
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
    }
  }

  Future<void> _verifyPhone() async {
    PaidUser? paidUser = await FirestoreHelper.getPaidUserFirestore(widget.code, widget.phone);
    if (paidUser == null) {
      bool decision = await showDialog(
          context: context,
          builder: (_) => ConfirmationDialog(
                alertMessage: 'not_paid_msg'.tr,
                confirmLabel: 'sure'.tr,
                cancelLabel: 'no_thanks'.tr,
              ));
      if (decision == true) {
        _openWebsite();
      }
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
    } else {
      await _firebaseAuth.verifyPhoneNumber(
        phoneNumber: widget.code + widget.phone,
        verificationCompleted: (PhoneAuthCredential credential) async {
          await _handleLoginRequest(credential);
        },
        verificationFailed: (FirebaseAuthException e) async {
          print('phone auth exception');
          print(e.message);
          await showDialog(
              context: context,
              builder: (_) => ShowDialog(
                    title: 'error'.tr,
                    alertMessage: e.message!,
                  ));
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
        },
        codeSent: (String verificationID, int? resendToken) {
          startTimer();
          // setState(() {
          _verificationCode = verificationID;
          // });
        },
        codeAutoRetrievalTimeout: (String verificationID) {
          // setState(() {
          _verificationCode = verificationID;
          // });
        },
        timeout: const Duration(seconds: 60),
      );
    }
  }

  Future<void> _openWebsite() async {
    String locale = Get.locale!.languageCode + '_' + Get.locale!.countryCode!;
    final String url = locale == kEnglishLocale ? 'https://www.regeneration.today/regeneration-detox/' : 'https://www.regeneration.today/%d7%aa%d7%95%d7%9b%d7%a0%d7%99%d7%aa-regeneration/';
    if (await canLaunch(url)) {
      await launch(
        url,
        forceSafariVC: false,
        forceWebView: false,
      );
    } else {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext _) => ShowDialog(
          title: 'error'.tr,
          alertMessage: 'no_browser_found'.tr,
          onTap: () {
            Navigator.of(context).pop();
            Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
          },
        ),
      );
    }
  }
}
