import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';

import '../components/add_recipe_sheet.dart';
import '../components/custom_text_field.dart';
import '../components/select_image_bottom_sheet.dart';
import '../components/show_dialog.dart';
import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/post_model.dart';
import '../models/post_recipe.dart';
import '../models/questionnaire_model.dart';
import '../services/firestore_helper.dart';
import '../services/storage_helper.dart';

class NewPostScreen extends StatefulWidget {
  const NewPostScreen({Key? key}) : super(key: key);

  @override
  _NewPostScreenState createState() => _NewPostScreenState();
}

class _NewPostScreenState extends State<NewPostScreen> {
  final _controller = AppStateController.controller;
  bool _isLoading = false;
  File? _img;
  bool _imgErr = false;
  String _postText = '';
  String? _postTextErr;
  int rn = Random().nextInt(15);

  @override
  void dispose() {
    super.dispose();
    _controller.newRecipe = PostRecipe.fromMap({});
  }

  _validateFields() {
    if (_img == null && _controller.newRecipe.title.isEmpty) {
      if (_postText.isEmpty) {
        _postTextErr = 'required_field_err'.tr;
      } else {
        _postTextErr = null;
      }
    }
    setState(() {});
  }

  _selectImage() async {
    ImageSource? src = await showModalBottomSheet(shape: const RoundedRectangleBorder(borderRadius: kTLRBorderRadius), context: context, builder: (_) => const SelectImageBottomSheet());
    if (src != null) {
      final XFile? _pickedFile = await ImagePicker().pickImage(source: src, imageQuality: 50, maxHeight: 500, maxWidth: 500);
      if (_pickedFile != null) {
        setState(() {
          _img = File(_pickedFile.path);
          _imgErr = false;
          rn = Random().nextInt(15);
        });
      }
    }
  }

  Widget getPostRecipeTile() {
    final recipe = _controller.newRecipe;
    final i = PostRecipe.categoriesList.indexOf(recipe.category);
    return GestureDetector(
      onTap: _isLoading
          ? null
          : () async {
              await showModalBottomSheet<void>(
                  context: context,
                  isScrollControlled: true,
                  isDismissible: true,
                  backgroundColor: Colors.transparent,
                  shape: const RoundedRectangleBorder(
                    borderRadius: kTLRBorderRadius,
                  ),
                  builder: (context) {
                    return AddRecipeScreen(postRecipe: recipe);
                  });
              setState(() {});
            },
      child: SizedBox(
        height: 70,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black26,
                    offset: Offset(0, 2),
                    blurRadius: 4,
                  )
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Container(
                  padding: const EdgeInsets.all(5),
                  height: 60,
                  width: 60,
                  alignment: Alignment.center,
                  color: Colors.white,
                  child: Image.asset(
                    '$assets/icons${i + 1}.png',
                  ),
                ),
              ),
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 65,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: Text(
                                  recipe.title,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: kAppColor,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              Flexible(
                                child: Text(
                                  'ingredients'.tr + recipe.ingredients.toString().replaceAll('[', '').replaceAll(']', ''),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: kDarkGrey),
                                ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: Icon(
                            Icons.remove_circle,
                            size: 25,
                            color: kAppColor.withOpacity(0.7),
                          ),
                          onPressed: () {
                            setState(() {
                              _controller.newRecipe = PostRecipe.fromMap({});
                            });
                          },
                        )
                      ],
                    ),
                  ),
                  SizedBox(width: double.infinity, child: Divider(height: 5, color: kAppColor.withAlpha(200))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: kAppColor),
        backgroundColor: Colors.white,
        actions: [
          _isLoading
              ? Container(
                  height: 25,
                  width: 25,
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  child: const CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation(kAppColor),
                  ),
                )
              : TextButton(
                  child: Text(
                    'post'.tr,
                    style: const TextStyle(color: kAppColor, fontWeight: FontWeight.bold),
                  ),
                  onPressed: () async {
                    setState(() => _isLoading = true);
                    _validateFields();
                    if (_postTextErr == null) {
                      await _createPost();
                    }
                    setState(() => _isLoading = false);
                  },
                ),
        ],
        title: Text(
          'new_post'.tr,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: kAppColor),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5),
              child: CustomTextField(
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                hintText: 'say_about_post'.tr,
                maxLines: 100,
                readOnly: _isLoading,
                minLines: 3,
                // autofocus: true,
                onChanged: (v) {
                  _postText = v;

                  if (_postTextErr != null) {
                    if (_postText.isEmpty) {
                      _postTextErr = 'required_field_err'.tr;
                    } else {
                      _postTextErr = null;
                    }
                    setState(() {});
                  }
                },
                errorText: _postTextErr,
              ),
            ),
            const SizedBox(height: 10),
            _img == null
                ? GestureDetector(
                    onTap: _isLoading ? null : _selectImage,
                    child: Container(
                      height: 200,
                      width: double.infinity,
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: _imgErr ? Colors.red[50] : Colors.grey[100],
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.image,
                            size: 100,
                            color: _imgErr ? Colors.red[400] : kAppColor.withOpacity(0.5),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            _imgErr ? 'image_req_err'.tr : 'add_image'.tr,
                            style: TextStyle(fontSize: 16, color: _imgErr ? Colors.red[400] : kAppColor.withOpacity(0.7), fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),
                  )
                : Container(
                    width: size.width,
                    height: size.width,
                    alignment: Alignment.center,
                    child: Image.file(_img!),
                    color: kColors[rn],
                  ),
            const SizedBox(height: 20),
            _controller.newRecipe.title.isNotEmpty
                ? getPostRecipeTile()
                : Align(
                    alignment: Alignment.center,
                    child: GestureDetector(
                      onTap: _isLoading
                          ? null
                          : () async {
                              await showModalBottomSheet<void>(
                                  context: context,
                                  isScrollControlled: true,
                                  isDismissible: true,
                                  backgroundColor: Colors.transparent,
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: kTLRBorderRadius,
                                  ),
                                  builder: (context) {
                                    return const AddRecipeScreen();
                                  });
                              setState(() {});
                            },
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: kEnabledBorderRadius,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Colors.black26,
                                    offset: Offset(0, 2),
                                    blurRadius: 4,
                                  )
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15),
                                child: Container(
                                  height: 55,
                                  width: 55,
                                  alignment: Alignment.center,
                                  color: Colors.white,
                                  padding: const EdgeInsets.all(10),
                                  child: SvgPicture.asset('$assets/icon-recipes.svg', color: kAppColor.withAlpha(130)),
                                ),
                              ),
                            ),
                            const SizedBox(width: 15),
                            Flexible(
                              child: Text(
                                'add_recipe_to_post'.tr,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: kAppColor,
                                  fontSize: 18,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }

  Future<void> _createPost() async {
    try {
      if (await InternetConnectionChecker().hasConnection) {
        final user = _controller.userModel.value;
        final postDoc = FirestoreHelper.getNewPostDoc();
        String url = '';
        String imageName = '';
        if (_img != null) {
          imageName = postDoc.id + '.' + _img!.path.split('.').last;
          url = await StorageHelper.uploadPostImage(imageName: imageName, imageFile: _img!);
        }
        Post post = Post(
          id: postDoc.id,
          userName: user.fName + ' ' + user.lName,
          userImgUrl: user.userImgUrl,
          userId: _controller.userModel.value.userID,
          postText: _postText,
          postImgUrl: url,
          postImgName: imageName,
          batchDate: _getBatchString(),
          recipe: _controller.newRecipe,
          language: Get.locale!.languageCode == 'en' ? kEnglishLocale : kHebrewLocale,
        );
        await postDoc.set(post.toMap());
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          duration: const Duration(seconds: 2),
          backgroundColor: kAppColor.withOpacity(0.8),
          content: Row(
            children: [
              const Icon(
                Icons.check_circle_outline,
                color: Colors.white,
              ),
              const SizedBox(width: 10),
              Text('post_created'.tr),
            ],
          ),
        ));
        Navigator.of(context).pop();
      } else {
        showDialog(context: context, builder: (_) => ShowDialog(alertMessage: 'no_conn_err'.tr));
      }
    } catch (_) {
      showDialog(context: context, builder: (_) => ShowDialog(alertMessage: 'otp_request_err'.tr));
    }
  }

  String _getBatchString() {
    String str = '';
    if (DateTime.now().isBefore(_controller.userModel.value.userBatch!.startingDate)) {
      final DateTime prepDate = _controller.userModel.value.userBatch!.startingDate.subtract(Duration(days: Questionnaire.coffeeOptions[_controller.userModel.value.userQuestionnaire!.cupsOfCoffee]!));
      if (DateTime.now().isBefore(prepDate)) {
        str = 'post_text_before_prep'.tr;
      } else {
        Duration diff = DateTime.now().difference(prepDate);
        str = 'post_text_prep_day'.trArgs(['${diff.inDays + 1}']);
      }
    } else {
      if (!_controller.userModel.value.userBatch!.isExpired) {
        str = 'post_text_detox_day'.trArgs(['${_controller.userModel.value.userBatch!.currentDay}']);
      } else {
        str = 'post_text_after_detox'.tr;
      }
    }
    return str;
  }
}
