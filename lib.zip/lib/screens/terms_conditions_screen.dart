import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';

import '../components/empty_app_bar.dart';
import '../components/language_selector_dropdown.dart';
import '../components/privacy_policy_widget.dart';
import '../components/show_dialog.dart';
import '../components/terms_of_use_widget.dart';
import '../constants.dart';
import 'phone_login_screen.dart';
import 'questionnaire_screen.dart';

class TermsConditionsScreen extends StatelessWidget {
  TermsConditionsScreen({Key? key}) : super(key: key);
  final RxBool atEnd = false.obs;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: const EmptyAppBar(kAppColor),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            margin: const EdgeInsets.only(top: 10),
            height: 50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('terms_conditions'.tr, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold, fontFamily: 'Trajan', color: kAppColor)),
                LanguageSelectorDropdown(),
              ],
            ),
          ),
          Expanded(
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Scrollbar(
                  isAlwaysShown: true,
                  radius: const Radius.circular(10),
                  child: NotificationListener(
                    onNotification: (ScrollEndNotification scrollEnd) {
                      if (scrollEnd.metrics.atEdge) {
                        if (scrollEnd.metrics.pixels == 0) {
                        } else {
                          atEnd.value = true;
                        }
                      }
                      return true;
                    },
                    child: NotificationListener<OverscrollIndicatorNotification>(
                      onNotification: (OverscrollIndicatorNotification indicatorNotification) {
                        indicatorNotification.disallowGlow();
                        return true;
                      },
                      child: SingleChildScrollView(
                        child: Column(
                          children: const [
                            PrivacyPolicy(),
                            TermsOfUse(),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.only(bottom: 10),
        child: Padding(
          padding: const EdgeInsets.only(bottom: 10, left: 20, right: 20),
          child: Obx(
            () => Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Material(
                  borderRadius: kEnabledBorderRadius,
                  color: Colors.white,
                  elevation: 6,
                  shadowColor: kAppColor.withAlpha(200),
                  borderOnForeground: true,
                  child: InkWell(
                    splashColor: Colors.white,
                    splashFactory: InkRipple.splashFactory,
                    borderRadius: kEnabledBorderRadius,
                    onTap: () async {
                      bool decision = await showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (_) => AlertDialog(
                          title: Text(
                            'attention'.tr,
                            style: const TextStyle(color: kAppColor, fontSize: 25),
                          ),
                          content: Text('disagree_pop_up_msg'.tr),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                          actions: <Widget>[
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                              child: GestureDetector(
                                child: Container(
                                    constraints: const BoxConstraints(minWidth: 75, maxHeight: 35, minHeight: 35),
                                    decoration: BoxDecoration(color: kAppColor.withAlpha(200), borderRadius: BorderRadius.circular(5), boxShadow: [BoxShadow(color: kAppColor.withAlpha(128), offset: const Offset(0, 2), blurRadius: 6)]),
                                    child: Center(child: Text('agree_wterms'.tr, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white)))),
                                onTap: () => Navigator.of(context).pop(true),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                              ),
                              child: GestureDetector(
                                  child: Container(
                                      constraints: const BoxConstraints(minWidth: 75, maxHeight: 35, minHeight: 35),
                                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(5), border: Border.all(color: kAppColor.withAlpha(200), width: 1), boxShadow: [BoxShadow(color: kAppColor.withAlpha(100), offset: const Offset(0, 2), blurRadius: 4)]),
                                      child: Center(child: Text('refund'.tr, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: kAppColor.withAlpha(200))))),
                                  onTap: () => Navigator.of(context).pop(false)),
                            ),
                          ],
                        ),
                      );
                      if (decision == false) {
                        _launchEmailApp(context);
                        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
                      } else if (decision == true) {
                        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const QuestionnaireScreen()));
                      }
                    },
                    child: Container(
                      width: 110,
                      height: 35,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: kEnabledBorderRadius,
                        border: Border.all(color: kAppColor),
                      ),
                      child: Text(
                        'disagree'.tr,
                        style: const TextStyle(
                          color: kAppColor,
                          fontWeight: FontWeight.w500,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ),
                ),
                Material(
                  borderRadius: kEnabledBorderRadius,
                  color: atEnd.value ? kAppColor.withAlpha(200) : Colors.grey.withAlpha(120),
                  elevation: 6,
                  shadowColor: atEnd.value ? kAppColor.withAlpha(200) : Colors.transparent,
                  child: InkWell(
                    splashColor: Colors.white,
                    splashFactory: InkRipple.splashFactory,
                    borderRadius: kEnabledBorderRadius,
                    onTap: atEnd.value
                        ? () async {
                            Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const QuestionnaireScreen()));
                          }
                        : null,
                    child: Container(
                      width: 110,
                      height: 35,
                      alignment: Alignment.center,
                      child: Text(
                        'agree'.tr,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _launchEmailApp(BuildContext context) async {
    final String url = 'mailto:$kAppEmail?subject=Detox%20App%20Refund';
    if (await canLaunch(url)) {
      await launch(
        url,
        forceSafariVC: false,
        forceWebView: false,
      );
    } else {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext _) => ShowDialog(
          title: 'error'.tr,
          alertMessage: 'no_emailapp_found'.tr,
        ),
      );
    }
  }
}
