import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';

import '../components/home_menu_button.dart';
import '../components/home_screen_tabs/forum_tab.dart';
import '../components/home_screen_tabs/methods_tab.dart';
import '../components/home_screen_tabs/practices_tab.dart';
import '../components/home_screen_tabs/recipes_tab.dart';
import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/questionnaire_model.dart';
import '../settings/preferences.dart';
import '../utils/app_helpers.dart';
import '../utils/utils.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final AppStateController _controller = AppStateController.controller;
  late TabController _tabController;
  @override
  void initState() {
    _tabController = TabController(length: _tabs.length, vsync: this);
    showAnnouncements();
    super.initState();
  }

  final List<Widget> _tabs = [
    MethodsTab(),
    PracticesTab(),
    const RecipesTab(),
    const ForumTab(),
  ];

  Widget getAppBarWidget() {
    Widget abChild;
    if (DateTime.now().isBefore(_controller.userModel.value.userBatch!.startingDate)) {
      final DateTime prepDate = _controller.userModel.value.userBatch!.startingDate.subtract(Duration(days: Questionnaire.coffeeOptions[_controller.userModel.value.userQuestionnaire!.cupsOfCoffee]!));
      if (DateTime.now().isBefore(prepDate)) {
        abChild = Row(
          children: [
            Text('prep_strt_info'.tr, style: kSelectedTextStyle),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: kFocusedBorderRadius,
              ),
              child: Text(
                getBatchDate(prepDate),
                style: kUnselectedTextStyle,
              ),
            ),
          ],
        );
      } else if (DateTime.now().isAfter(prepDate)) {
        Duration diff = DateTime.now().difference(prepDate);
        abChild = abChild = Row(
          children: [
            Text('prep_day'.tr, style: kAppBarAppNameStyle.copyWith(fontSize: 20)),
            Text(
              '${diff.inDays + 1}',
              textDirection: TextDirection.ltr,
              style: kAppBarAppNameStyle.copyWith(fontSize: 20, fontWeight: FontWeight.w600),
            ),
            Text(' | ' + 'detox_on'.tr, style: kAppBarAppNameStyle.copyWith(fontSize: 20)),
            Text(
              getDateString(_controller.userModel.value.userBatch!.startingDate),
              textDirection: TextDirection.ltr,
              style: kAppBarAppNameStyle.copyWith(fontSize: 20, fontWeight: FontWeight.w600),
            ),
          ],
        );
      } else {
        abChild = Row(
          children: [
            Text('batch_strt_info'.tr, style: kSelectedTextStyle),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: kFocusedBorderRadius,
              ),
              child: Text(
                getBatchDate(_controller.userModel.value.userBatch!.startingDate),
                style: kUnselectedTextStyle,
              ),
            ),
          ],
        );
      }
    } else if (!_controller.userModel.value.userBatch!.isExpired) {
      abChild = Row(
        children: [
          Text('stage'.tr, style: kAppBarAppNameStyle.copyWith(fontSize: 20)),
          Container(
            height: 32,
            width: 40,
            alignment: Alignment.center,
            margin: const EdgeInsets.only(left: 5, right: 5),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: kFocusedBorderRadius,
            ),
            child: Text(
              '${_controller.userModel.value.userBatch!.currentPhase}',
              style: kUnselectedTextStyle.copyWith(fontSize: 20, fontWeight: FontWeight.w600),
            ),
          ),
          Text('day'.tr, style: kAppBarAppNameStyle.copyWith(fontSize: 20)),
          Container(
            height: 32,
            width: 40,
            alignment: Alignment.center,
            margin: const EdgeInsets.only(left: 5),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: kFocusedBorderRadius,
            ),
            child: Text(
              '${_controller.userModel.value.userBatch!.currentDay}',
              style: kUnselectedTextStyle.copyWith(fontSize: 20, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      );
    } else if (_controller.userModel.value.userBatch!.isExpired) {
      abChild = Row(
        children: [
          Text('cntnt_avbl_info'.tr, style: kSelectedTextStyle),
          Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: kFocusedBorderRadius,
            ),
            child: Text(
              getBatchDate(_controller.userModel.value.userBatch!.after30),
              style: kUnselectedTextStyle,
            ),
          ),
        ],
      );
    } else {
      abChild = const Text('21d Detox', style: kAppBarAppNameStyle);
    }
    return abChild;
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        shadowColor: kAppColor,
        backgroundColor: kAppColor,
        title: FittedBox(child: getAppBarWidget()),
        actions: [
          HomeMenuButton(),
        ],
      ),
      body: SizedBox(
        height: size.height,
        width: size.width,
        child: Column(
          children: [
            Container(
              color: Colors.white,
              height: 40,
              width: size.width,
              child: TabBar(
                controller: _tabController,
                indicatorSize: TabBarIndicatorSize.tab,
                indicatorPadding: const EdgeInsets.symmetric(horizontal: 20),
                indicatorColor: kAppColor.withAlpha(150),
                labelColor: kDarkBlue,
                unselectedLabelColor: kDarkBlue.withAlpha(150),
                labelPadding: const EdgeInsets.symmetric(horizontal: 15),
                labelStyle: kIndicatorStyle,
                unselectedLabelStyle: const TextStyle(fontSize: 13, fontFamily: 'Trajan'),
                tabs: [
                  Tab(text: 'method'.tr),
                  Tab(text: 'practice'.tr),
                  Tab(text: 'recipes'.tr),
                  Tab(text: 'amigos'.tr),
                ],
              ),
            ),
            Flexible(
              child: NotificationListener<OverscrollIndicatorNotification>(
                onNotification: (OverscrollIndicatorNotification _notification) {
                  _notification.disallowGlow();
                  return true;
                },
                child: TabBarView(
                  controller: _tabController,
                  children: _tabs,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  showAnnouncements() async {
    if (await InternetConnectionChecker().hasConnection) {
      if (await Preferences.showAnnouncements()) {
        await getAnnouncements(context, isFirst: true);
      }
    }
  }
}
