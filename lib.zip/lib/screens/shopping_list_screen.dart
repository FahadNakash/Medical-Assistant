import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/shopping_item_model.dart';
import '../models/user_model.dart';
import '../services/firestore_helper.dart';

class ShoppingListScreen extends StatelessWidget {
  ShoppingListScreen({Key? key}) : super(key: key);
  final AppStateController _controller = AppStateController.controller;

  List<ShoppingItem> getFilteredShoppingList() {
    List<ShoppingItem> filteredShoppingList = [];
    UserModel user = _controller.userModel.value;
    if (user.userBatch != null) {
      for (var shoppingItem in _controller.shoppingList) {
        if (!user.userBatch!.isExpired && user.userBatch!.isAvailableAfter) {
          if (shoppingItem.days.any((element) => element == user.userBatch!.currentDay)) {
            for (String userCategory in shoppingItem.userCategories) {
              if (user.userQuestionnaire!.hasDiabetes) {
                if (userCategory == diabetes && shoppingItem.locale == _controller.appLocale.value) {
                  filteredShoppingList.add(shoppingItem);
                  break;
                }
              } else if (user.userQuestionnaire!.hasWeightLoss) {
                if (userCategory == weightLoss && shoppingItem.locale == _controller.appLocale.value) {
                  filteredShoppingList.add(shoppingItem);
                  break;
                }
              } else {
                if (user.userQuestionnaire!.purpose.contains(userCategory) && shoppingItem.locale == _controller.appLocale.value) {
                  filteredShoppingList.add(shoppingItem);
                  break;
                }
              }
            }
          }
        } else if (user.userBatch!.isExpired && user.userBatch!.isAvailableAfter) {
          if (shoppingItem.days.contains(21)) {
            for (String userCategory in shoppingItem.userCategories) {
              if (user.userQuestionnaire!.hasDiabetes) {
                if (userCategory == diabetes && shoppingItem.locale == _controller.appLocale.value) {
                  filteredShoppingList.add(shoppingItem);
                  break;
                }
              } else if (user.userQuestionnaire!.hasWeightLoss) {
                if (userCategory == weightLoss && shoppingItem.locale == _controller.appLocale.value) {
                  filteredShoppingList.add(shoppingItem);
                  break;
                }
              } else {
                if (user.userQuestionnaire!.purpose.contains(userCategory) && shoppingItem.locale == _controller.appLocale.value) {
                  filteredShoppingList.add(shoppingItem);
                  break;
                }
              }
            }
          }
        }
      }
    }
    filteredShoppingList.sort((ShoppingItem a, ShoppingItem b) => b.dateCreated.compareTo(a.dateCreated));
    return filteredShoppingList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        shadowColor: kAppColor,
        backgroundColor: kAppColor,
        title: Text(
          'shopping_list'.tr,
          style: const TextStyle(color: Colors.white),
        ),
      ),
      body: GetBuilder(builder: (AppStateController controller) {
        return StreamBuilder<QuerySnapshot>(
          stream: FirestoreHelper.shoppingListRef.snapshots().distinct(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              List<ShoppingItem> temp = [];
              for (var element in snapshot.data?.docs ?? []) {
                temp.add(ShoppingItem.fromMap(element.data() as Map<String, dynamic>));
              }
              _controller.setShoppingList(temp);
            }
            List<ShoppingItem> userShoppingList = getFilteredShoppingList();
            List<Widget> listViewWidgets = [];
            for (var itemCategory in ShoppingItem.itemCategoriesList) {
              List<ShoppingItem> categoryItemsList = userShoppingList.where((ShoppingItem item) => item.itemCategory == itemCategory).toList();
              listViewWidgets.add(
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  child: Text(
                    itemCategory.toLowerCase().tr + ':',
                    style: kIndicatorStyle.copyWith(fontSize: 20, decoration: TextDecoration.underline),
                  ),
                ),
              );
              listViewWidgets.add(categoryItemsList.isNotEmpty
                  ? Container(
                      width: MediaQuery.of(context).size.width,
                      margin: const EdgeInsets.symmetric(horizontal: 10),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: kAppColor.withAlpha(20),
                        borderRadius: kFocusedBorderRadius,
                      ),
                      child: Wrap(
                        alignment: WrapAlignment.center,
                        children: [
                          for (ShoppingItem item in categoryItemsList)
                            Container(
                              padding: kRecipePadding,
                              margin: kRecipeMargin,
                              decoration: kSelectedBoxDecoration,
                              child: Text(
                                item.name,
                                textAlign: TextAlign.center,
                                textDirection: item.locale == kEnglishLocale ? TextDirection.ltr : TextDirection.rtl,
                                style: kSelectedTextStyle,
                              ),
                            ),
                        ],
                      ),
                    )
                  : Container(
                      padding: const EdgeInsets.all(15),
                      margin: const EdgeInsets.only(left: 15, right: 15, bottom: 15),
                      decoration: BoxDecoration(
                        color: kAppColor.withAlpha(20),
                        borderRadius: kFocusedBorderRadius,
                      ),
                      child: Text(
                        'no_item_txt'.tr,
                        style: kUnselectedTextStyle,
                        textAlign: TextAlign.center,
                      ),
                    ));
            }
            return NotificationListener<OverscrollIndicatorNotification>(
              onNotification: (OverscrollIndicatorNotification _notification) {
                _notification.disallowGlow();
                return true;
              },
              child: ListView(
                children: listViewWidgets,
              ),
            );
          },
        );
      }),
    );
  }
}
