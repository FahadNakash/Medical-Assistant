import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:url_launcher/url_launcher.dart';

import '../components/confirmation_dialog.dart';
import '../components/empty_app_bar.dart';
import '../components/language_selector_dropdown.dart';
import '../components/questionnaire_slides/batch_selection_slide.dart';
import '../components/questionnaire_slides/coffee_cups_slide.dart';
import '../components/questionnaire_slides/detox_conditions_slide.dart';
import '../components/questionnaire_slides/detox_purpose_slide.dart';
import '../components/questionnaire_slides/ending_slide.dart';
import '../components/questionnaire_slides/personal_details_slide.dart';
import '../components/questionnaire_slides/starting_slide.dart';
import '../components/select_image_bottom_sheet.dart';
import '../components/show_dialog.dart';
import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/batch_model.dart';
import '../models/questionnaire_model.dart';
import '../models/user_model.dart';
import '../services/firestore_helper.dart';
import '../services/storage_helper.dart';
import '../settings/preferences.dart';
import '../utils/utils.dart';
import 'phone_login_screen.dart';
import 'welcome_screen.dart';

class QuestionnaireScreen extends StatefulWidget {
  const QuestionnaireScreen({Key? key}) : super(key: key);
  @override
  _QuestionnaireScreenState createState() => _QuestionnaireScreenState();
}

class _QuestionnaireScreenState extends State<QuestionnaireScreen> {
  final PageController _pageController = PageController();
  final AppStateController _appController = AppStateController.controller;
  int currentPage = 0;
  bool showIndicator = false;
  final Questionnaire _userQuestionnaire = Questionnaire();
  Batch? _userBatch;
  String? batchErrorText;
  String? fNameErrorText;
  String? lNameErrorText;
  String? heightErrorText;
  String? weightErrorText;
  String? purposeErrorText;
  String? dobErrorText;
  String? isFemaleErrTxt;
  String? coffeeErrTxt;
  late DateTime maximumDate;
  bool notPregnant = false;
  bool notBFeeding = false;
  bool noChemo = false;
  bool noInflame = false;
  bool responsibility = false;
  bool fillLater = false;
  File? profileImage;

  @override
  void initState() {
    String now = DateTime.now().toString().split(' ')[0];
    String initial = now.splitMapJoin(now.split('-').first, onMatch: (m) => '${int.parse(m[0]!) - 18}');
    maximumDate = DateTime.parse(initial);
    _userQuestionnaire.userID = _appController.userModel.value.userID;
    _userQuestionnaire.purpose = [];
    super.initState();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  _validateFields() {
    if (_userQuestionnaire.fName.isEmpty) {
      fNameErrorText = 'required_field_err'.tr;
    } else {
      fNameErrorText = null;
    }
    if (_userQuestionnaire.lName.isEmpty) {
      lNameErrorText = 'required_field_err'.tr;
    } else {
      lNameErrorText = null;
    }
    if (_userQuestionnaire.dob == null) {
      dobErrorText = 'required_field_err'.tr;
    } else if (_userQuestionnaire.dob?.isAfter(maximumDate) ?? true) {
      dobErrorText = 'under_age_err'.tr;
    } else {
      dobErrorText = null;
    }
    if (_userQuestionnaire.isFemale == null) {
      isFemaleErrTxt = 'slct_one_err'.tr;
    } else {
      isFemaleErrTxt = null;
    }
    if (!fillLater) {
      if (_userQuestionnaire.height == null) {
        heightErrorText = 'required_field_err'.tr;
      } else {
        heightErrorText = null;
      }
      if (_userQuestionnaire.weight == null) {
        weightErrorText = 'required_field_err'.tr;
      } else {
        weightErrorText = null;
      }
    } else {
      heightErrorText = null;
      weightErrorText = null;
    }
    setState(() {});
  }

  Widget slideNavigators() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Material(
          borderRadius: kEnabledBorderRadius,
          color: kAppColor.withAlpha(200),
          elevation: 6,
          shadowColor: kAppColor.withAlpha(200),
          child: InkWell(
            splashColor: Colors.white,
            splashFactory: InkRipple.splashFactory,
            borderRadius: kEnabledBorderRadius,
            onTap: showIndicator
                ? null
                : () {
                    _pageController.previousPage(duration: slideDuration, curve: slideCurve);
                  },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 7),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  RotatedBox(
                    quarterTurns: _appController.appLocale.value == kEnglishLocale ? 1 : 3,
                    child: SvgPicture.asset('$assets/icon-arrow_down.svg', color: Colors.white, height: 7),
                  ),
                  const SizedBox(width: 5),
                  Text('previous'.tr, style: const TextStyle(fontSize: 16, color: Colors.white)),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 15),
        currentPage != 6
            ? Material(
                borderRadius: kEnabledBorderRadius,
                color: kAppColor.withAlpha(200),
                elevation: 6,
                shadowColor: kAppColor.withAlpha(200),
                child: InkWell(
                  splashColor: Colors.white,
                  splashFactory: InkRipple.splashFactory,
                  borderRadius: kEnabledBorderRadius,
                  onTap: showIndicator
                      ? null
                      : () {
                          FocusScope.of(context).unfocus();
                          if (currentPage == 1) {
                            _validateFields();
                            if (fNameErrorText == null && lNameErrorText == null && dobErrorText == null && isFemaleErrTxt == null && heightErrorText == null && weightErrorText == null) {
                              _pageController.nextPage(duration: slideDuration, curve: slideCurve);
                            } else if (dobErrorText == 'under_age_err'.tr) {
                              showDialog(context: context, builder: (_) => ConfirmationDialog(title: 'attention'.tr, alertMessage: 'under_age_pop_up'.tr, confirmLabel: 'refund'.tr)).then((decision) {
                                if (decision == true) {
                                  _launchEmailApp(context);
                                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
                                }
                              });
                            }
                          } else if (currentPage == 2) {
                            if ((!notPregnant && _userQuestionnaire.isFemale!) || (!notBFeeding && _userQuestionnaire.isFemale!) || !noChemo || !noInflame || !responsibility) {
                              showDialog(context: context, builder: (_) => ConfirmationDialog(title: 'attention'.tr, alertMessage: 'q2_slide_ineligible'.tr, confirmLabel: 'refund'.tr)).then((decision) {
                                if (decision == true) {
                                  _launchEmailApp(context);
                                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
                                }
                              });
                            } else {
                              _pageController.nextPage(duration: slideDuration, curve: slideCurve);
                            }
                          } else if (currentPage == 3) {
                            if (_userQuestionnaire.purpose.isEmpty) {
                              purposeErrorText = 'slct_one_err'.tr;
                              setState(() {});
                            } else {
                              purposeErrorText = null;
                              setState(() {});
                              _pageController.nextPage(duration: slideDuration, curve: slideCurve);
                            }
                          } else if (currentPage == 4) {
                            if (_userQuestionnaire.cupsOfCoffee == null) {
                              coffeeErrTxt = 'slct_one_err'.tr;
                              setState(() {});
                            } else {
                              coffeeErrTxt = null;
                              setState(() {});
                              _pageController.nextPage(duration: slideDuration, curve: slideCurve);
                            }
                          } else if (currentPage == 5) {
                            if (_userBatch != null) {
                              _pageController.nextPage(duration: slideDuration, curve: slideCurve);
                            } else {
                              batchErrorText = 'batch_err_txt'.tr;
                            }
                            setState(() {});
                          } else {
                            _pageController.nextPage(duration: slideDuration, curve: slideCurve);
                          }
                        },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 7),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'next'.tr,
                          style: const TextStyle(fontSize: 16, color: Colors.white),
                        ),
                        const SizedBox(width: 5),
                        RotatedBox(
                          quarterTurns: _appController.appLocale.value == kEnglishLocale ? 3 : 1,
                          child: SvgPicture.asset('$assets/icon-arrow_down.svg', color: Colors.white, height: 7),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            : const SizedBox(width: 47),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: const EmptyAppBar(kAppColor),
      body: SizedBox(
        height: size.height - MediaQuery.of(context).viewPadding.top,
        width: size.width,
        child: Column(
          children: [
            Container(
              height: 60,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  LanguageSelectorDropdown(),
                  currentPage != 0 ? slideNavigators() : const SizedBox(),
                ],
              ),
            ),
            Expanded(
              child: SizedBox(
                child: PageView(
                  controller: _pageController,
                  physics: const NeverScrollableScrollPhysics(),
                  onPageChanged: (int page) {
                    setState(() {
                      currentPage = page;
                    });
                  },
                  children: [
                    StartingSlide(pageController: _pageController),
                    PersonalDetailsSlide(
                      fName: _userQuestionnaire.fName,
                      fNameErrorText: fNameErrorText,
                      fNameCallback: (String value) {
                        _userQuestionnaire.fName = value.trim();
                        if (fNameErrorText != null) _validateFields();
                      },
                      lName: _userQuestionnaire.lName,
                      lNameErrorText: lNameErrorText,
                      lNameCallback: (String value) {
                        _userQuestionnaire.lName = value.trim();
                        if (lNameErrorText != null) _validateFields();
                      },
                      dobErrorText: dobErrorText,
                      maximumDate: maximumDate,
                      dobCallback: (DateTime value) {
                        _userQuestionnaire.dob = value;
                        if (dobErrorText != null) _validateFields();
                      },
                      height: _userQuestionnaire.height,
                      heightErrorText: heightErrorText,
                      heightCallback: (num? value) {
                        _userQuestionnaire.height = value;
                        if (heightErrorText != null) _validateFields();
                      },
                      weight: _userQuestionnaire.weight,
                      weightErrorText: weightErrorText,
                      weightCallback: (num? value) {
                        _userQuestionnaire.weight = value;
                        if (weightErrorText != null) _validateFields();
                      },
                      isMetric: _userQuestionnaire.isMetric,
                      isMetricCallback: (bool val) => _userQuestionnaire.isMetric = val,
                      isFemale: _userQuestionnaire.isFemale,
                      isFemaleErrTxt: isFemaleErrTxt,
                      isFemaleCallback: (bool val) {
                        _userQuestionnaire.isFemale = val;
                        if (isFemaleErrTxt != null) _validateFields();
                      },
                      fillLater: fillLater,
                      fillLaterCallback: (bool val) {
                        fillLater = val;
                      },
                      image: profileImage,
                      onImgSelect: () async {
                        ImageSource? src = await showModalBottomSheet(shape: const RoundedRectangleBorder(borderRadius: kTLRBorderRadius), context: context, builder: (_) => const SelectImageBottomSheet());
                        if (src != null) {
                          final XFile? _pickedFile = await ImagePicker().pickImage(source: src, imageQuality: 50, maxHeight: 500, maxWidth: 500);
                          if (_pickedFile != null) {
                            setState(() {
                              profileImage = File(_pickedFile.path);
                            });
                          }
                        }
                      },
                    ),
                    DetoxConditionsSlide(
                      notPregnant: notPregnant,
                      notPregnantCallback: (bool val) => notPregnant = val,
                      notBFeeding: notBFeeding,
                      notBFeedingCallback: (bool val) => notBFeeding = val,
                      noChemo: noChemo,
                      noChemoCallback: (bool val) => noChemo = val,
                      noInflame: noInflame,
                      noInflameCallback: (bool val) => noInflame = val,
                      responsibility: responsibility,
                      responsibilityCallback: (bool val) => responsibility = val,
                      isFemale: _userQuestionnaire.isFemale,
                    ),
                    DetoxPurposeSlide(
                      data: _userQuestionnaire.purpose,
                      errorText: purposeErrorText == null ? null : 'slct_one_err'.tr,
                      onTap: (String option) {
                        if (_userQuestionnaire.purpose.contains(option)) {
                          _userQuestionnaire.purpose.remove(option);
                        } else {
                          _userQuestionnaire.purpose.add(option);
                        }
                        if (purposeErrorText != null) {
                          if (_userQuestionnaire.purpose.isEmpty) {
                            purposeErrorText = 'slct_one_err'.tr;
                          } else {
                            purposeErrorText = null;
                          }
                        }
                        setState(() {});
                      },
                    ),
                    CoffeeCupsSlide(
                      cupsOfCoffee: _userQuestionnaire.cupsOfCoffee,
                      coffeeErrTxt: coffeeErrTxt,
                      onChanged: (String val) {
                        _userQuestionnaire.cupsOfCoffee = val;
                        _userBatch = null;
                        _appController.userModel.value.userBatch = null;
                        _appController.setUser(_appController.userModel.value);
                        if (coffeeErrTxt != null) {
                          if (_userQuestionnaire.cupsOfCoffee == null) {
                            coffeeErrTxt = 'slct_one_err'.tr;
                          } else {
                            coffeeErrTxt = null;
                          }
                        }
                        setState(() {});
                      },
                    ),
                    BatchSelectionSlide(
                      prepDays: Questionnaire.coffeeOptions[_userQuestionnaire.cupsOfCoffee],
                      errorText: batchErrorText == null ? null : 'batch_err_txt'.tr,
                      onTap: (Batch batch) async {
                        bool proceed = await showDialog(
                            context: context,
                            builder: (_) => ConfirmationDialog(
                                  title: 'attention'.tr,
                                  alertMessage: 'batch_confirmation'.trArgs([batch.name, getBatchDate(batch.startingDate), getBatchDate(batch.endingDate)]),
                                ));
                        if (proceed) {
                          _userBatch = batch;
                          _appController.userModel.value.userBatch = batch;
                          _appController.setUser(_appController.userModel.value);
                          batchErrorText = null;
                          setState(() {});
                        }
                      },
                    ),
                    EndingSlide(
                      userBatch: _userBatch,
                      fillLater: fillLater,
                      pageController: _pageController,
                      showIndicator: showIndicator,
                      onSubmit: () async {
                        setState(() {
                          showIndicator = true;
                        });
                        try {
                          if (await InternetConnectionChecker().hasConnection) {
                            if (_userQuestionnaire.height != null && _userQuestionnaire.weight != null) {
                              num bmi;
                              if (_userQuestionnaire.isMetric) {
                                bmi = getMetricBMI(_userQuestionnaire.height!.toInt(), _userQuestionnaire.weight!.toInt());
                              } else {
                                bmi = getImperialBMI(_userQuestionnaire.height!.toInt(), _userQuestionnaire.weight!.toInt());
                              }
                              _userQuestionnaire.bmiList.add({DateTime.now().toString(): bmi});
                            }
                            UserModel user = _appController.userModel.value;
                            user.userQuestionnaire = _userQuestionnaire;
                            user.fName = _userQuestionnaire.fName;
                            user.lName = _userQuestionnaire.lName;
                            if (profileImage != null) {
                              String imageName = user.userID + '.' + profileImage!.path.split('.').last;
                              String url = await StorageHelper.uploadProfileImage(imageName: imageName, imageFile: profileImage!);
                              user.userImgName = imageName;
                              user.userImgUrl = url;
                            }
                            _appController.setUser(user);
                            await Preferences.saveUserSession(user);
                            await FirestoreHelper.saveUserFirestore(user);
                            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const WelcomeScreen()));
                          } else {
                            showDialog(context: context, builder: (_) => ShowDialog(alertMessage: 'no_conn_err'.tr));
                          }
                        } catch (e) {
                          setState(() {
                            showIndicator = false;
                          });
                          await showDialog(context: context, builder: (_) => ShowDialog(alertMessage: 'otp_request_err'.tr));
                          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
                        }
                      },
                      userQuestionnaire: _userQuestionnaire,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _launchEmailApp(BuildContext context) async {
    final String url = 'mailto:$kAppEmail?subject=Detox%20App%20Refund';
    if (await canLaunch(url)) {
      await launch(
        url,
        forceSafariVC: false,
        forceWebView: false,
      );
    } else {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext _) => ShowDialog(
          title: 'error'.tr,
          alertMessage: 'no_emailapp_found'.tr,
        ),
      );
    }
  }
}
