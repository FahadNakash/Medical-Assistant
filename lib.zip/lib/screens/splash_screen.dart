import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:transparent_image/transparent_image.dart';

import '../components/empty_app_bar.dart';
import '../components/show_dialog.dart';
import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/user_model.dart';
import '../settings/preferences.dart';
import 'home_screen.dart';
import 'phone_login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    Future.delayed(const Duration(seconds: 3), () async {
      final AppStateController _appController = AppStateController.controller;
      _appController.setAppLocale(Preferences.getAppLocale());
      // if (true) {
      //   Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const QuestionnaireScreen()));
      //   return;
      // }
      final UserModel? user = Preferences.loadUserSession();
      if (user != null) {
        if (user.userBatch != null) {
          if (user.userBatch!.isAvailableAfter) {
            _appController.setUser(user);
            _appController.setWatchedVideos(Preferences.getWatchedVideos());
            _appController.setInitMethods(Preferences.getInitMethods());
            _appController.setInitPractices(Preferences.getInitPractices());
            _appController.setInitRecipes(Preferences.getInitRecipes());
            _appController.setShoppingList(Preferences.getShoppingList());
            Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const HomeScreen()));
          } else {
            Preferences.deleteUserSession();
            await showDialog(
                context: context,
                builder: (_) => ShowDialog(
                      alertMessage: 'program_end_msg'.tr,
                    ));
            Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
          }
        } else {
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
        }
      } else {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const PhoneLoginScreen()));
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: const EmptyAppBar(kAppColor),
      body: SafeArea(
        child: Container(
          padding: const EdgeInsets.only(top: 50, bottom: 10),
          height: size.height,
          width: size.width,
          alignment: Alignment.center,
          color: Colors.white,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                children: [
                  Hero(
                    tag: 'Logo',
                    child: SizedBox(
                      height: 270,
                      width: 270,
                      child: FadeInImage(
                        fadeInDuration: const Duration(milliseconds: 600),
                        fadeInCurve: Curves.easeInToLinear,
                        placeholder: MemoryImage(kTransparentImage),
                        image: const AssetImage(
                          '$assets/detox_logo.png',
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'splash_welcome'.tr,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 28,
                      fontFamily: 'Trajan',
                      fontWeight: FontWeight.w600,
                      color: kAppColor.withAlpha(230),
                    ),
                  ),
                ],
              ),
              Text(
                'copyright_text'.trArgs([DateTime.now().year.toString()]),
                style: const TextStyle(fontSize: 10, color: kAppColor),
              )
            ],
          ),
        ),
      ),
    );
  }
}
