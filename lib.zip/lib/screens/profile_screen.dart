import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../components/custom_text_field.dart';
import '../components/profile_selector.dart';
import '../components/select_image_bottom_sheet.dart';
import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/user_model.dart';
import '../services/firestore_helper.dart';
import '../services/storage_helper.dart';
import '../settings/preferences.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen(this.user, {Key? key}) : super(key: key);
  final UserModel user;

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  File? _profileImage;
  bool _showIndicator = false;
  String? _fNameErr;
  String? _lNameErr;
  late final TextEditingController _fNameController;
  late final TextEditingController _lNameController;
  bool isMetric = true;
  final TextStyle unselectedStyle = const TextStyle(fontSize: 16, color: Colors.black54);
  final TextStyle selectedStyle = const TextStyle(fontSize: 17, color: Colors.white, fontWeight: FontWeight.w600);

  @override
  void initState() {
    super.initState();
    _fNameController = TextEditingController(text: widget.user.fName);
    _lNameController = TextEditingController(text: widget.user.lName);
    isMetric = widget.user.userQuestionnaire?.isMetric ?? true;
  }

  @override
  void dispose() {
    super.dispose();
    _fNameController.dispose();
    _lNameController.dispose();
  }

  Widget getOption(String key) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      decoration: kSelectedBoxDecoration,
      child: Text(
        key.tr,
        style: kSelectedTextStyle,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final String locale = Get.locale!.languageCode + '_' + Get.locale!.countryCode!;
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: kAppColor,
        title: Text(
          'profile'.tr,
          style: const TextStyle(color: Colors.white),
        ),
        actions: [
          GestureDetector(
            onTap: updateUserProfile,
            child: Container(
              color: kAppColor,
              height: 25,
              width: 25,
              margin: const EdgeInsets.symmetric(horizontal: 10),
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: _showIndicator
                  ? const CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation(Colors.white),
                    )
                  : const Icon(
                      Icons.save,
                      color: Colors.white,
                    ),
            ),
          ),
        ],
      ),
      body: SizedBox(
        width: size.width,
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 10),
              ProfileSelector(
                userImgUrl: widget.user.userImgUrl,
                image: _profileImage,
                onSelect: getProfileImage,
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: CustomTextField(
                  height: 55,
                  width: size.width * 0.85,
                  readOnly: _showIndicator,
                  textController: _fNameController,
                  contentPadding: const EdgeInsets.only(left: 20, right: 20, bottom: 5),
                  labelText: 'f_name'.tr,
                  helperText: "",
                  errorText: _fNameErr,
                  textInputAction: TextInputAction.done,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: CustomTextField(
                  height: 55,
                  width: size.width * 0.85,
                  readOnly: _showIndicator,
                  textController: _lNameController,
                  contentPadding: const EdgeInsets.only(left: 20, right: 20, bottom: 5),
                  labelText: 'l_name'.tr,
                  helperText: "",
                  errorText: _lNameErr,
                  textInputAction: TextInputAction.done,
                ),
              ),
              const SizedBox(height: 20),
              Container(
                height: 35,
                width: 180,
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: isMetric ? kAppColor.withAlpha(220) : Colors.white,
                          borderRadius: locale == kEnglishLocale ? const BorderRadius.only(topLeft: Radius.circular(25), bottomLeft: Radius.circular(25)) : const BorderRadius.only(topRight: Radius.circular(25), bottomRight: Radius.circular(25)),
                        ),
                        alignment: Alignment.center,
                        child: Text('metric'.tr, style: isMetric ? selectedStyle : unselectedStyle),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: !isMetric ? kAppColor.withAlpha(220) : Colors.white,
                          borderRadius: locale == kEnglishLocale ? const BorderRadius.only(topRight: Radius.circular(25), bottomRight: Radius.circular(25)) : const BorderRadius.only(topLeft: Radius.circular(25), bottomLeft: Radius.circular(25)),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'imperial'.tr,
                          style: isMetric ? unselectedStyle : selectedStyle,
                        ),
                      ),
                    ),
                  ],
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  border: Border.all(
                    color: kAppColor.withAlpha(220),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Column(
                        children: [
                          Text(
                            'q1_slide_height'.tr,
                            style: kPropertyStyle,
                          ),
                          const SizedBox(height: 5),
                          Container(
                            width: 70,
                            alignment: Alignment.center,
                            margin: const EdgeInsets.symmetric(horizontal: 5),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: const Color(0xffF5F6EC),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              '${widget.user.userQuestionnaire?.height ?? '??'}',
                              style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w500, fontSize: 25),
                            ),
                          ),
                        ],
                      ),
                      Container(width: 30, alignment: Alignment.bottomLeft, height: 40, child: Text(isMetric ? 'cm'.tr : 'inch'.tr, style: const TextStyle(fontWeight: FontWeight.w600))),
                    ],
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Column(
                        children: [
                          Text(
                            'q1_slide_weight'.tr,
                            style: kPropertyStyle,
                          ),
                          const SizedBox(height: 5),
                          Container(
                            width: 70,
                            alignment: Alignment.center,
                            margin: const EdgeInsets.symmetric(horizontal: 5),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: const Color(0xffF5F6EC),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              '${widget.user.userQuestionnaire?.weight ?? '??'}',
                              style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w500, fontSize: 25),
                            ),
                          ),
                        ],
                      ),
                      Container(width: 30, alignment: Alignment.bottomLeft, height: 40, child: Text(isMetric ? 'cm'.tr : 'inch'.tr, style: const TextStyle(fontWeight: FontWeight.w600))),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: size.width * 0.8,
                child: Text(
                  'your_goals'.tr,
                  textAlign: TextAlign.center,
                  style: kHeading2Style,
                ),
              ),
              const SizedBox(height: 20),
              Wrap(
                alignment: WrapAlignment.center,
                children: [
                  if (widget.user.userQuestionnaire?.purpose.contains('Blood Pressure') ?? false) getOption('blood_pressure'),
                  if (widget.user.userQuestionnaire?.purpose.contains('Cholesterol') ?? false) getOption('cholesterol'),
                  if (widget.user.userQuestionnaire?.purpose.contains('Diabetes') ?? false) getOption('diabetes'),
                  if (widget.user.userQuestionnaire?.purpose.contains('Weight Loss') ?? false) getOption('weight_loss'),
                  if (widget.user.userQuestionnaire?.purpose.contains('Fertility/Family Planning') ?? false) getOption('family_planning'),
                  if (widget.user.userQuestionnaire?.purpose.contains('Lifestyle') ?? false) getOption('lifestyle'),
                ],
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> getProfileImage() async {
    ImageSource? src = await showModalBottomSheet(shape: const RoundedRectangleBorder(borderRadius: kTLRBorderRadius), context: context, builder: (_) => const SelectImageBottomSheet());
    if (src != null) {
      final XFile? _pickedFile = await ImagePicker().pickImage(source: src, imageQuality: 50, maxHeight: 500, maxWidth: 500);
      if (_pickedFile != null) {
        setState(() {
          _profileImage = File(_pickedFile.path);
        });
      }
    }
  }

  updateUserProfile() async {
    setState(() {
      _showIndicator = true;
    });
    try {
      final AppStateController _appController = AppStateController.controller;
      widget.user.fName = _fNameController.text;
      widget.user.lName = _lNameController.text;
      widget.user.userQuestionnaire!.fName = _fNameController.text;
      widget.user.userQuestionnaire!.lName = _lNameController.text;
      if (_profileImage != null) {
        String imageName = widget.user.userID + '.' + _profileImage!.path.split('.').last;
        String url = await StorageHelper.uploadProfileImage(imageName: imageName, imageFile: _profileImage!);
        widget.user.userImgName = imageName;
        widget.user.userImgUrl = url;
      }
      _appController.setUser(widget.user);
      await FirestoreHelper.saveUserFirestore(widget.user);
      await Preferences.saveUserSession(widget.user);
      ScaffoldMessenger.of(_scaffoldKey.currentContext!).removeCurrentSnackBar();
      ScaffoldMessenger.of(_scaffoldKey.currentContext!).showSnackBar(SnackBar(content: Text('update_profile_success'.tr), backgroundColor: kAppColor));
    } catch (e) {
      ScaffoldMessenger.of(_scaffoldKey.currentContext!).removeCurrentSnackBar();
      ScaffoldMessenger.of(_scaffoldKey.currentContext!).showSnackBar(SnackBar(content: Text('err_update_profile'.tr), backgroundColor: Colors.red));
    }
    setState(() {
      _showIndicator = false;
    });
  }
}
