import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../components/bmi_tabs/bmi_calculation_tab.dart';
import '../components/bmi_tabs/bmi_history_tab.dart';
import '../constants.dart';

class BMIScreen extends StatelessWidget {
  const BMIScreen({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          iconTheme: const IconThemeData(color: Colors.white),
          backgroundColor: kAppColor,
          title: Text(
            'bmi'.tr,
            style: kAppBarAppNameStyle,
          ),
        ),
        body: Column(
          children: [
            Container(
              color: Colors.white,
              height: 40,
              width: MediaQuery.of(context).size.width,
              child: TabBar(
                indicatorSize: TabBarIndicatorSize.tab,
                indicatorPadding: const EdgeInsets.symmetric(horizontal: 20),
                indicatorColor: kAppColor.withAlpha(150),
                labelColor: kDarkBlue,
                unselectedLabelColor: kDarkBlue.withAlpha(150),
                labelPadding: const EdgeInsets.symmetric(horizontal: 15),
                labelStyle: kIndicatorStyle,
                unselectedLabelStyle: const TextStyle(fontSize: 13, fontFamily: 'Trajan'),
                tabs: [Tab(text: 'calc_bmi'.tr), Tab(text: 'bmi_history'.tr)],
              ),
            ),
            const Flexible(child: TabBarView(children: [BMICalculationTab(), BMIHistoryTab()]))
          ],
        ),
      ),
    );
  }
}
