import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'constants.dart';
import 'controller/app_state_controller.dart';
import 'screens/splash_screen.dart';
import 'settings/preferences.dart';
import 'translations/detox_app_translations.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await Preferences.init();
  Get.put<AppStateController>(AppStateController());
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: '21d Detox',
      locale: Preferences.fetchAppLocale(),
      translations: DetoxAppTranslations(),
      debugShowCheckedModeBanner: false,
      color: kAppColor,
      theme: ThemeData(
        fontFamily: 'Montserrat',
        primarySwatch: Colors.lightGreen,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const SplashScreen(),
      builder: (BuildContext context, Widget? child) {
        return MediaQuery(data: MediaQuery.of(context).copyWith(textScaleFactor: 0.8), child: child!);
      },
    );
  }
}
