import 'dart:io';

import 'package:get/get.dart';

import '../models/batch_model.dart';
import '../models/method_practice_model.dart';
import '../models/post_recipe.dart';
import '../models/recipe_model.dart';
import '../models/shopping_item_model.dart';
import '../models/user_model.dart';
import '../settings/preferences.dart';

class AppStateController extends GetxController {
  static AppStateController get controller => Get.find<AppStateController>();
  final Rx<UserModel> userModel = UserModel().obs;
  final RxList<Recipe> recipeList = RxList<Recipe>([]);
  final RxList<String> watchedVideos = RxList<String>([]);
  final RxList<MethodPractice> initialMethods = RxList<MethodPractice>([]);
  final RxList<MethodPractice> initialPractices = RxList<MethodPractice>([]);
  final RxString appLocale = RxString('');
  final RxList<ShoppingItem> shoppingList = RxList<ShoppingItem>([]);
  final RxMap<String, File> recipeImages = RxMap<String, File>({});
  PostRecipe newRecipe = PostRecipe.fromMap({});

  Batch? get userBatch => userModel.value.userBatch;

  setInitMethods(List<MethodPractice> methods) {
    initialMethods.clear();
    initialMethods.assignAll(methods);
    Preferences.saveInitMethods(initialMethods.toList());
  }

  setInitPractices(List<MethodPractice> practices) {
    initialPractices.clear();
    initialPractices.assignAll(practices);
    Preferences.saveInitPractices(initialPractices.toList());
  }

  setShoppingList(List<ShoppingItem> shoppingItems) {
    shoppingList.clear();
    shoppingList.assignAll(shoppingItems);
    Preferences.saveShoppingList(shoppingList.toList());
  }

  setAppLocale(String locale) {
    appLocale.value = locale;
  }

  setWatchedVideos(List<String> videos) {
    watchedVideos.clear();
    watchedVideos.assignAll(videos);
  }

  setUser(UserModel user) {
    userModel(user);
    update();
  }

  setInitRecipes(List<Recipe> rList) {
    recipeList.clear();
    recipeList.assignAll(rList);
    Preferences.saveInitRecipes(recipeList.toList());
  }

  deleteRecipeItem(int index) {
    recipeList.removeAt(index);
    update();
  }

  updateRecipeListItem(int index, Recipe item) {
    recipeList.removeAt(index);
    recipeList.insert(index, item);
    update();
  }

  setRecipeImages(Map<String, File> images) {
    recipeImages.assignAll(images);
    update();
  }

  addRecipeImage(Map<String, File> value) {
    recipeImages.addAll(value);
    update();
  }

  updateRecipeImage(String key, File image) {
    File temp = File(image.path);
    temp.writeAsBytesSync(image.readAsBytesSync());
    recipeImages.update(key, (value) => temp);
    update();
  }

  deleteRecipeImage(String key) {
    recipeImages.remove(key);
    update();
  }
}
