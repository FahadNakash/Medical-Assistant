class PaidUser {
  PaidUser({
    required this.countryCode,
    required this.number,
  });

  String countryCode = '';
  String number = '';

  /// countryCode+number
  String get phone => countryCode + number;

  PaidUser.fromMap(Map<String, dynamic> map) {
    countryCode = map['countryCode'];
    number = map['number'];
  }

  Map<String, dynamic> toMap() {
    final Map<String, dynamic> map = {};
    map['countryCode'] = countryCode;
    map['number'] = number;
    return map;
  }
}
