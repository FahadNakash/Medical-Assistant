class Comment {
  String id = '';
  String userName = '';
  DateTime dateTime = DateTime.now();
  String comment = '';
  String userImgUrl = '';
  String forumID = '';
  String postID = '';
  String language = '';

  Comment({
    required this.id,
    required this.comment,
    required this.forumID,
    required this.postID,
    required this.userImgUrl,
    required this.userName,
    required this.language,
    required this.dateTime,
  });

  Comment.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    userName = map['userName'];
    userImgUrl = map['userImgUrl'];
    dateTime = DateTime.parse(map['dateTime']);
    comment = map['comment'];
    forumID = map['forumID'];
    postID = map['postID'];
    language = map['language'];
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userName': userName,
      'dateTime': dateTime.toString(),
      'comment': comment,
      'userImgUrl': userImgUrl,
      'forumID': forumID,
      'postID': postID,
      'language': language,
    };
  }
}
