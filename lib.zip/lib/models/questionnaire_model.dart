class Questionnaire {
  Questionnaire();
  String userID = '';
  String fName = '';
  String lName = '';
  String? cupsOfCoffee;
  bool isMetric = true;
  bool? isFemale;
  num? height;
  num? weight;
  List purpose = [];
  List<Map> bmiList = [];
  DateTime? dob;
  bool get hasDiabetes {
    return purpose.contains('Diabetes');
  }

  bool get hasWeightLoss {
    return purpose.contains('Weight Loss');
  }

  static const Map<String, int> coffeeOptions = {
    '0-1': 0,
    '1-2': 5,
    '2-3': 7,
    '3-4': 8,
    '4-5': 9,
    '5+': 10,
  };
  static const Map<String, String> purposeKeyMap = {
    'Blood Pressure': 'blood_pressure',
    'Cholesterol': 'cholesterol',
    'Diabetes': 'diabetes',
    'Weight Loss': 'weight_loss',
    'Fertility/Family Planning': 'family_planning',
    'Lifestyle': 'lifestyle',
  };

  Questionnaire.fromMap(Map<String, dynamic> json) {
    // if (json != null) {
    userID = json['userID'];
    purpose = json['purpose'];
    fName = json['fName'];
    lName = json['lName'];
    dob = DateTime.tryParse(json['dob']);
    isMetric = json['isMetric'];
    height = json['height'];
    weight = json['weight'];
    cupsOfCoffee = json['cupsOfCoffee'];
    isFemale = json['isFemale'];
    bmiList = json['bmiList'].cast<Map>();
    // }
  }

  Map<String, dynamic> toMap() {
    Map<String, dynamic> json = {};
    json['userID'] = userID;
    json['purpose'] = purpose;
    json['fName'] = fName;
    json['lName'] = lName;
    json['dob'] = dob.toString();
    json['isMetric'] = isMetric;
    json['height'] = height;
    json['weight'] = weight;
    json['cupsOfCoffee'] = cupsOfCoffee;
    json['isFemale'] = isFemale;
    json['bmiList'] = bmiList;
    return json;
  }
}
