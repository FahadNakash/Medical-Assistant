class Batch {
  Batch({
    required this.id,
    required this.name,
    required this.locale,
    required this.dateCreated,
    required this.startingDate,
  });

  String id = '';
  String name = '';
  String locale = '';
  DateTime dateCreated = DateTime.now();
  DateTime startingDate = DateTime.now();
  static const int _phaseDays = 3;
  DateTime get endingDate => startingDate.add(const Duration(days: 21));
  DateTime get after30 => endingDate.add(const Duration(days: 30));
  int get currentDay {
    Duration diff = DateTime.now().difference(startingDate);
    if (diff.isNegative) {
      return 0;
    } else {
      return diff.inDays + 1;
    }
  }

  int get currentPhase {
    int phase = (currentDay / _phaseDays).ceil();
    return phase > 0 ? phase : 0;
  }

  bool get isStarted => DateTime.now().isAfter(startingDate);

  bool get isExpired {
    return DateTime.now().isAfter(endingDate);
  }

  bool get isAvailableAfter {
    DateTime now = DateTime.now();
    return after30.isAfter(now) || after30.isAtSameMomentAs(now);
  }

  int get remainingDays {
    return after30.difference(DateTime.now()).inDays;
  }

  Batch.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    name = map['name'];
    locale = map['locale'];
    startingDate = DateTime.tryParse(map['startingDate']) ?? DateTime.now();
    dateCreated = DateTime.tryParse(map['dateCreated']) ?? DateTime.now();
  }

  Map<String, dynamic> toMap() {
    Map<String, dynamic> map = {};
    map['id'] = id;
    map['name'] = name;
    map['locale'] = locale;
    map['startingDate'] = startingDate.toString();
    map['dateCreated'] = dateCreated.toString();
    return map;
  }
}
