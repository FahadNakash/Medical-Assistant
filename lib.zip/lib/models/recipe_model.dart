class Recipe {
  Recipe({
    required this.id,
    required this.language,
    required this.title,
    required this.imgUrl,
    required this.imgName,
    required this.dateCreated,
    required this.categories,
    required this.days,
    required this.ingredients,
    required this.steps,
  });

  String id = '';
  String language = '';
  String title = '';
  String imgUrl = '';
  String imgName = '';
  List categories = [];
  List days = [];
  List ingredients = [];
  List steps = [];
  List userCategories = [];
  DateTime dateCreated = DateTime.now();

  static const List<String> categoriesTitle = [
    'Salads',
    'Raw',
    'Cooking',
    'Baking',
    'Spreads/Sauces',
    'Drinks',
  ];

  static const List<String> userCategoryList = [
    'Blood Pressure',
    'Cholesterol',
    'Diabetes',
    'Weight Loss',
    'Fertility/Family Planning',
    'Lifestyle',
  ];

  Recipe.fromMap(Map<String, dynamic> json) {
    if (json.isEmpty) {
      id = '';
      language = '';
      title = '';
      imgUrl = '';
      imgName = '';
      dateCreated = DateTime.now();
      categories = [];
      days = [];
      ingredients = [];
      steps = [];
      userCategories = [];
    } else {
      id = json['id'];
      language = json['language'];
      title = json['title'];
      imgUrl = json['imgUrl'];
      imgName = json['imgName'];
      dateCreated = DateTime.parse(json['dateTime']);
      categories = json['categories'];
      days = json['days'];
      ingredients = json['ingredients'];
      steps = json['steps'];
      userCategories = json['userCategories'];
    }
  }

  Map<String, dynamic> toMap() {
    Map<String, dynamic> json = {};
    json['id'] = id;
    json['language'] = language;
    json['title'] = title;
    json['imgName'] = imgName;
    json['imgUrl'] = imgUrl;
    json['dateTime'] = dateCreated.toString();
    json['categories'] = categories;
    json['days'] = days;
    json['ingredients'] = ingredients;
    json['steps'] = steps;
    json['userCategories'] = userCategories;
    return json;
  }
}
