class PostRecipe {
  PostRecipe({
    required this.language,
    required this.title,
    // required this.imgUrl,
    // required this.imgName,
    // required this.dateCreated,
    required this.ingredients,
    required this.steps,
    required this.category,
  });

  // String id = '';
  String language = '';
  String title = '';
  // String imgUrl = '';
  // String imgName = '';
  List ingredients = [];
  List steps = [];
  String category = '';
  // DateTime dateCreated = DateTime.now();

  static const List<String> categoriesList = [
    'Salad',
    'Raw',
    'Cooked',
    'Baked',
    'Spread/Sauce',
    'Drink',
  ];

  PostRecipe.fromMap(Map<String, dynamic> json) {
    // id = json['id'] ?? '';
    language = json['language'] ?? '';
    title = json['title'] ?? '';
    category = json['category'] ?? '';
    // imgUrl = json['imgUrl'] ?? '';
    // imgName = json['imgName'] ?? '';
    // dateCreated = DateTime.parse(json['dateTime'] ?? DateTime.now().toString());
    ingredients = json['ingredients'] ?? const [];
    steps = json['steps'] ?? const [];
  }

  Map<String, dynamic> toMap() {
    Map<String, dynamic> json = {};
    if (title.isEmpty) {
      return json;
    }
    // json['id'] = id;
    json['language'] = language;
    json['title'] = title;
    json['category'] = category;
    // json['imgName'] = imgName;
    // json['imgUrl'] = imgUrl;
    // json['dateTime'] = dateCreated.toString();
    json['ingredients'] = ingredients;
    json['steps'] = steps;
    return json;
  }
}
