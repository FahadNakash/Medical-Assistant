import 'post_recipe.dart';

class Post {
  String id = '';
  String userName = '';
  String userImgUrl = '';
  String userId = '';
  String postImgUrl = '';
  String postImgName = '';
  String postText = '';
  String batchDate = '';
  DateTime postDate = DateTime.now();
  int comments = 0;
  String language = '';
  // contains id of users who liked this
  List<String> likes = [];
  bool fromAdmin = false;
  bool pinned = false;
  PostRecipe recipe = PostRecipe.fromMap({});

  Post({
    required this.id,
    required this.userName,
    required this.userImgUrl,
    required this.userId,
    required this.postText,
    required this.postImgUrl,
    required this.postImgName,
    required this.batchDate,
    required this.recipe,
    required this.language,
    this.fromAdmin = false,
    this.pinned = false,
  });

  Post.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    userName = map['userName'];
    userImgUrl = map['userImgUrl'];
    userId = map['userId'];
    postImgUrl = map['postImgUrl'];
    postImgName = map['postImgName'];
    batchDate = map['batchDate'];
    language = map['language'];
    postText = map['postText'];
    postDate = DateTime.parse(map['postDate']);
    comments = map['comments'];
    likes = map['likes'].cast<String>();
    fromAdmin = map['fromAdmin'];
    pinned = map['pinned'] ?? false;
    recipe = PostRecipe.fromMap(map['recipe'] ?? {});
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userName': userName,
      'userImgUrl': userImgUrl,
      'userId': userId,
      'postImgUrl': postImgUrl,
      'postImgName': postImgName,
      'postText': postText,
      'batchDate': batchDate,
      'language': language,
      'postDate': postDate.toString(),
      'comments': comments,
      'likes': likes,
      'fromAdmin': fromAdmin,
      'pinned': pinned,
      'recipe': recipe.toMap(),
    };
  }
}
