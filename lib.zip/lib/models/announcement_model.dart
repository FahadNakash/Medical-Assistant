class Announcement {
  Announcement({
    required this.id,
    required this.title,
    required this.announcement,
    required this.dateCreated,
    required this.locale,
    required this.days,
    required this.categories,
  });

  String id = '';
  String title = '';
  String announcement = '';
  String locale = '';
  List days = [];
  List categories = [];
  DateTime dateCreated = DateTime.now();

  static const List<String> userCategoryList = [
    'Blood Pressure',
    'Cholesterol',
    'Diabetes',
    'Weight Loss',
    'Fertility/Family Planning',
    'Lifestyle',
  ];

  update(Announcement announcement) {
    title = announcement.title;
    this.announcement = announcement.announcement;
    locale = announcement.locale;
    days = announcement.days;
    categories = announcement.categories;
  }

  Announcement.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    title = map['title'];
    locale = map['locale'];
    announcement = map['announcement'];
    days = map['days'];
    categories = map['categories'];
    dateCreated = DateTime.tryParse(map['dateCreated']) ?? DateTime.now();
  }

  Map<String, dynamic> toMap() {
    Map<String, dynamic> map = {};
    map['id'] = id;
    map['title'] = title;
    map['locale'] = locale;
    map['announcement'] = announcement;
    map['days'] = days;
    map['categories'] = categories;
    map['dateCreated'] = dateCreated.toString();
    return map;
  }
}
