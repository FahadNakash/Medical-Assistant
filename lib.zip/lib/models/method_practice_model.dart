class MethodPractice {
  MethodPractice({
    required this.id,
    required this.title,
    required this.type,
    required this.description,
    required this.videoUrl,
    required this.locale,
    required this.days,
    required this.categories,
    required this.dateCreated,
  });
  String id = '';
  String title = '';
  String type = '';
  String description = '';
  String videoUrl = '';
  String locale = '';
  List days = [];
  List categories = [];
  DateTime dateCreated = DateTime.now();

  static const List<String> userCategoryList = [
    'Blood Pressure',
    'Cholesterol',
    'Diabetes',
    'Weight Loss',
    'Fertility/Family Planning',
    'Lifestyle',
  ];

  update(MethodPractice methodPractice) {
    title = methodPractice.title;
    locale = methodPractice.locale;
    description = methodPractice.description;
    videoUrl = methodPractice.videoUrl;
    days = methodPractice.days;
    categories = methodPractice.categories;
  }

  MethodPractice.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    title = map['title'];
    type = map['type'];
    locale = map['locale'];
    description = map['description'];
    videoUrl = map['videoUrl'];
    days = map['days'];
    categories = map['categories'];
    dateCreated = DateTime.tryParse(map['dateCreated']) ?? DateTime.now();
  }

  Map<String, dynamic> toMap() {
    Map<String, dynamic> map = {};
    map['id'] = id;
    map['title'] = title;
    map['type'] = type;
    map['locale'] = locale;
    map['description'] = description;
    map['videoUrl'] = videoUrl;
    map['days'] = days;
    map['categories'] = categories;
    map['dateCreated'] = dateCreated.toString();
    return map;
  }
}
