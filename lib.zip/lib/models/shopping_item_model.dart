class ShoppingItem {
  ShoppingItem({
    required this.id,
    required this.name,
    required this.dateCreated,
    required this.days,
    required this.userCategories,
    required this.itemCategory,
    required this.locale,
  });

  String id = '';
  String name = '';
  String locale = '';
  String itemCategory = '';
  List<int> days = [];
  List<String> userCategories = [];
  DateTime dateCreated = DateTime.now();

  static const List<String> userCategoryList = [
    'Blood Pressure',
    'Cholesterol',
    'Diabetes',
    'Weight Loss',
    'Fertility/Family Planning',
    'Lifestyle',
  ];

  static const List<String> itemCategoriesList = [
    'Cereals',
    'Vegetables',
    'Fruits',
    'Legumes',
    'Miscellaneous',
  ];

  ShoppingItem.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    name = map['name'];
    locale = map['locale'];
    dateCreated = DateTime.parse(map['dateCreated']);
    itemCategory = map['itemCategory'];
    days = map['days'].cast<int>().toList();
    userCategories = map['userCategories'].cast<String>().toList();
  }

  Map<String, dynamic> toMap() {
    Map<String, dynamic> map = {};
    map['id'] = id;
    map['name'] = name;
    map['locale'] = locale;
    map['dateCreated'] = dateCreated.toString();
    map['itemCategory'] = itemCategory;
    map['days'] = days;
    map['userCategories'] = userCategories;
    return map;
  }
}
