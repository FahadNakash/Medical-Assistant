import 'batch_model.dart';
import 'questionnaire_model.dart';

class UserModel {
  UserModel();
  // UserModel({
  // this.userID,
  // this.fName,
  // this.lName,
  // this.phoneNo,
  // this.country,
  // this.dialingCode,
  // this.userQuestionnaire,
  // this.joiningDate,
  // });
  String userID = '';
  String userImgUrl = '';
  String userImgName = '';
  String fName = '';
  String lName = '';
  String phoneNo = '';
  String dialingCode = '';
  String country = '';
  Questionnaire? userQuestionnaire;
  DateTime? joiningDate;
  Batch? userBatch;

  UserModel.fromMap(Map<String, dynamic> json) {
    userID = json['userID'];
    userImgUrl = json['userImgUrl'] ?? '';
    userImgName = json['userImgName'] ?? '';
    fName = json['fName'];
    lName = json['lName'];
    phoneNo = json['phoneNo'];
    dialingCode = json['dialingCode'];
    country = json['country'];
    joiningDate = DateTime.tryParse(json['joiningDate']);
    userQuestionnaire = Questionnaire.fromMap(json['userQuestionnaire']);
    userBatch = json['userBatch'].isNotEmpty ? Batch.fromMap(json['userBatch']) : null;
  }

  Map<String, dynamic> toMap() {
    Map<String, dynamic> json = {};
    json['userID'] = userID;
    json['userImgUrl'] = userImgUrl;
    json['userImgName'] = userImgName;
    json['fName'] = fName;
    json['lName'] = lName;
    json['phoneNo'] = phoneNo;
    json['dialingCode'] = dialingCode;
    json['country'] = country;
    json['joiningDate'] = joiningDate.toString();
    json['userQuestionnaire'] = userQuestionnaire?.toMap();
    json['userBatch'] = userBatch?.toMap() ?? {};
    return json;
  }
}
