import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../constants.dart';

class CustomDropDown<T> extends StatelessWidget {
  const CustomDropDown({
    required this.height,
    this.width,
    required this.items,
    required this.selectedItemBuilder,
    required this.popUpItemBuilder,
    required this.onChanged,
    this.errorText,
    this.showSearchBox,
    this.prefix,
    this.contentPadding,
    this.searchBoxContentPadding,
    this.searchBoxHintText,
    this.maxHeight,
    this.selectedItem,
    this.borderColor,
    this.readOnly = false,
    this.clearButton,
    this.showClearButton = false,
    Key? key,
  }) : super(key: key);

  final double height;
  final double? width;
  final List<T> items;
  final ValueChanged<T?> onChanged;
  final String? errorText;
  final DropdownSearchPopupItemBuilder<T> popUpItemBuilder; //(context, value, isSelected)
  final DropdownSearchBuilder<T> selectedItemBuilder; //(context, givenData, value)
  final bool? showSearchBox;
  final Widget? prefix;
  final EdgeInsets? contentPadding;
  final EdgeInsets? searchBoxContentPadding;
  final String? searchBoxHintText;
  final double? maxHeight;
  final T? selectedItem;
  final Color? borderColor;
  final bool? readOnly;
  final Widget? clearButton;
  final bool? showClearButton;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: width,
      child: DropdownSearch<T>(
        mode: Mode.MENU,
        popupBackgroundColor: Colors.white,
        items: items,
        showClearButton: showClearButton ?? false,
        clearButton: clearButton,
        selectedItem: selectedItem,
        maxHeight: maxHeight,
        enabled: !(readOnly ?? false),
        showSearchBox: showSearchBox ?? false,
        dropDownButton: SvgPicture.asset(
          '$assets/icon-arrow_down.svg',
          height: 8,
          width: 8,
          color: borderColor?.withAlpha(200) ?? kAppColor.withAlpha(140),
        ),
        popupItemBuilder: popUpItemBuilder,
        dropdownBuilder: selectedItemBuilder,
        onChanged: onChanged,
        popupShape: RoundedRectangleBorder(
          borderRadius: kFocusedBorderRadius,
          side: BorderSide.none,
        ),
        dropdownSearchDecoration: InputDecoration(
          contentPadding: contentPadding,
          prefixIcon: prefix,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: borderColor?.withAlpha(80) ?? Colors.lime.shade300,
            ),
            borderRadius: kEnabledBorderRadius,
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: borderColor ?? kAppColor.withAlpha(150),
            ),
            borderRadius: kFocusedBorderRadius,
          ),
          focusedErrorBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.red, width: 1.2),
          ),
          errorText: errorText,
          errorStyle: kErrorStyle,
          errorBorder: OutlineInputBorder(
              borderSide: BorderSide(
                width: 1,
                color: Colors.red.shade100,
              ),
              borderRadius: kEnabledBorderRadius),
        ),
        showAsSuffixIcons: true,
        searchBoxDecoration: InputDecoration(
          contentPadding: searchBoxContentPadding,
          suffixIcon: Padding(
            padding: const EdgeInsets.all(15),
            child: SvgPicture.asset(
              '$assets/icon-search.svg',
              color: kAppColor.withAlpha(140),
              height: 15,
              width: 15,
            ),
          ),
          hintText: searchBoxHintText,
          hintStyle: kHintStyle,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.lime.shade300,
            ),
            borderRadius: kEnabledBorderRadius,
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: kAppColor.withAlpha(150),
            ),
            borderRadius: kFocusedBorderRadius,
          ),
        ),
      ),
    );
  }
}
