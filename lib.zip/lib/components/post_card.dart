import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:readmore/readmore.dart';
import 'package:transparent_image/transparent_image.dart';

import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/post_model.dart';
import '../models/post_recipe.dart';
import '../screens/view_post_recipe_screen.dart';
import '../services/firestore_helper.dart';
import '../utils/utils.dart';
import 'comments_sheet.dart';

class PostCard extends StatefulWidget {
  const PostCard(this.post, {Key? key}) : super(key: key);
  final Post post;

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  final rn = Random().nextInt(15);
  final _controller = AppStateController.controller;

  Widget _postMenuButton() {
    return PopupMenuButton(
        padding: const EdgeInsets.all(0),
        shape: RoundedRectangleBorder(borderRadius: kFocusedBorderRadius),
        icon: const Icon(Icons.more_vert, color: kDarkBlue),
        onSelected: (option) async {
          FirestoreHelper.deletePost(widget.post);
        },
        itemBuilder: (context) {
          return <PopupMenuItem>[
            PopupMenuItem(
              height: 35,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.delete, color: Colors.red, size: 17),
                  const SizedBox(width: 5),
                  Text(
                    'delete'.tr,
                    style: const TextStyle(color: Colors.red),
                  ),
                ],
              ),
            ),
          ];
        });
  }

  Widget getPostRecipeTile(PostRecipe recipe) {
    final Size size = MediaQuery.of(context).size;
    final i = PostRecipe.categoriesList.indexOf(recipe.category);
    return Container(
      height: 80,
      width: size.width,
      color: Colors.white.withOpacity(0.9),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'recipe'.tr,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Expanded(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              margin: const EdgeInsets.symmetric(horizontal: 10),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(8),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Colors.black26,
                                    offset: Offset(0, 2),
                                    blurRadius: 4,
                                  )
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  padding: const EdgeInsets.all(5),
                                  height: 35,
                                  width: 35,
                                  alignment: Alignment.center,
                                  color: Colors.white,
                                  child: Image.asset(
                                    '$assets/icons${i + 1}.png',
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Flexible(
                                    child: Text(
                                      recipe.title,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: kAppColor,
                                        fontSize: 20,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                  Flexible(
                                    child: Text(
                                      'ingredients'.tr + recipe.ingredients.toString().replaceAll('[', '').replaceAll(']', ''),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 2,
                                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: kDarkGrey),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Divider(height: 5, color: kAppColor.withAlpha(200)),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: GestureDetector(
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ViewPostRecipeScreen(recipe: recipe))),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.black),
                ),
                child: Text(
                  'view'.tr,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.black),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Stack(
      children: [
        Container(
          color: Colors.white,
          width: size.width,
          margin: const EdgeInsets.symmetric(vertical: 7.5),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                alignment: Alignment.center,
                height: 70,
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: SizedBox(
                        height: 50,
                        width: 50,
                        child: widget.post.fromAdmin
                            ? Container(
                                child: Icon(
                                  Icons.account_circle_rounded,
                                  color: kAppColor.withAlpha(200),
                                  size: 45,
                                ),
                                decoration: BoxDecoration(color: kAppColor.withAlpha(20), border: Border.all(color: kAppColor), borderRadius: BorderRadius.circular(10)),
                              )
                            : Image.network(
                                widget.post.userImgUrl,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Icon(
                                  Icons.image,
                                  color: Colors.red.withAlpha(200),
                                  size: 30,
                                ),
                              ),
                      ),
                    ),
                    Expanded(
                        child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (!widget.post.fromAdmin)
                            RichText(
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                maxLines: 2,
                                text: TextSpan(
                                  text: '${widget.post.userName} ',
                                  style: kPostNameStyle,
                                  children: [
                                    TextSpan(
                                      text: widget.post.batchDate.split(' ')[0],
                                      style: const TextStyle(color: Colors.black, fontFamily: 'Poppins', fontSize: 13, fontWeight: FontWeight.w400),
                                    ),
                                    TextSpan(
                                      text: widget.post.batchDate.replaceAll(widget.post.batchDate.split(' ')[0], ''),
                                      style: kPostNameStyle,
                                    ),
                                  ],
                                )),
                          if (widget.post.fromAdmin)
                            RichText(
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                maxLines: 2,
                                text: TextSpan(
                                  text: 'admin'.tr,
                                  style: kPostNameStyle,
                                )),
                          Text(
                            getDateTimeString(widget.post.postDate),
                            style: const TextStyle(fontSize: 12, color: kGrey, fontFamily: 'Comfortaa', fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    )),
                    if (widget.post.userId == _controller.userModel.value.userID) _postMenuButton(),
                  ],
                ),
              ),
              if (widget.post.postText.isNotEmpty)
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  child: ReadMoreText(
                    widget.post.postText,
                    trimLines: 3,
                    style: kPostBodyStyle,
                    trimMode: TrimMode.Line,
                    trimCollapsedText: 'show_more'.tr,
                    trimExpandedText: 'show_less'.tr,
                    moreStyle: kPostBodyStyle.copyWith(color: kAppColor.withOpacity(0.7), fontWeight: FontWeight.bold),
                    lessStyle: kPostBodyStyle.copyWith(color: kAppColor.withOpacity(0.7), fontWeight: FontWeight.bold),
                  ),
                ),
              if (widget.post.postImgUrl.isNotEmpty && widget.post.recipe.title.isEmpty)
                Container(
                  constraints: const BoxConstraints(minHeight: 200),
                  width: size.width,
                  color: kColors[rn],
                  child: FadeInImage.memoryNetwork(
                    placeholder: kTransparentImage,
                    image: widget.post.postImgUrl,
                    imageErrorBuilder: (_, __, ___) => Icon(
                      Icons.image,
                      color: Colors.red.withAlpha(200),
                      size: 150,
                    ),
                  ),
                ),
              if (widget.post.postImgUrl.isNotEmpty && widget.post.recipe.title.isNotEmpty)
                Stack(
                  children: [
                    Container(
                      constraints: const BoxConstraints(minHeight: 200),
                      width: size.width,
                      color: kColors[rn],
                      child: FadeInImage.memoryNetwork(
                        placeholder: kTransparentImage,
                        image: widget.post.postImgUrl,
                        imageErrorBuilder: (_, __, ___) => Icon(
                          Icons.image,
                          color: Colors.red.withAlpha(200),
                          size: 150,
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 10,
                      child: getPostRecipeTile(widget.post.recipe),
                    ),
                  ],
                ),
              if (widget.post.postImgUrl.isEmpty && widget.post.recipe.title.isNotEmpty) getPostRecipeTile(widget.post.recipe),
              Container(
                  color: Colors.grey.shade50,
                  height: 50,
                  child: Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 50,
                          child: Material(
                            color: Colors.grey.shade50,
                            child: InkWell(
                              onTap: _likePost,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(widget.post.likes.contains(_controller.userModel.value.userID) ? Icons.favorite : Icons.favorite_border, color: Colors.red[400]),
                                  const SizedBox(width: 5),
                                  Text(
                                    'likes'.tr,
                                    style: const TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Poppins'),
                                  ),
                                  Text(
                                    ' (${widget.post.likes.length})',
                                    style: const TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Poppins'),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      const VerticalDivider(indent: 5, endIndent: 5),
                      Expanded(
                        child: SizedBox(
                          height: 50,
                          child: Material(
                            color: Colors.grey.shade50,
                            child: InkWell(
                              onTap: _postComment,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.comment_outlined, color: kAppColor.withOpacity(0.7)),
                                  const SizedBox(width: 5),
                                  Text(
                                    'comments'.tr,
                                    style: const TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Poppins'),
                                  ),
                                  Text(
                                    ' (${widget.post.comments})',
                                    style: const TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Poppins'),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  )),
            ],
          ),
        ),
        if (widget.post.pinned)
          Positioned(
            top: 15,
            right: Get.locale!.languageCode == 'en' ? 10 : null,
            left: Get.locale!.languageCode == 'en' ? null : 10,
            child: Transform.rotate(
              angle: Get.locale!.languageCode == 'en' ? -12 : 12,
              child: Icon(
                Icons.push_pin_rounded,
                size: 20,
                color: kAppColor.withAlpha(200),
              ),
            ),
          ),
      ],
    );
  }

  _likePost() {
    try {
      if (widget.post.likes.contains(_controller.userModel.value.userID)) {
        return;
      }
      final likes = List.from(widget.post.likes);
      likes.add(_controller.userModel.value.userID);
      FirebaseFirestore.instance.collection('forums').doc(kForumId).collection('posts').doc(widget.post.id).update({'likes': likes});
    } catch (_) {}
  }

  _postComment() {
    try {
      showModalBottomSheet<void>(
          context: context,
          isScrollControlled: true,
          isDismissible: true,
          backgroundColor: Colors.transparent,
          shape: const RoundedRectangleBorder(
            borderRadius: kTLRBorderRadius,
          ),
          builder: (context) {
            return CommentsSheet(widget.post);
          });
    } catch (_) {}
  }
}
