import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

import '../constants.dart';
import '../utils/utils.dart';

class BMIGauge extends StatelessWidget {
  const BMIGauge({required this.bmi, this.initialAnimation = false, this.canScaleToFit = false, this.radiusFactor = 0.96, this.title, Key? key}) : super(key: key);
  final double gaugeWidth = 10;
  final num bmi;
  final bool initialAnimation;
  final bool canScaleToFit;
  final double radiusFactor;
  final GaugeTitle? title;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SfRadialGauge(
          enableLoadingAnimation: initialAnimation,
          title: title,
          axes: <RadialAxis>[
            RadialAxis(
              minimum: 15,
              maximum: 40,
              canScaleToFit: canScaleToFit,
              startAngle: 180,
              endAngle: 0,
              radiusFactor: radiusFactor,
              showAxisLine: false,
              labelOffset: gaugeWidth + 5,
              showTicks: false,
              tickOffset: gaugeWidth,
              onLabelCreated: (AxisLabelCreatedArgs args) {
                if (args.text == '40') {
                  args.text = '>40';
                } else if (args.text == '15') {
                  args.text = '15<';
                }
              },
              pointers: <GaugePointer>[MarkerPointer(value: bmi.toDouble(), markerOffset: -10, markerHeight: 15, markerWidth: 18)],
              ranges: <GaugeRange>[
                GaugeRange(
                  endWidth: gaugeWidth,
                  startWidth: gaugeWidth,
                  startValue: 10,
                  endValue: 18.5,
                  gradient: SweepGradient(
                    colors: [
                      Colors.blue.shade50,
                      Colors.blue.shade100,
                    ],
                  ),
                ),
                GaugeRange(
                  endWidth: gaugeWidth,
                  startWidth: gaugeWidth,
                  startValue: 18.5,
                  endValue: 24.9,
                  gradient: SweepGradient(
                    colors: [
                      Colors.blue.shade100,
                      Colors.green.shade200,
                    ],
                  ),
                ),
                GaugeRange(
                  endWidth: gaugeWidth,
                  startWidth: gaugeWidth,
                  startValue: 24.9,
                  endValue: 29.9,
                  gradient: SweepGradient(
                    colors: [
                      Colors.green.shade200,
                      Colors.yellow.shade400,
                    ],
                  ),
                ),
                GaugeRange(
                  endWidth: gaugeWidth,
                  startWidth: gaugeWidth,
                  startValue: 29.9,
                  endValue: 35,
                  gradient: SweepGradient(
                    colors: [
                      Colors.yellow.shade400,
                      Colors.orange.shade400,
                    ],
                  ),
                ),
                GaugeRange(
                  endWidth: gaugeWidth,
                  startWidth: gaugeWidth,
                  startValue: 35,
                  endValue: 40,
                  gradient: SweepGradient(
                    colors: [
                      Colors.orange.shade400,
                      Colors.red.shade300,
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
        Align(
          alignment: Alignment.center,
          child: Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Text(
              'your_bmi_is'.tr + '\n' + bmi.toStringAsFixed(2) + '\n' + getBMIResultString(bmi).tr,
              textAlign: TextAlign.center,
              // textDirection: TextDirection.ltr,
              style: kBodyStyle.copyWith(color: getBMIResultColor(bmi)),
            ),
          ),
        ),
      ],
    );
  }
}
