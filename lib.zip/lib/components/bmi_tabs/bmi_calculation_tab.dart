import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:numberpicker/numberpicker.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

import '../../constants.dart';
import '../../controller/app_state_controller.dart';
import '../../models/user_model.dart';
import '../../settings/preferences.dart';
import '../../utils/utils.dart';
import '../bmi_gauge.dart';
import '../main_button.dart';

class BMICalculationTab extends StatefulWidget {
  const BMICalculationTab({Key? key}) : super(key: key);

  @override
  _BMICalculationTabState createState() => _BMICalculationTabState();
}

class _BMICalculationTabState extends State<BMICalculationTab> {
  final AppStateController _controller = AppStateController.controller;
  final TextStyle unselectedStyle = const TextStyle(fontSize: 16, color: Colors.black54);
  final TextStyle selectedStyle = const TextStyle(fontSize: 17, color: Colors.white, fontWeight: FontWeight.w600);
  num? height, weight;
  late num bmi;
  bool isMetric = true;
  final RxBool isLoading = false.obs;

  @override
  void initState() {
    super.initState();
    height = _controller.userModel.value.userQuestionnaire!.height;
    weight = _controller.userModel.value.userQuestionnaire!.weight;
    bmi = calculateBMI();
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final String locale = Get.locale!.languageCode + '_' + Get.locale!.countryCode!;
    return NotificationListener<OverscrollIndicatorNotification>(
      onNotification: (OverscrollIndicatorNotification scrollEndNotification) {
        scrollEndNotification.disallowGlow();
        return true;
      },
      child: GetBuilder<AppStateController>(
        builder: (controller) => SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 10),
              Container(
                height: 35,
                width: 180,
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          setState(() {
                            isMetric = true;
                            bmi = calculateBMI();
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color: isMetric ? kAppColor.withAlpha(220) : Colors.white,
                            borderRadius: locale == kEnglishLocale ? const BorderRadius.only(topLeft: Radius.circular(25), bottomLeft: Radius.circular(25)) : const BorderRadius.only(topRight: Radius.circular(25), bottomRight: Radius.circular(25)),
                          ),
                          alignment: Alignment.center,
                          child: Text('metric'.tr, style: isMetric ? selectedStyle : unselectedStyle),
                        ),
                      ),
                    ),
                    Expanded(
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          setState(() {
                            isMetric = false;
                            bmi = calculateBMI();
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color: !isMetric ? kAppColor.withAlpha(220) : Colors.white,
                            borderRadius: locale == kEnglishLocale ? const BorderRadius.only(topRight: Radius.circular(25), bottomRight: Radius.circular(25)) : const BorderRadius.only(topLeft: Radius.circular(25), bottomLeft: Radius.circular(25)),
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            'imperial'.tr,
                            style: isMetric ? unselectedStyle : selectedStyle,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  border: Border.all(
                    color: kAppColor.withAlpha(220),
                  ),
                ),
              ),
              const SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(width: 5),
                      Column(
                        children: [
                          Text(
                            'q1_slide_height'.tr,
                            style: kPropertyStyle,
                          ),
                          const SizedBox(height: 5),
                          Container(
                            width: 70,
                            decoration: BoxDecoration(
                              color: const Color(0xffF5F6EC),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Container(
                                  height: 35,
                                  width: 60,
                                  decoration: BoxDecoration(
                                    color: const Color(0xffE6E7DF),
                                    borderRadius: BorderRadius.circular(7),
                                  ),
                                ),
                                NumberPicker(
                                  value: height?.toInt() ?? 60,
                                  minValue: 0,
                                  maxValue: 999,
                                  textStyle: const TextStyle(color: Colors.grey, fontWeight: FontWeight.w500, fontSize: 23),
                                  selectedTextStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.w500, fontSize: 25),
                                  onChanged: (val) => setState(() {
                                    height = val;
                                    bmi = calculateBMI();
                                  }),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(width: 5),
                      Container(
                        width: 30,
                        alignment: Alignment.bottomLeft,
                        height: 40,
                        child: Text(isMetric ? 'cm' : 'inch', style: const TextStyle(fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(width: 5),
                      Column(
                        children: [
                          Text(
                            'q1_slide_weight'.tr,
                            style: kPropertyStyle,
                          ),
                          const SizedBox(height: 5),
                          Container(
                            width: 70,
                            decoration: BoxDecoration(
                              color: const Color(0xffF5F6EC),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Container(
                                  height: 35,
                                  width: 60,
                                  decoration: BoxDecoration(
                                    color: const Color(0xffE6E7DF),
                                    borderRadius: BorderRadius.circular(7),
                                  ),
                                ),
                                NumberPicker(
                                  value: weight?.toInt() ?? 60,
                                  minValue: 0,
                                  maxValue: 999,
                                  textStyle: const TextStyle(color: Colors.grey, fontWeight: FontWeight.w500, fontSize: 23),
                                  selectedTextStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.w500, fontSize: 25),
                                  onChanged: (val) => setState(() {
                                    weight = val;
                                    bmi = calculateBMI();
                                  }),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(width: 5),
                      Container(
                        width: 30,
                        alignment: Alignment.bottomLeft,
                        height: 40,
                        child: Text(isMetric ? 'kg' : 'lbs', style: const TextStyle(fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: size.width * 0.7,
                height: 230,
                child: BMIGauge(
                  title: const GaugeTitle(text: 'BMI', textStyle: kPropertyStyle),
                  bmi: bmi,
                  initialAnimation: true,
                  canScaleToFit: true,
                  radiusFactor: 1.2,
                ),
              ),
              Obx(
                () => isLoading.value
                    ? Column(
                        children: [
                          const SizedBox(
                            height: 25,
                            width: 25,
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation(kAppColor),
                              strokeWidth: 1,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text('pls_wait'.tr, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: kAppColor)),
                        ],
                      )
                    : SizedBox(width: 120, child: MainButton(title: 'save'.tr, onTap: saveBMI)),
              ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  saveBMI() async {
    if (height != null && weight != null) {
      isLoading.value = true;
      UserModel user = _controller.userModel.value;
      user.userQuestionnaire!.height = height;
      user.userQuestionnaire!.weight = weight;
      user.userQuestionnaire!.bmiList.add({DateTime.now().toString(): bmi});
      _controller.setUser(user);
      await Preferences.saveUserSession(user);
      isLoading.value = false;
    }
  }

  num calculateBMI() {
    if (isMetric) {
      return getMetricBMI(height ?? 0, weight ?? 0);
    } else {
      return getImperialBMI(height ?? 0, weight ?? 0);
    }
  }
}
