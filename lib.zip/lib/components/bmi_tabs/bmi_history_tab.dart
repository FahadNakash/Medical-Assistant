import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../constants.dart';
import '../../controller/app_state_controller.dart';
import '../../utils/utils.dart';

class BMIHistoryTab extends StatelessWidget {
  const BMIHistoryTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return NotificationListener<OverscrollIndicatorNotification>(
      onNotification: (OverscrollIndicatorNotification scrollEndNotification) {
        scrollEndNotification.disallowGlow();
        return true;
      },
      child: GetBuilder<AppStateController>(
        builder: (controller) => ListView.builder(
          itemCount: controller.userModel.value.userQuestionnaire!.bmiList.length,
          itemBuilder: (_, index) {
            final Map bmi = controller.userModel.value.userQuestionnaire!.bmiList[index];
            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  flex: 3,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(height: 50, width: 0.7, color: kAppColor.withAlpha(200)),
                      Padding(
                        padding: const EdgeInsets.only(top: 10, bottom: 10),
                        child: Text(getDateString(DateTime.parse(bmi.keys.first)), style: kIndicatorStyle),
                      ),
                      Container(height: 50, width: 0.7, color: kAppColor.withAlpha(200)),
                    ],
                  ),
                ),
                Expanded(
                  flex: 5,
                  child: Container(
                      alignment: Alignment.center,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Text(
                          bmi.values.first.toStringAsFixed(2) + '\n' + getBMIResultString(bmi.values.first).tr,
                          textAlign: TextAlign.center,
                          style: kBodyStyle.copyWith(color: getBMIResultColor(bmi.values.first)),
                        ),
                        decoration: BoxDecoration(
                          color: getBMIResultColor(bmi.values.first).withAlpha(20),
                          border: Border.all(color: getBMIResultColor(bmi.values.first)),
                          borderRadius: BorderRadius.circular(15),
                        ),
                      )),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
