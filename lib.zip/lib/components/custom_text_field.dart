import 'package:flutter/material.dart';

import '../constants.dart';

class CustomTextField extends StatelessWidget {
  const CustomTextField({
    this.width,
    this.height,
    this.textInputAction,
    this.keyboardType,
    this.textController,
    this.node,
    this.contentPadding,
    this.obscureText,
    this.onChanged,
    this.onEditingComplete,
    this.onFieldSubmitted,
    this.errorText,
    this.suffix,
    this.prefix,
    this.labelText,
    this.helperText,
    this.hintText,
    this.isDense,
    this.readOnly,
    this.maxLines,
    this.minLines,
    this.autofocus,
    this.initialValue,
    this.isError = false,
    Key? key,
  }) : super(key: key);

  final String? labelText;
  final String? errorText;
  final String? helperText;
  final String? hintText;
  final String? initialValue;
  final int? maxLines;
  final int? minLines;
  final double? height;
  final double? width;
  final bool? obscureText;
  final bool? isDense;
  final bool? readOnly;
  final bool? isError;
  final bool? autofocus;
  final Function(String)? onChanged;
  final Function()? onEditingComplete;
  final Function(String)? onFieldSubmitted;
  final EdgeInsets? contentPadding;
  final FocusNode? node;
  final TextEditingController? textController;
  final TextInputType? keyboardType;
  final TextInputAction? textInputAction;
  final Widget? suffix;
  final Widget? prefix;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: width,
      child: TextFormField(
        initialValue: initialValue,
        onChanged: onChanged,
        onEditingComplete: onEditingComplete,
        onFieldSubmitted: onFieldSubmitted,
        controller: textController,
        keyboardType: keyboardType,
        textInputAction: textInputAction,
        focusNode: node,
        readOnly: readOnly ?? false,
        obscureText: obscureText ?? false,
        cursorColor: errorText == null ? kAppColor : Colors.red,
        cursorRadius: const Radius.circular(25),
        cursorWidth: 1,
        autofocus: autofocus ?? false,
        maxLines: maxLines ?? 1,
        minLines: minLines ?? 1,
        style: TextStyle(
          color: errorText == null ? kAppColor : Colors.red,
          fontSize: 19,
        ),
        decoration: InputDecoration(
          contentPadding: contentPadding,
          alignLabelWithHint: true,
          labelText: labelText,
          labelStyle: kLabelStyle,
          helperText: helperText,
          helperStyle: const TextStyle(height: 0.08, fontSize: 10, color: Colors.black54),
          hintText: hintText,
          hintStyle: kHintStyle,
          suffixIcon: suffix,
          prefix: prefix,
          isDense: isDense,
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: isError ?? false ? Colors.red : kAppColor.withAlpha(150),
            ),
            borderRadius: kFocusedBorderRadius,
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: isError ?? false ? Colors.red.shade100 : Colors.lime.shade300,
            ),
            borderRadius: kEnabledBorderRadius,
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderSide: const BorderSide(
              width: 1,
              color: Colors.red,
            ),
            borderRadius: kFocusedBorderRadius,
          ),
          errorText: errorText,
          errorStyle: kErrorStyle,
          errorBorder: OutlineInputBorder(
              borderSide: BorderSide(
                width: 1,
                color: Colors.red.shade100,
              ),
              borderRadius: kEnabledBorderRadius),
        ),
      ),
    );
  }
}
