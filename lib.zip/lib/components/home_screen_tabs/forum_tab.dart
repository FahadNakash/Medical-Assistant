import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../components/post_card.dart';
import '../../constants.dart';
import '../../controller/app_state_controller.dart';
import '../../models/post_model.dart';
import '../../screens/new_post_screen.dart';
import '../../services/firestore_helper.dart';
import '../loading_indicator.dart';

class ForumTab extends StatefulWidget {
  const ForumTab({Key? key}) : super(key: key);

  @override
  State<ForumTab> createState() => _ForumTabState();
}

class _ForumTabState extends State<ForumTab> {
  final AppStateController _controller = AppStateController.controller;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        RefreshIndicator(
          onRefresh: () {
            return Future.delayed(
                const Duration(
                  seconds: 0,
                ),
                () => setState(() {}));
          },
          child: StreamBuilder<QuerySnapshot<Object?>>(
              stream: FirestoreHelper.forumRef.doc(kForumId).collection('posts').snapshots(),
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: LoadingIndicator(),
                  );
                }
                if (snap.data != null) {
                  if ((snap.data?.size ?? -1) > 0) {
                    List<Post> _posts = snap.data?.docs.map<Post>((e) => Post.fromMap(e.data() as Map<String, dynamic>)).toList() ?? [];
                    if (_posts.length > 1) {
                      _posts.sort((a, b) {
                        if (a.pinned && !b.pinned) {
                          return -1;
                        }
                        if (!a.pinned && b.pinned) {
                          return 1;
                        }
                        return b.postDate.compareTo(a.postDate);
                      });
                    }
                    return ForumBuilder(_posts);
                  }
                }
                return Center(
                  child: Container(
                    padding: const EdgeInsets.all(15),
                    margin: const EdgeInsets.only(bottom: 100),
                    decoration: BoxDecoration(
                      color: kAppColor.withAlpha(20),
                      borderRadius: kFocusedBorderRadius,
                    ),
                    child: Text(
                      'no_posts_err'.tr,
                      style: kUnselectedTextStyle,
                      textAlign: TextAlign.center,
                    ),
                  ),
                );
              }),
        ),
        Positioned(
          bottom: 25,
          right: Get.locale?.languageCode == 'en' ? 10 : null,
          left: Get.locale?.languageCode == 'en' ? null : 10,
          child: FloatingActionButton.extended(
            backgroundColor: kAppColor.withAlpha(200),
            onPressed: () => Navigator.of(context).push(CupertinoPageRoute(builder: (_) => const NewPostScreen())),
            label: Text('new_post'.tr, style: const TextStyle(color: Colors.white)),
          ),
        ),
      ],
    );
  }
}

class ForumBuilder extends StatelessWidget {
  const ForumBuilder(this.posts, {Key? key}) : super(key: key);
  final List<Post> posts;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey.shade300,
      child: ListView.builder(
        padding: const EdgeInsets.only(top: 10, bottom: 10),
        itemCount: posts.length,
        itemBuilder: (_, i) {
          return PostCard(posts[i]);
        },
      ),
    );
  }
}
