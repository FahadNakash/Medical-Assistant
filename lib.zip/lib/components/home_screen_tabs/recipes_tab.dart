import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

import '../../components/recipe_card.dart';
import '../../constants.dart';
import '../../controller/app_state_controller.dart';
import '../../models/recipe_model.dart';
import '../../models/user_model.dart';
import '../../screens/shopping_list_screen.dart';
import '../../services/firestore_helper.dart';

class RecipesTab extends StatefulWidget {
  const RecipesTab({Key? key}) : super(key: key);
  @override
  _RecipesTabState createState() => _RecipesTabState();
}

class _RecipesTabState extends State<RecipesTab> {
  final AppStateController _controller = AppStateController.controller;
  String selectedTab = 'Salads';
  late bool hasRecipes;

  @override
  void initState() {
    hasRecipes = getFilteredRecipes().any((element) => element.categories.contains(selectedTab));
    super.initState();
  }

  List<Recipe> getFilteredRecipes() {
    List<Recipe> filteredRecipes = [];
    UserModel user = _controller.userModel.value;
    if (user.userBatch != null) {
      for (var recipe in _controller.recipeList) {
        if (!user.userBatch!.isExpired && user.userBatch!.isAvailableAfter) {
          if (recipe.days.any((element) => element == user.userBatch!.currentDay)) {
            for (String recipeCategory in recipe.userCategories) {
              if (user.userQuestionnaire!.hasDiabetes) {
                if (recipeCategory == diabetes && recipe.language == _controller.appLocale.value) {
                  filteredRecipes.add(recipe);
                  break;
                }
              } else if (user.userQuestionnaire!.hasWeightLoss) {
                if (recipeCategory == weightLoss && recipe.language == _controller.appLocale.value) {
                  filteredRecipes.add(recipe);
                  break;
                }
              } else {
                if (user.userQuestionnaire!.purpose.contains(recipeCategory) && recipe.language == _controller.appLocale.value) {
                  filteredRecipes.add(recipe);
                  break;
                }
              }
            }
          }
        } else if (user.userBatch!.isExpired && user.userBatch!.isAvailableAfter) {
          if (recipe.days.contains(21)) {
            for (String recipeCategory in recipe.userCategories) {
              if (user.userQuestionnaire!.hasDiabetes) {
                if (recipeCategory == diabetes && recipe.language == _controller.appLocale.value) {
                  filteredRecipes.add(recipe);
                  break;
                }
              } else if (user.userQuestionnaire!.hasWeightLoss) {
                if (recipeCategory == weightLoss && recipe.language == _controller.appLocale.value) {
                  filteredRecipes.add(recipe);
                  break;
                }
              } else {
                if (user.userQuestionnaire!.purpose.contains(recipeCategory) && recipe.language == _controller.appLocale.value) {
                  filteredRecipes.add(recipe);
                  break;
                }
              }
            }
          }
        }
      }
    }

    filteredRecipes.sort((Recipe a, Recipe b) {
      int c = b.dateCreated.compareTo(a.dateCreated);
      int aFold = a.days.sublist(0, a.days.indexOf(user.userBatch!.isExpired ? 21 : user.userBatch!.currentDay)).fold(0, (p, c) => (p.abs() + c.abs()).toInt());
      int bFold = b.days.sublist(0, b.days.indexOf(user.userBatch!.isExpired ? 21 : user.userBatch!.currentDay)).fold(0, (p, c) => (p.abs() + c.abs()).toInt());
      if (c > 0) {
        if (aFold < 0 && bFold < 0) {
          if (bFold > aFold) {
            c = 1;
          } else {
            c = -1;
          }
        } else {
          if (bFold > aFold && aFold > 0) {
            c = -1;
          } else if (bFold > aFold && aFold < 0) {
            c = 1;
          }
        }
      } else if (c < 0) {
        if (bFold < 0 && aFold < 0) {
          if (bFold < aFold) {
            c = -1;
          } else {
            c = 1;
          }
        } else {
          if (bFold < aFold && bFold > 0) {
            c = 1;
          } else if (bFold < aFold && bFold < 0) {
            c = -1;
          }
        }
      }
      return c;
    });
    return filteredRecipes;
  }

  Widget getTabIcons(int index, String category) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedTab = category;
          hasRecipes = getFilteredRecipes().any((element) => element.categories.contains(selectedTab));
        });
      },
      child: Container(
        height: 50,
        width: 50,
        alignment: Alignment.center,
        decoration: selectedTab == category ? BoxDecoration(border: _controller.appLocale.value == kEnglishLocale ? Border(right: BorderSide(color: kAppColor.withAlpha(150), width: 2)) : Border(left: BorderSide(color: kAppColor.withAlpha(150), width: 2))) : null,
        child: Image.asset(
          '$assets/icons$index.png',
          height: selectedTab == category ? 40 : 25,
          width: selectedTab == category ? 40 : 25,
          color: selectedTab == category ? null : Colors.grey,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
        stream: FirestoreHelper.recipesRef.snapshots().distinct(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            List<Recipe> temp = [];
            for (var element in snapshot.data?.docs ?? []) {
              temp.add(Recipe.fromMap(element.data() as Map<String, dynamic>));
            }
            _controller.setInitRecipes(temp);
          }
          final List<Recipe> userRecipes = getFilteredRecipes();
          hasRecipes = userRecipes.any((element) => element.categories.contains(selectedTab));
          return Row(
            children: [
              Container(
                color: Colors.white,
                height: MediaQuery.of(context).size.height,
                width: 50,
                padding: const EdgeInsets.only(top: 10),
                child: Column(
                  children: [
                    getTabIcons(1, 'Salads'),
                    getTabIcons(2, 'Raw'),
                    getTabIcons(3, 'Cooking'),
                    getTabIcons(4, 'Baking'),
                    getTabIcons(5, 'Spreads'),
                    getTabIcons(6, 'Drinks'),
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          Navigator.of(context).push(MaterialPageRoute(builder: (_) => ShoppingListScreen()));
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                              height: 50,
                              width: 50,
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: kAppColor.withAlpha(240),
                                shape: BoxShape.circle,
                              ),
                              alignment: Alignment.center,
                              child: SvgPicture.asset(
                                '$assets/icon-shopping.svg',
                                color: Colors.white,
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(top: 5, bottom: 15),
                              width: 55,
                              child: Text(
                                'shopping_list'.tr,
                                maxLines: 2,
                                textAlign: TextAlign.center,
                                style: kTextActionStyle.copyWith(fontSize: 12),
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Expanded(
                child: Container(
                    height: MediaQuery.of(context).size.height,
                    padding: const EdgeInsets.only(top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          height: 25,
                          child: Text(
                            selectedTab.toLowerCase().tr + ':',
                            style: kIndicatorStyle.copyWith(fontSize: 20, decoration: TextDecoration.underline),
                          ),
                        ),
                        hasRecipes
                            ? Flexible(
                                child: ListView.builder(
                                  itemCount: userRecipes.length,
                                  itemBuilder: (context, index) {
                                    if (userRecipes[index].categories.contains(selectedTab)) {
                                      return RecipeCard(userRecipes[index]);
                                    } else {
                                      return const SizedBox();
                                    }
                                  },
                                ),
                              )
                            : Center(
                                child: Container(
                                  padding: const EdgeInsets.all(15),
                                  margin: const EdgeInsets.only(top: 100),
                                  decoration: BoxDecoration(
                                    color: kAppColor.withAlpha(20),
                                    borderRadius: kFocusedBorderRadius,
                                  ),
                                  child: Text(
                                    'no_recipe_err'.tr,
                                    style: kUnselectedTextStyle,
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ),
                      ],
                    )),
              ),
            ],
          );
        });
  }
}
