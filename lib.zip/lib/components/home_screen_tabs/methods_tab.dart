import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../components/method_practice_card.dart';
import '../../constants.dart';
import '../../controller/app_state_controller.dart';
import '../../models/method_practice_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_helper.dart';

class MethodsTab extends StatelessWidget {
  MethodsTab({Key? key}) : super(key: key);
  final AppStateController _controller = AppStateController.controller;

  List<MethodPractice> getFilteredMethods() {
    List<MethodPractice> filteredMethods = [];
    UserModel user = _controller.userModel.value;
    if (user.userBatch != null) {
      for (var method in _controller.initialMethods) {
        if (!user.userBatch!.isExpired && user.userBatch!.isAvailableAfter) {
          if (method.days.any((element) => element == user.userBatch!.currentDay)) {
            for (String methodCategory in method.categories) {
              if (user.userQuestionnaire!.hasDiabetes) {
                if (methodCategory == diabetes && method.locale == _controller.appLocale.value) {
                  filteredMethods.add(method);
                  break;
                }
              } else {
                if (user.userQuestionnaire!.purpose.contains(methodCategory) && method.locale == _controller.appLocale.value) {
                  filteredMethods.add(method);
                  break;
                }
              }
            }
          }
        } else if (user.userBatch!.isExpired && user.userBatch!.isAvailableAfter) {
          if (method.days.contains(21)) {
            for (String methodCategory in method.categories) {
              if (user.userQuestionnaire!.hasDiabetes) {
                if (methodCategory == diabetes && method.locale == _controller.appLocale.value) {
                  filteredMethods.add(method);
                  break;
                }
              } else {
                if (user.userQuestionnaire!.purpose.contains(methodCategory) && method.locale == _controller.appLocale.value) {
                  filteredMethods.add(method);
                  break;
                }
              }
            }
          }
        }
      }
    }

    filteredMethods.sort((MethodPractice a, MethodPractice b) {
      int c = b.dateCreated.compareTo(a.dateCreated);
      int aFold = a.days.sublist(0, a.days.indexOf(user.userBatch!.isExpired ? 21 : user.userBatch!.currentDay)).fold(0, (p, c) => (p.abs() + c.abs()).toInt());
      int bFold = b.days.sublist(0, b.days.indexOf(user.userBatch!.isExpired ? 21 : user.userBatch!.currentDay)).fold(0, (p, c) => (p.abs() + c.abs()).toInt());
      if (c > 0) {
        if (aFold < 0 && bFold < 0) {
          if (bFold > aFold) {
            c = 1;
          } else {
            c = -1;
          }
        } else {
          if (bFold > aFold && aFold > 0) {
            c = -1;
          } else if (bFold > aFold && aFold < 0) {
            c = 1;
          }
        }
      } else if (c < 0) {
        if (bFold < 0 && aFold < 0) {
          if (bFold < aFold) {
            c = -1;
          } else {
            c = 1;
          }
        } else {
          if (bFold < aFold && bFold > 0) {
            c = 1;
          } else if (bFold < aFold && bFold < 0) {
            c = -1;
          }
        }
      }
      return c;
    });
    return filteredMethods;
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder(builder: (AppStateController controller) {
      return StreamBuilder<QuerySnapshot>(
        stream: FirestoreHelper.methodsRef.snapshots().distinct(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            List<MethodPractice> temp = [];
            for (var element in snapshot.data?.docs ?? []) {
              temp.add(MethodPractice.fromMap(element.data() as Map<String, dynamic>));
            }
            _controller.setInitMethods(temp);
          }
          final List<MethodPractice> userMethods = getFilteredMethods();
          return userMethods.isNotEmpty
              ? ListView.builder(
                  itemCount: userMethods.length,
                  itemBuilder: (context, index) {
                    return MethodPracticeCard(userMethods[index]);
                  },
                )
              : Center(
                  child: Container(
                    padding: const EdgeInsets.all(15),
                    margin: const EdgeInsets.only(bottom: 100),
                    decoration: BoxDecoration(
                      color: kAppColor.withAlpha(20),
                      borderRadius: kFocusedBorderRadius,
                    ),
                    child: Text(
                      'no_method_err'.tr,
                      style: kUnselectedTextStyle,
                      textAlign: TextAlign.center,
                    ),
                  ),
                );
        },
      );
    });
  }
}
