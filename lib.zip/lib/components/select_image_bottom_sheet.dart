import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

class SelectImageBottomSheet extends StatelessWidget {
  const SelectImageBottomSheet({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 25, horizontal: 45),
      height: size.height * 0.3,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'profile_photo'.tr,
            style: const TextStyle(fontFamily: 'Montserrat', fontSize: 30, fontWeight: FontWeight.w500),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.of(context).pop(ImageSource.gallery);
                },
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      child: const Icon(
                        Icons.image,
                        size: 40,
                        color: Color(0xfffcfcfc),
                      ),
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(colors: [Color(0xff642B73), Color(0xffC6426E)]),
                        shape: BoxShape.circle,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10, top: 5),
                      child: Text('gallery'.tr, style: const TextStyle(fontFamily: 'Arial', color: Colors.black54)),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.of(context).pop(ImageSource.camera);
                },
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      child: const Icon(
                        Icons.camera_alt,
                        size: 40,
                        color: Color(0xfffcfcfc),
                      ),
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(colors: [Color(0xff202066), Color(0xff1CB5E0)]),
                        shape: BoxShape.circle,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10, top: 5),
                      child: Text('camera'.tr, style: const TextStyle(fontFamily: 'Arial', color: Colors.black54)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
