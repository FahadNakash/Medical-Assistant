import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:readmore/readmore.dart';

import '../constants.dart';
import '../models/comment_model.dart';
import '../utils/utils.dart';

class CommentCard extends StatelessWidget {
  const CommentCard(this.comment, {Key? key}) : super(key: key);
  final Comment comment;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: SizedBox(
                  height: 40,
                  width: 40,
                  child: Image.network(
                    comment.userImgUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Icon(
                      Icons.image,
                      color: Colors.red.withAlpha(200),
                      size: 30,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(8),
                  constraints: const BoxConstraints(minHeight: 50),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: Colors.grey.shade100,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        comment.userName,
                        style: kPostBodyStyle.copyWith(fontSize: 17, fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: ReadMoreText(
                          comment.comment,
                          trimLines: 3,
                          style: kPostBodyStyle,
                          trimMode: TrimMode.Line,
                          trimCollapsedText: 'show_more'.tr,
                          trimExpandedText: 'show_less'.tr,
                          moreStyle: kPostBodyStyle.copyWith(color: kAppColor.withOpacity(0.7), fontWeight: FontWeight.bold),
                          lessStyle: kPostBodyStyle.copyWith(color: kAppColor.withOpacity(0.7), fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(
              left: 10,
              right: 10,
              top: 5,
            ),
            child: Text(
              getDateTimeString(comment.dateTime),
              style: const TextStyle(fontSize: 12, color: kGrey, fontFamily: 'Comfortaa', fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}
