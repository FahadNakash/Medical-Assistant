import 'package:flutter/material.dart';

import '../constants.dart';

class MainButton extends StatelessWidget {
  const MainButton({
    required this.title,
    required this.onTap,
    this.height = 35,
    this.width = 110,
    Key? key,
  }) : super(key: key);
  final String title;
  final VoidCallback onTap;
  final double height, width;
  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: kEnabledBorderRadius,
      color: kAppColor.withAlpha(200),
      elevation: 6,
      shadowColor: kAppColor.withAlpha(200),
      child: InkWell(
        splashColor: Colors.white,
        splashFactory: InkRipple.splashFactory,
        borderRadius: kEnabledBorderRadius,
        onTap: onTap,
        child: Container(
          width: width,
          height: height,
          alignment: Alignment.center,
          child: Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w500,
              fontSize: 18,
            ),
          ),
        ),
      ),
    );
  }
}
