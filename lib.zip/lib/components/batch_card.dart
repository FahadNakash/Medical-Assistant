import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/batch_model.dart';
import '../utils/utils.dart';

class BatchCard extends StatelessWidget {
  const BatchCard(this.batch, {Key? key}) : super(key: key);
  final Batch batch;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: 75,
      width: size.width,
      margin: const EdgeInsets.only(top: 10, left: 5, right: 5),
      padding: const EdgeInsets.only(left: 5, top: 5, bottom: 5, right: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kAppColor.withAlpha(20), width: 2),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: SizedBox(
              height: 70,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Flexible(
                    child: Text(
                      batch.name,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: kDarkBlue.withAlpha(200),
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                        margin: const EdgeInsets.only(right: 3),
                        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                        decoration: BoxDecoration(
                          color: kAppColor.withAlpha(20),
                          borderRadius: kEnabledBorderRadius,
                        ),
                        child: Text(
                          'date_from_to'.trArgs([getBatchDate(batch.startingDate), getBatchDate(batch.endingDate)]),
                          overflow: TextOverflow.ellipsis,
                          style: kCardBodyStyle.copyWith(color: kAppColor),
                        ),
                      ),
                      batch.isExpired
                          ? Container(
                              margin: const EdgeInsets.only(right: 3),
                              padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                              decoration: BoxDecoration(
                                color: Colors.red.withAlpha(20),
                                border: Border.all(color: Colors.red, width: 0.5),
                                borderRadius: kEnabledBorderRadius,
                              ),
                              child: Text(
                                'expired',
                                overflow: TextOverflow.ellipsis,
                                style: kCardBodyStyle.copyWith(color: Colors.red),
                              ),
                            )
                          : const SizedBox(),
                      GetBuilder<AppStateController>(builder: (controller) {
                        return controller.userModel.value.userBatch != null && controller.userModel.value.userBatch?.id == batch.id
                            ? Container(
                                padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                                decoration: BoxDecoration(
                                  color: kAppColor.withAlpha(200),
                                  borderRadius: kEnabledBorderRadius,
                                ),
                                child: Text(
                                  'selected'.tr,
                                  style: kCardBodyStyle.copyWith(color: Colors.white),
                                ),
                              )
                            : const SizedBox();
                      }),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Container(
            width: 60,
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            decoration: BoxDecoration(
              color: kAppColor.withAlpha(20),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text(
                  'stage'.tr,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12, color: kAppColor),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                ),
                Text(
                  '${batch.currentPhase}',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w500, color: kAppColor),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
