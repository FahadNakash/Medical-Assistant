import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../settings/preferences.dart';

class LanguageSelectorDropdown extends StatelessWidget {
  LanguageSelectorDropdown({Key? key}) : super(key: key);
  final RxBool _languageTabOpened = false.obs;
  final AppStateController _controller = AppStateController.controller;
  final RxString selectedLanguage = AppStateController.controller.appLocale.value == kEnglishLocale ? 'English'.obs : 'Hebrew'.obs;

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => GestureDetector(
        onTap: _languageTabOpened.value ? null : () => _languageTabOpened.value = true,
        child: Container(
          width: 60,
          height: _languageTabOpened.value ? 50 : 20,
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: kAppColor, width: 0.7),
            borderRadius: BorderRadius.circular(5),
          ),
          child: !_languageTabOpened.value
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '$selectedLanguage ',
                      style: const TextStyle(
                        fontSize: 13,
                        color: kAppColor,
                      ),
                    ),
                    SvgPicture.asset(
                      '$assets/icon-arrow_down.svg',
                      color: kAppColor,
                      height: 5,
                      width: 5,
                    ),
                  ],
                )
              : Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    GestureDetector(
                      onTap: () async {
                        _controller.setAppLocale(kEnglishLocale);
                        Get.updateLocale(const Locale('en', 'US'));
                        selectedLanguage.value = 'English';
                        _languageTabOpened.value = false;
                        await Preferences.saveAppLocale(kEnglishLocale);
                      },
                      child: Container(
                        color: Colors.white,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text(
                              'English',
                              softWrap: false,
                              style: TextStyle(
                                fontSize: 13,
                                color: selectedLanguage.value == 'English' ? kAppColor : kGrey,
                              ),
                            ),
                            SvgPicture.asset(
                              selectedLanguage.value == 'English' ? '$assets/icon-circle_check.svg' : '$assets/icon-circle.svg',
                              color: selectedLanguage.value == 'English' ? kAppColor : kGrey,
                              height: 12,
                              width: 12,
                            ),
                          ],
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () async {
                        _controller.setAppLocale(kHebrewLocale);
                        Get.updateLocale(const Locale('he', 'IL'));
                        selectedLanguage.value = 'Hebrew';
                        _languageTabOpened.value = false;
                        await Preferences.saveAppLocale(kHebrewLocale);
                      },
                      child: Container(
                        color: Colors.white,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text(
                              'Hebrew',
                              softWrap: false,
                              style: TextStyle(
                                fontSize: 13,
                                color: selectedLanguage.value == 'Hebrew' ? kAppColor : kGrey,
                              ),
                            ),
                            SvgPicture.asset(
                              selectedLanguage.value == 'Hebrew' ? '$assets/icon-circle_check.svg' : '$assets/icon-circle.svg',
                              color: selectedLanguage.value == 'Hebrew' ? kAppColor : kGrey,
                              height: 12,
                              width: 12,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}
