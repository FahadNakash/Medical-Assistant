import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';

import '../components/show_dialog.dart';
import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../screens/bmi_screen.dart';
import '../screens/phone_login_screen.dart';
import '../screens/profile_screen.dart';
import '../settings/preferences.dart';
import '../utils/app_helpers.dart';
import 'confirmation_dialog.dart';

class HomeMenuButton extends StatelessWidget {
  HomeMenuButton({Key? key}) : super(key: key);
  final AppStateController _controller = AppStateController.controller;
  final RxBool _showIndicator = false.obs;

  changeLanguageDialog(BuildContext context) {
    final List<Map<String, dynamic>> locales = [
      {'name': 'English', 'locale': const Locale('en', 'US')},
      {'name': 'Hebrew', 'locale': const Locale('he', 'IL')}
    ];
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: Text(
                'choose_language'.tr,
                style: const TextStyle(color: kAppColor, fontSize: 25),
              ),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
              content: SizedBox(
                  width: double.maxFinite,
                  child: ListView.separated(
                      shrinkWrap: true,
                      itemBuilder: (context, index) => GestureDetector(
                            onTap: () async {
                              _controller.setAppLocale(locales[index]['name'] == 'English' ? kEnglishLocale : kHebrewLocale);
                              Get.updateLocale(locales[index]['locale']);
                              await Preferences.saveAppLocale(locales[index]['name'] == 'English' ? kEnglishLocale : kHebrewLocale);
                              Navigator.of(context).pop();
                            },
                            child: Container(
                              color: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Text(
                                locales[index]['name'],
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                      separatorBuilder: (context, index) => const Divider(color: kGrey),
                      itemCount: 2)),
            ));
  }

  @override
  Widget build(BuildContext context) {
    return Obx(() => _showIndicator.value
        ? Container(
            color: kAppColor,
            height: 25,
            width: 25,
            margin: const EdgeInsets.symmetric(horizontal: 10),
            padding: const EdgeInsets.symmetric(vertical: 15),
            child: const CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation(Colors.white),
            ),
          )
        : PopupMenuButton<Options>(
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(borderRadius: kFocusedBorderRadius),
            icon: const Icon(Icons.more_vert, color: Colors.white),
            onSelected: (option) async {
              if (option == Options.announcements) {
                _showIndicator.value = true;
                try {
                  if (await InternetConnectionChecker().hasConnection) {
                    await getAnnouncements(context);
                  } else {
                    showDialog(
                        context: context,
                        builder: (_) => ShowDialog(
                              alertMessage: 'no_conn_err'.tr,
                            ));
                  }
                  _showIndicator.value = false;
                } catch (e) {
                  _showIndicator.value = false;
                }
              } else if (option == Options.language) {
                changeLanguageDialog(context);
              } else if (option == Options.profile) {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProfileScreen(_controller.userModel.value)));
              } else if (option == Options.bmi) {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BMIScreen()));
              } else if (option == Options.logout) {
                bool? decision = await showDialog<bool>(
                    context: context,
                    builder: (_) => ConfirmationDialog(
                          title: 'attention'.tr,
                          alertMessage: 'logout_msg'.tr,
                        ));
                if (decision == true) {
                  await FirebaseAuth.instance.signOut();
                  await Preferences.deleteUserSession();
                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const PhoneLoginScreen()));
                }
              }
            },
            itemBuilder: (context) {
              return <PopupMenuItem<Options>>[
                PopupMenuItem<Options>(
                  height: 35,
                  value: Options.profile,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.account_circle_outlined, color: Colors.grey, size: 17),
                      const SizedBox(width: 5),
                      Text('profile'.tr),
                    ],
                  ),
                ),
                PopupMenuItem<Options>(
                  height: 35,
                  value: Options.announcements,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.announcement_outlined, color: Colors.grey, size: 15),
                      const SizedBox(width: 5),
                      Text('announcements'.tr),
                    ],
                  ),
                ),
                PopupMenuItem<Options>(
                  height: 35,
                  value: Options.language,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.translate, color: Colors.grey, size: 15),
                      const SizedBox(width: 5),
                      Text('language'.tr),
                    ],
                  ),
                ),
                PopupMenuItem<Options>(
                  height: 35,
                  value: Options.bmi,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.fitness_center, color: Colors.grey, size: 15),
                      const SizedBox(width: 5),
                      Text('bmi'.tr),
                    ],
                  ),
                ),
                PopupMenuItem<Options>(
                  height: 35,
                  value: Options.logout,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.logout, color: Colors.red, size: 15),
                      const SizedBox(width: 5),
                      Text('logout'.tr),
                    ],
                  ),
                  textStyle: Theme.of(context).textTheme.subtitle1!.copyWith(color: Colors.red, fontWeight: FontWeight.w600),
                )
              ];
            }));
  }
}

enum Options {
  profile,
  announcements,
  language,
  bmi,
  logout,
}
