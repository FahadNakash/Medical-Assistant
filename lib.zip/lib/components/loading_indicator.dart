import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants.dart';

class LoadingIndicator extends StatelessWidget {
  const LoadingIndicator({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const SizedBox(
          height: 35,
          width: 35,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation(kAppColor),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('loading'.tr),
        ),
      ],
    );
  }
}
