import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../constants.dart';
import '../models/shopping_item_model.dart';

class ShoppingItemCard extends StatelessWidget {
  const ShoppingItemCard(this.shoppingItem, {Key? key}) : super(key: key);
  final ShoppingItem shoppingItem;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      width: size.width,
      margin: const EdgeInsets.only(top: 10, left: 5, right: 5),
      padding: const EdgeInsets.only(left: 5, top: 5, bottom: 5, right: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kAppColor.withAlpha(20), width: 2),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            height: 40,
            width: 40,
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.all(5),
            child: SvgPicture.asset(
              '$assets/icon-tag.svg',
              color: kAppColor,
            ),
            decoration: BoxDecoration(
              color: kAppColor.withAlpha(20),
              border: Border.all(color: kAppColor.withAlpha(200), width: 1),
              borderRadius: BorderRadius.circular(15),
            ),
          ),
          Expanded(
            child: SizedBox(
              height: 50,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Flexible(
                    child: Text(
                      shoppingItem.name,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: kAppColor,
                        fontSize: 25,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          shoppingItem.itemCategory,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: kDarkGrey),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
