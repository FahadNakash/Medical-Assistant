import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../constants.dart';

class TermsOfUse extends StatelessWidget {
  const TermsOfUse({Key? key}) : super(key: key);

  final mainTitleStyle = const TextStyle(fontFamily: 'Trajan', color: kAppColor, fontSize: 30, decoration: TextDecoration.underline);
  final textBodyStyle = const TextStyle(fontFamily: 'Montserrat', color: Colors.black, fontSize: 17, height: 1.5);
  final spanBodyStyle = const TextStyle(fontFamily: 'Montserrat', color: Colors.black, fontSize: 14, height: 1.5);
  final smallTitleStyle = const TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.w600, decoration: TextDecoration.underline);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Align(
          alignment: Alignment.center,
          child: Text(
            'Terms of Use',
            textAlign: TextAlign.center,
            style: mainTitleStyle,
          ),
        ),
        const SizedBox(height: 20),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: 'WELCOME TO Regeneration 21 DT ("',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'Regeneration',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '" OR "',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'WE',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '").\n\n',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'BY USING (I) THE Regeneration APPLICATION FOR MOBILE DEVICES (II)  THE SERVICES OFFERED BY Regeneration (THE " Regeneration ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'SERVICES',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '") (III) THE Regeneration WEBSITE (THE "',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'WEBSITE',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '") AND/OR (IV) THE Regeneration WEBAPP (ALL COLLECTIVELY (THE "',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'APPLICATION',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '"); YOU, AN INDIVIDUAL, A CORPORATION OR ANY BUSINESS ENTITY ("',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'YOU',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '") ACCEPT AND AGREE TO BE BOUND BY THE FOLLOWING TERMS OF USE ("',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'TERMS',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '") AND ALL APPLICABLE LAWS AND REGULATIONS GOVERNING THE APPLICATION.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text:
                    '\n\nTHESE TERMS CONSTITUTES A LEGAL AGREEMENT THAT REGULATES THE BUSINESS RELATIONSHIP BETWEEN YOU AND Regeneration. PLEASE READ THESE TERMS CAREFULLY BEFORE USING THE APPLICATION OR ANY Regeneration SERVICE. Regeneration RESERVES THE RIGHT TO AMEND THESE TERMS, AT ANY TIME, ON ITS SOLE DISCRETION, EFFECTIVE IMMEDIATELY UPON POSTING SUCH AMENDED TERMS VIA THE APPLICATION OR VIA THE WEBSITE, AND THEREFORE, WE URGE YOU TO CHECK PERIODICALLY FOR UPDATES. YOUR CONTINUED USE OF THE APPLICATION, AFTER THE POSTING AN UPDATED VERSION OF THE TERMS, CONSTITUTES YOUR AGREEMENT TO ANY AMENDED VERSION OF THE TERMS.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: '\n\nBY DOWNLOADING, INSTALLING OR USING THE APPLICATION, ON YOUR MOBILE DEVICE ("',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'DEVICE',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '"), YOU EXPRESSLY AGREE TO, AND CONSENT THAT YOU UNDERSTOOD THESE TERMS, AND THAT YOU CONSENT TO BE BOUND BY THESE TERMS. PLEASE READ THESE TERMS CAREFULLY BEFORE APPROVING THE ABOVE.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text:
                    '\n\nANY DOWNLOAD, INSTALLATION OR USE OF THE APPLICATION, INCLUDING ANY UPDATED VERSION OF THE APPLICATION, IS SUBJECT TO, AND SHALL REMAIN SUBJECT TO, THE CONDITIONS OF THESE TERMS, AT ANY TIME. IF YOU DO NOT AGREE TO THE FULL EXTENT OF THESE TERMS, OR IF YOU DO NOT WISH TO BE BOUND BY THESE TERMS, PLEASE DO NOT DOWNLOAD, INSTALL OR USE THE APPLICATION OR ANY OF THE Regeneration SERVICES OR IF YOU HAVE INSTALLED IT, THEN PLEASE UNINSTALL IT IMMEDIATELY FROM YOUR DEVICE, AND DO NOT ACCESS, USE OR INSTALL IT IN ANY FORM OR MANNER.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: '\n\nTHE USE OF THE MASCULINE GENDER IN THESE TERMS IS FOR CONVENIENCE PURPOSES ONLY, AND ANY PART THEREOF, IN WHICH THE MASCULINE GENDER IS USED, APPLIES THE FEMININE GENDER AS WELL.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text:
                    '\n\nTHE APPLICATION, AS WELL AS THE DETOX PLAN AND ANY CONSULTING, INFORMATION OR ADVISE THAT YOU WILL RECEIVE VIA THE APPLICATION, OR AS PART OF THE DETOX PLAN, DOES NOT, IN ANY WAY, CONSTITUTE MEDICAL CONSULTING OR MEDICAL TREATMENT, AND YOU ARE AWARE THAT THE OWNERS OF THE APPLICATION ARE NOT DOCTORS AND DOES NOT PROVIDE MEDICAL ADVISE OR TREATMENT. THEREFORE, YOU ARE REQUESTED, AND IT IS HIGHLY RECOMMENDED BY US, TO CONSULT YOUR PERSONAL DOCTOR, PRIOR TO THE START OF THE DETOX PLAN AS WELL AS IN ANY SITUATION IN WHICH, DURING THE DETOX PLAN, YOU WILL FEEL ANY MENTAL OR PHYSICAL PROBLEM OR PAIN. IN CASE THAT YOU CONSUME ANY MEDICATIONS OR INCURE ANY PAINS OR CRONICAL DISEASES ON A REGULAR BASIS, YOU ARE OBLIGATED TO INFORM US IMMEDIATELY BEFORE YOU PARTICIPATE IN THE DETOX PLAN AND NOT TO PARTICIPATE IN IT, UNTIL YOU GET AN APPROVAL FROM YOUR PERSONAL DOCTOR AND REPORT TO US.',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '\n\nPARTICIPATING IN THE DETOX PLAN AS WELL AS PERFORMING ANY ACTION OFFERED UNDER THE DETOX PLAN, INCLUDING AS PART OF THE WEEKLY ZOOM MEETING, SHALL BE AT YOUR OWN RESPONSIBILITY AND RISK.',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '\n\nAS PART OF THE DETOX PLAN, WE RECOMMEND TO USE CERTAIN FOOD ADDITIVES IN ORDER TO IMPROVE THE RESAULTS. YOU ARE REQUESTED TO CONSULT WITH YOUR PERSONAL DOCTOR BEFORE YOU USE ANY SUCH FOOD ADDITIVES.',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'The Application',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'The Application is intended for providing information and plans for body detox by way of written information, video and recipes that are intended for improving your health and lifestyle.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'You are not required to register or open an account in order to use the Application, however, in order to register yourself to the detox plan, You must open an account and subscribe to the plan. The use of the Application is intended for individuals only and not for commercial purpose.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Upon your first use of the Application, You will be required to fill in our health questionnaire to assist us in getting to know you better. You undertake that all of the information that You provide is true accurate and updated, and You shall notify us immediately in case of any change in such information. Such information will be used for building your personal detox plan.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Your Account',
          style: smallTitleStyle,
        ),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: 'In case that You do decide to open an account (the "',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'Account',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text:
                    '") You will be required to provide certain information about You in order to adjust the detox process for you in specific. You hereby declare and acknowledge that You are not demanded to provide any information about yourself, except for your full name, telephone number and email.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text:
                    '\n\nYour account will be opened under your telephone number. You will be able to use Your account only from this telephone number. You agree to immediately notify Us of any unauthorized use of your Account or any other breach of security. We will not be liable for any loss or damage arising from your failure to comply with this section.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text:
                    '\n\nYou must be at least 18 years old to use the Application (or such older age required in your country to be authorized to use the Application without parental approval). If you are not old enough to have authority to agree to our Terms in your country, please do not use and delete the Application.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: '\n\nYou undertake that all information provided by You to Us is true and accurate, and consent to update this information in order to keep its accuracy, correctness and completeness.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text:
                    '\n\nYou acknowledge and confirm that the use of the Application and most of its functions requires a Device that is connected to the internet. All costs from maintaining internet connection and/or any additional cost that will be required as a result of using the Application, shall be borne by you solely.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: '\n\nPlease be advised that upon 30 days from the completion of the detox plan, Your Account will be automatically deactivated.',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'PAYMENT',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: 'The structure and steps of the detox plan are specified in the Application.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text:
                    'The Payment is for the detox plan, as specified in the Application and for additional 30 days after the end of the detox plan. Following 30 days, Your Account shall be disabled.\n\nFollowing completion of your payment, an email will be sent to You summarizing the details of your order with an order number, and Your Account shall be activated.\n\nYou may terminate any subscription and/or package and/or service that You purchased, within 14 days from ordering either by telephone to 972-508714344, by sending a written notice by e-mail to ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'regeneration.today.dror@gmail.com',
                style: spanBodyStyle.copyWith(color: kAppColor, fontWeight: FontWeight.w500),
              ),
              TextSpan(
                text:
                    ', indicating your full name, telephone number, and order number, however, in case You have already started the detox plan, during such 14 days, You will be charged with the applicable amount of fees, up to the stage that You have completed in the detox plan on the date of notice of termination.\n\nYou hereby represent and warrant that You are the owner of the credit card and/or pay pal account that You are paying from, and that such credit card and/or account has sufficient amount of credit to cover the payment. All payments through third parties (such as credit card or Paypal) are subject to the applicable third party\'s Terms of Service. You are aware that any inaccurate or untrue information provided by You with respect to such payment methods, is considered a criminal offense.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'License',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text:
                    'Regeneration hereby grants You, pursuant to the terms and subject to the conditions of these Terms, a limited, personal, non-exclusive, non-assignable, non-commercial, revocable, non- sublicensable license to use Application, for the sole purpose of participating in the detox plan and for 30 days after it is completed  (the "',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'License',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '"). Regeneration reserves all other rights to the Application that were not explicitly granted under these Terms.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: '\n\nThe License shall be conditioned upon Your full compliance with these Terms and shall be immediately terminated upon any breach by You of any of these Terms.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text:
                    '\n\nRegeneration shall not own the information that you shall submit as part of opening your Account or as part of using the Application. You undertake that You have all rights, title and interest to all information that you submit to your Account or to other parties via the Application.\n\nYou hereby grant Regeneration a worldwide, non-exclusive, royalty-free, sublicensable, and transferable license to use, reproduce, distribute, create derivative works of, display, and perform the information that you upload, submit, store, send, or receive on or through the Application, including without limitations video, audio, text message, video message, audio message, image, stickers, special stickers (stickers with text or audio) , and any other data for the limited purpose of operating and providing the services as part of the Application.',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'Restrictions and Prohibitions',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: 'As part of using the Application, You may, from time to time, provide Information to Regeneration and/or to other users via the Application or via the weekly zoom meeting ("',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'Information',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '").',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'You hereby undertake not to, directly or indirectly make any use of the Application, including using Information provided to You within the framework of using the Application for the purpose of: (i) Uploading content and/or information in which You have no ownership or right of use and/or which violates or may violate any rights of any third party, including without limitations proprietary or privacy rights. (ii) Interference, disruption, limiting or preventing the use of the Application. (iii) Uploading content and/or information which is misleading, false and/or harmful to Regeneration and/or its executives, directors and/or to any third party. (iv) Uploading information which is abusive, insulting, defamatory, threatening forbidden or any other information of similar nature. (v) Any illegal purpose and/or in breach of these Terms. (vi) Harassment or false complaint. (vii) Causing damage to any third party. (viii) Performing an action which is against the law. (ix) Performing any action that deviates from the intended use of the Application. Or (x) Transferring Information which is a false report of an incident (xi) selling products and services that are in breach of the applicable law or that you are not authorize to sell or that their sale is in breach of rights to third parties.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Within the framework of using the Application, You undertake not to cause and/or assist, either by acts or by omissions, either directly or indirectly, and/or to damage and/or breach contractual rights, proprietary rights, copyrights, moral rights, duties of care and trust, trade secrets, trademarks, patents; not to publish information that constitutes defamation, not to invalidate any privacy rights of a person, not to violate warrants, not to make advertising that is prohibited by law, and not to harm in any way state security or the rights of third parties.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'You further undertake not to violate any law by uploading Information within the framework of using the Application, and You will not upload and/or publish within the framework of using of the Application, any contents which violates proprietary rights of others, any pornographic or sexually or sensitive materials and/or any materials relating to minors and/or identifies them, or materials that encourages and/or supports and/or assists in performing an act which constitutes a criminal offense under the applicable laws and/or providing passwords and/or personal information and/or intimate details about other users and/or harassment of users, impersonating others, advertising and/or promotion of commercial sales, political propaganda and/or promotion of candidates and parties in elections, the use of inappropriate language and/or offensive language, collecting information about others, change the location of information from the Application and/or the Website to elsewhere for commercial purposes or in a manner which may damage Regeneration\'s business, make repeated messages, publishing false or misleading materials, posting links and/or any other illegal materials. For the avoidance of doubt it is hereby clarified that the aforementioned prohibitions shall also apply to uploading links to materials and/or improper content.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Part of Your Information to be provided as part of the registration process and as part of using the Application, will be saved in Regeneration servers, and may be used as detailed in our Privacy Policy.',
          style: textBodyStyle.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 10),
        Text(
          'You undertake to refrain from any attempt to collect Information via the Application, including through technological means, operation or assistance to the operation of a computer application or by any other means designed to scan and/or copy and/or retrieve and/or mine information, to refrain from executing and/or causing any change to the Application, including to other users’ content, and not to interfere with the Application’s source code.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'You undertake to refrain from any acts and/or omissions that may disrupt the Application\'s activity and/or the activity of users thereof, such as "viruses", "worms" and other harmful applications, accessing of computerized material, editing and / or inserting software in a manner that may cause damage or disruption to a device and/or materials.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'You shall inform Regeneration, immediately, regarding any possibility of damage that may be caused to other users and/or third parties and/or Regeneration and/or of an existing or anticipated breach of the applicable law, due and/or as a result of Your use of the Application.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'You hereby acknowledge that Regeneration may take any action against a user who breaches these Terms by any means available to Regeneration by the applicable law.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'You undertake, that there is no legal and/or contractual and/or any other obligation that prevents You from uploading and/or publishing and/or transferring the Information and that said Information is not in any breach of any applicable law and is not in breach of any right of any third party.',
          style: textBodyStyle.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text:
                    'You shall be fully liable for any act of defamation and/or breach of privacy and/or violation of proprietary rights and/or contractual and/or violation of a judicial decree and/or any other violation, and You expressly exempt Regeneration, including its representatives, employees, managers and shareholders acting on its behalf ("',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'Representatives',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: '"), from any and all responsibility and/or liability in connection therewith.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        Text(
          'You hereby acknowledge that You are aware that the Application is only a platform for the transfer of the Information and therefore Regeneration or its Representatives are not responsible, in any way, for the nature, reliability, correctness, completeness, legality and function of the Information, and that they are not responsible in case that a third party shall rely on the Information.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Regeneration may, at its sole discretion, refuse to allow You to share Information with others via the Application without the need to receive Your consent or provide You with prior notice, or have you removed from the weekly zoom meeting, in case that Regeneration suspects of violation and/or risk of violation of the provisions of these Terms, the provisions of the applicable law or the rights of third parties and/or as a result of technical reasons, including technological changes, or due to the request of the receiving party. Regeneration may also notify You that there is no need for any such Information and therefore no such Information will be uploaded.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Regeneration may, at its sole discretion, refuse to allow You to share Information with others via the Application without the need to receive Your consent or provide You with prior notice, or have you removed from the weekly zoom meeting, in case that Regeneration suspects of violation and/or risk of violation of the provisions of these Terms, the provisions of the applicable law or the rights of third parties and/or as a result of technical reasons, including technological changes, or due to the request of the receiving party. Regeneration may also notify You that there is no need for any such Information and therefore no such Information will be uploaded.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'You hereby confirm and undertake that You are aware that the full responsibility of Information You choose to share with third parties and/or Regeneration lies on You, and that any damage, loss or expense caused by any suit, claim or demand by a third party with respect thereto, will be under Your responsibility and on You exclusively.',
          style: textBodyStyle.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 10),
        Text(
          'You may not make amendments or copies, distribute, transmit, display, execute, reproduce, publish, license, create derivative works, or sell any material received by You via the Application.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Ownership and Intellectual Property Rights',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'You acknowledge and confirm that the Application and/or any materials related thereto including without limitations, images, text designs, software, music, video, graphics tradenames, trademarks and materials contained in advertisements or messages sent to You or commercial information offered to You by Regeneration, or that were created or collected or developed by Regeneration are the exclusive property of Regeneration and/or properly licensed from other third parties and shall remain at Regeneration\'s exclusive property at all times. All intellectual property rights (including, inter alia, copyrights, trade secrets, trademarks, patents, etc.) that exist and/or are embodied in the Application and/or attached, linked, and/or referring to the Application, are the exclusive property of Regeneration and will remain the exclusive property of Regeneration as stated.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'All materials submitted by You or any other user including Information shall be owned by their creator or sender.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'These Terms does not provide You with any rights in the Application and/or regarding it, and/or in any materials to be transferred to You, rather only a limited right to view those materials provided to You in accordance with these Terms and the provisions of the applicable law. Nothing stated in these Terms constitutes a waiver of the intellectual property rights of Regeneration or any third party under any law.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Uses and Restrictions',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Unless if it is expressly permitted in these Terms, You hereby consent that You shall not, without prior written consent of Regeneration: (i) use, modify or integrate the Application into other software, or create derivative works from any part of the Application; (ii) sell, license (or sub-license), lease, assign, transfer, pledge or share Your rights according to these Terms to and with any other person; (iii) distribute or copy the Application for the benefit of third parties; (iv) modify, disassemble, reverse-compile, reverse engineer, update or improve the Application or attempt to discover the source code of the Application.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Maintenance and Support',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Regeneration will have no obligation to provide support, maintenance, upgrades, modifications or new versions of the Application. However, Regeneration may from time to time issue upgraded versions of the Application, and might upgrade electronically and automatically the Application version that You are using on Your Device. You hereby give Your consent to such automatic upgrading, and agree that these Terms apply to all upgrades as stated.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Disclaimers',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'YOU EXPRESSLY ACKNOWLEDGE AND AGREE THAT YOUR USE OF THE APPLICATION INCLUDING ANY DATA THAT YOU DOWNLOAD OR OTHERWISE ACQUIRE THROUGH THE USE OF THE APPLICATION IS AT YOUR SOLE RISK AND ACCORDING TO YOUR OWN DISCRETION AND THAT THE ENTIRE RISK AS TO SATISFACTORY QUALITY, PERFORMANCE, ACCURACY AND EFFORT IS WITH YOU. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THE APPLICATION AND THE DETOX PLAN ARE PROVIDED “AS IS” AND “AS AVAILABLE”, WITH ALL FAULTS AND WITHOUT WARRANTY OF ANY KIND, AND Regeneration HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS WITH RESPECT TO THE APPLICATION, EITHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES AND/OR CONDITIONS OF MERCHANTABILITY, OF SATISFACTORY QUALITY, OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY, OF QUIET ENJOYMENT, AND NON-INFRINGEMENT OF THIRD PARTY RIGHTS.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Regeneration DOES NOT WARRANT AGAINST INTERFERENCE WITH YOUR ENJOYMENT OF THE APPLICATION THAT THE FUNCTIONS CONTAINED IN OR SERVICES PERFORMED OR PROVIDED BY, THE APPLICATION WILL MEET YOUR REQUIREMENTS, THAT THE OPERATION OF THE APPLICATION WILL BE UNINTERRUPTED OR ERROR-FREE, OR THAT DEFECTS IN THE APPLICATION WILL BE CORRECTED. Regeneration ASSUMES NO RESPONSIBILITY FOR ANY ERROR, OMISSION, INTERRUPTION, DELETION, DEFECT, DELAY IN OPERATION OR TRANSMISSION, COMMUNICATIONS LINE FAILURE, DESTRUCTION OR UNAUTHORIZED ACCESS TO, OR ALTERATION OF, ANY COMMUNICATION. Regeneration IS NOT RESPONSIBLE FOR ANY PROBLEMS OR TECHNICAL MALFUNCTION OF ANY HARDWARE OR SOFTWARE, OR TO ANY DAMAGE CAUSED TO USER’S DEVICE RELATED TO OR RESULTING FROM DOWNLOADING OR USING THE APPLICATION.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'UNDER NO CIRCUMSTANCES SHALL Regeneration BE RESPONSIBLE FOR ANY LOSS OR DAMAGE, RESULTING FROM USE OR INABILITY TO USE OR ANY DELAY IN OR MELFUNCTION IN THE APPLICATION.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'TO THE EXTENT PERMITTED BY THE APPLICABLE LAW, Regeneration HEREBY EXPRESSLY EXCLUDES ALL WARRANTIES OF ANY KIND, INCLUDING, INTER ALIA, WARRANTY FOR INTELLECTUAL PROPERTY RIGHTS OR NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Regeneration IS NOT RESPONSIBLE FOR, AND DOES NOT WARRANT WITH RESPECT TO THE ACCURACY LEVEL, COMPLETENESS, USES OR RELIABILITY OF THE APPLICATION\'S PERFORMANCES WHICH WILL BE ACHIEVED THROUGH THE USE OF THE APPLICATION.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Regeneration SHALL HAVE NO LIABILITY FOR ANY INFORMATION INCLUDING THE NATURE ACCURACY, COMPLETENESS, RELIABILITY, PROPRIETARY RIGHTS, QUALITY, AND CONTENT OF INFORMATION THAT WILL BE UPLOADED OR DELIVERED BY OR TO YOU WITHIN THE FRAMEWORK OF THE USE OF THE APPLICATION TO ANY THIRD PARTY AND ALL LIABILITY FOR SUCH INFORMATION WILL BE BORNE BY THE PARTY THAT HAS SENT SUCH INFORMATION  TO YOU EXCLUSIVELY. ',
          style: textBodyStyle.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 10),
        Text(
          'Regeneration IS NOT RESPONSIBLE FOR, AND DOES NOT WARRANT WITH RESPECT TO THE ACCURACY LEVEL, COMPLETENESS, USES OR RELIABILITY OF THE APPLICATION\'S PERFORMANCES WHICH WILL BE ACHIEVED THROUGH THE USE OF THE APPLICATION.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'IT IS HEREBY CLARIFIED TO YOU, THAT THE INFORMATION THAT MAY BE ACCESSED VIA THE APPLICATION MAY BE UPDATED AND/OR AMENDED, FROM TIME TO TIME, AND THAT THE CONTENTS THAT ARE INCLUDED IN THE APPLICATION MAY BE DELETED AND/OR AMENDED WITHOUT PRIOR NOTICE, AND Regeneration, INCLUDING ITS REPRESENTATIVES SHALL NOT BE RESPONSIBLE FOR ANY DAMAGE COST OR EXPENSE, INCURRED IN SUCH CASE.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'THE APPLICATION IS NOT INTENDED TO BE USED IN ANY COUNTRY WHERE SUCH USE WOULD VIOLATE LOCAL LAW OR THAT WOULD SUBJECT Regeneration TO ANY REGULATIONS OF ANOTHER COUNTRY. Regeneration RESERVES THE RIGHT TO LIMIT ITS SERVICES IN ANY COUNTRY.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'TO THE EXTENT YOU CHOOSE TO INSTALL AND USE THE APPLICATION, YOU DO SO AT YOUR OWN INITIATIVE AND ARE RESPONSIBLE FOR COMPLIANCE WITH ANY APPLICABLE LAWS, INCLUDING BUT NOT LIMITED TO APPLICABLE LOCAL LAWS. YOU ARE RESPONSIBLE FOR COMPLYING WITH LOCAL LAWS, IF AND TO THE EXTENT LOCAL LAWS ARE APPLICABLE.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES OR LIMITATIONS ON APPLICABLE STATUTORY RIGHTS OF A CONSUMER, SO THE ABOVE EXCLUSION AND LIMITATIONS MAY NOT APPLY TO YOU.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'LIMITATION OF LIABILITY',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'IN CASE THAT IT WILL BE DETERMINED THAT Regeneration IS LIABLE FOR DAMAGE, COST OR EXPENSE TO ANY THIRD PARTY, Regeneration\'s OBLIGATION SHALL NOT IN ANY WAY EXCEED THE AMOUNT ONE HUNDRED USD (\$100).',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Termination',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Regeneration may terminate the License granted to You for using the Application and/or the Website granted in accordance with these Terms at any time and for any reason. Without derogating from the aforementioned, Your violation of these Terms shall result in the immediate termination of the License provided to You, and You, upon the termination of the License, will cease all further use of the Application.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Governing Law; Jurisdiction',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'These Terms shall be construed and governed under and by the laws of the State of Israel. The parties agree that exclusive venue for any legal action relating hereto shall be in the courts of Tel Aviv - Jaffa. The parties agree not to contest the venue set forth herein and to submit to, and not contest, the exercise of personal jurisdiction over them by any of the foregoing courts.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Indemnification',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'You agree to indemnify and hold Regeneration and its Representatives, harmless from any loss, liability, claim or demand, including reasonable attorney’s fees, made by any third party due to or arising out of Your use of the Application in violation of these Terms or arising from a breach by You of these Terms or any breach in Your representations or warranties\' including with respect to the Information that You transferred via the Application.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Third Party Software',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'The Application may include software that has been supplied by third parties. Such software is provided "as is" without warranty of any kind, and said software will be subject to the limitations and conditions which are required by said third party.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'You hereby acknowledge and agree that these Terms are entered into solely between You and Regeneration, and not with Apple and / or Google, and that Apple and / or Google shall have no liability in connection with the Application. Your use of the Application will be in accordance with the terms of use of Apple or and/or Google and subject to them in addition to these Terms.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Miscellaneous',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'If it is determined that any provision included in these Terms cannot be enforced, then such provision will be removed or redrafted but only to the extent necessary to make it enforceable and other terms will remain valid.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'A printed version of these Terms and any message delivered in electronic form shall constitute admissible evidence in legal or administrative proceedings based or associated with them, equally and under the same terms that apply to other records and business documents originally generated and saved in a printed format.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Any claim suit or demand by You against Regeneration with respect to these Terms and/or the Application and/or the Website will be raised no later than 6 months from the date of the cause for the claim.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'No waiver of any term, provision or condition of these Terms, whether by conduct or otherwise, in any one or more instances, shall be deemed to be, or shall constitute, a waiver of any other term, provision or condition hereof, whether or not similar, nor shall such waiver constitute a continuing waiver of any such term, provision or condition hereof. No waiver shall be binding unless executed in writing by the party making the waiver.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'All notices shall be in writing and shall be deemed to be delivered when sent by first-class mail or when sent by facsimile or e-mail to either parties\' last known post office, facsimile or e-mail address, respectively. You hereby consent to notice by e-mail. All notices shall be directed to the parties at the respective addresses given above or to such other address as either party may, from time to time, provide to the other party.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'If the performance of any part of these Terms by either party is prevented, hindered, delayed or otherwise made impracticable by causes beyond the reasonable control of either party, that party shall be excused from such performance to the extent that it is prevented, hindered or delayed by such causes.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'These Terms supersedes any and all prior or contemporaneous communications, representations, statements and understandings, whether oral or written, between the parties concerning the Application.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'In the event of any conflict between the terms and conditions of these Terms and the terms and conditions of any license agreements appearing with or in the software products comprising the Application, these Terms shall prevail.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'These Terms may not be assigned by You without the prior written consent of Regeneration. Regeneration may assign this Agreement without Your consent.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: 'For information or questions you are welcome to contact Regeneration via e-mail ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'regeneration.today.dror@gmail.com.',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w500, color: kAppColor),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'These Terms were last updated on September 21.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 50),
      ],
    );
  }
}
