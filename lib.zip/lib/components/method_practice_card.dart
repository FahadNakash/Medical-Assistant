import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:transparent_image/transparent_image.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/method_practice_model.dart';
import '../screens/view_method_practice_screen.dart';

class MethodPracticeCard extends StatelessWidget {
  MethodPracticeCard(this.methodPractice, {Key? key}) : super(key: key);
  final MethodPractice methodPractice;
  final AppStateController _controller = AppStateController.controller;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => ViewMethodPracticeScreen(methodPractice),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(top: 10),
        height: 90,
        color: Colors.white,
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black26,
                        offset: Offset(0, 2),
                        blurRadius: 4,
                      )
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: Stack(
                      children: [
                        Container(
                            height: 60,
                            width: 80,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: FadeInImage(
                              placeholder: MemoryImage(kTransparentImage),
                              image: NetworkImage(
                                YoutubePlayer.getThumbnail(
                                  videoId: YoutubePlayer.convertUrlToId(methodPractice.videoUrl) ?? '',
                                ),
                              ),
                              fadeInDuration: const Duration(milliseconds: 500),
                              fit: BoxFit.fill,
                              imageErrorBuilder: (context, error, stackTrace) {
                                return Icon(
                                  Icons.image_outlined,
                                  color: kAppColor.withAlpha(150),
                                  size: 45,
                                );
                              },
                            )),
                        Positioned(
                          top: 0,
                          child: Container(
                            height: 8,
                            width: 80,
                            color: Colors.white,
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          child: Container(
                            height: 8,
                            width: 80,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    height: 89,
                    padding: const EdgeInsets.only(top: 5),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Flexible(
                          child: Text(
                            methodPractice.title,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: kDarkBlue.withAlpha(200),
                              fontSize: 22,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        Flexible(
                          child: Text(
                            methodPractice.description,
                            overflow: TextOverflow.ellipsis,
                            maxLines: 3,
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: kDarkBlue.withAlpha(150)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Obx(
                  () {
                    return Container(
                      alignment: Alignment.topCenter,
                      height: 70,
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      child: Icon(
                        Icons.remove_red_eye,
                        color: _controller.watchedVideos.contains(methodPractice.id) ? Colors.lime.shade600 : kGrey.withAlpha(50),
                        size: 25,
                      ),
                    );
                  },
                ),
              ],
            ),
            const Divider(
              height: 1,
              indent: 30,
              endIndent: 45,
            ),
          ],
        ),
      ),
    );
  }
}
