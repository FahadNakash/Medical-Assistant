import 'dart:io';

import 'package:flutter/material.dart';

import '../constants.dart';

class ProfileSelector extends StatelessWidget {
  const ProfileSelector({this.userImgUrl = '', this.image, this.onSelect, Key? key}) : super(key: key);
  final String userImgUrl;
  final File? image;
  final VoidCallback? onSelect;

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return GestureDetector(
        onTap: onSelect,
        child: Stack(
          children: [
            ClipRRect(
              borderRadius: kEnabledBorderRadius,
              child: image == null
                  ? Container(
                      constraints: BoxConstraints.tightFor(
                        height: size.width * 0.45,
                        width: size.width * 0.45,
                      ),
                      decoration: BoxDecoration(
                        borderRadius: kEnabledBorderRadius,
                        color: kAppColor.withAlpha(20),
                      ),
                      child: userImgUrl.isEmpty
                          ? Icon(
                              Icons.image,
                              color: kAppColor.withAlpha(200),
                              size: 100,
                            )
                          : Image.network(
                              userImgUrl,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Icon(
                                Icons.image,
                                color: Colors.red.withAlpha(200),
                                size: 100,
                              ),
                            ),
                    )
                  : Container(
                      color: kAppColor.withAlpha(20),
                      constraints: BoxConstraints.expand(width: size.width * 0.45, height: size.width * 0.45),
                      child: Image.file(
                        image!,
                        fit: BoxFit.cover,
                      ),
                    ),
            ),
            Positioned(
              bottom: 8,
              right: 8,
              child: Container(
                padding: const EdgeInsets.all(3),
                child: Icon(userImgUrl.isEmpty && image == null ? Icons.add : Icons.edit, color: kAppColor.withOpacity(0.7), size: 28),
                decoration: BoxDecoration(
                  color: kAppColor.withOpacity(0.3),
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ],
        ));
  }
}
