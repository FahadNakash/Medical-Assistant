import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants.dart';

class ConfirmationDialog extends StatelessWidget {
  const ConfirmationDialog({
    required this.alertMessage,
    this.title,
    this.confirmCallback,
    this.cancelCallback,
    this.confirmLabel,
    this.cancelLabel,
    Key? key,
  }) : super(key: key);

  final String alertMessage;
  final String? title;
  final String? confirmLabel;
  final String? cancelLabel;
  final VoidCallback? confirmCallback;
  final VoidCallback? cancelCallback;
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        title ?? 'alert'.tr,
        style: const TextStyle(color: kAppColor, fontSize: 25),
      ),
      content: Text(alertMessage),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
      actions: <Widget>[
        GestureDetector(
          child: Container(
            constraints: const BoxConstraints.tightFor(width: 90, height: 35),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(5),
              border: Border.all(color: kAppColor.withAlpha(200), width: 1),
              boxShadow: [
                BoxShadow(
                  color: kAppColor.withAlpha(100),
                  offset: const Offset(0, 2),
                  blurRadius: 4,
                ),
              ],
            ),
            child: Center(
              child: Text(
                cancelLabel ?? 'cancel'.tr,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  color: kAppColor.withAlpha(200),
                ),
              ),
            ),
          ),
          onTap: cancelCallback ?? () => Navigator.of(context).pop(false),
        ),
        GestureDetector(
          child: Container(
            constraints: const BoxConstraints.tightFor(width: 90, height: 35),
            decoration: BoxDecoration(
              color: kAppColor.withAlpha(200),
              borderRadius: BorderRadius.circular(5),
              boxShadow: [
                BoxShadow(
                  color: kAppColor.withAlpha(128),
                  offset: const Offset(0, 2),
                  blurRadius: 6,
                ),
              ],
            ),
            child: Center(
              child: Text(
                confirmLabel ?? 'confirm'.tr,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          onTap: confirmCallback ?? () => Navigator.of(context).pop(true),
        ),
      ],
    );
  }
}
