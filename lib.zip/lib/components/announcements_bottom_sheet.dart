import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants.dart';
import '../models/announcement_model.dart';

class AnnouncementsBottomSheet extends StatelessWidget {
  const AnnouncementsBottomSheet(this.name, {required this.announcements, Key? key}) : super(key: key);
  final List<Announcement> announcements;
  final String name;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    List<Widget> announcementWidgets = [];
    announcementWidgets.add(Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
          margin: const EdgeInsets.only(top: 10, bottom: 10),
          decoration: BoxDecoration(
            border: Border.all(color: kDarkBlue, width: 0.5),
            borderRadius: kEnabledBorderRadius,
          ),
          child: Text(
            'annoucnement_len_txt'.trArgs([announcements.length.toString()]),
            style: kCardBodyStyle,
          ),
        ),
      ],
    ));
    if (announcements.isNotEmpty) {
      for (var element in announcements) {
        announcementWidgets.add(Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      element.title,
                      style: const TextStyle(color: kAppColor, fontSize: 28, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  element.announcement.replaceAll('{fname}', name),
                  style: const TextStyle(fontSize: 23, color: Colors.black),
                ),
              ),
              const Divider(),
            ],
          ),
        ));
      }
    } else {
      announcementWidgets.add(Center(
        child: Container(
          padding: const EdgeInsets.all(15),
          margin: const EdgeInsets.only(top: 100),
          decoration: BoxDecoration(
            color: kAppColor.withAlpha(20),
            borderRadius: kFocusedBorderRadius,
          ),
          child: Text(
            'no_announcement_err'.tr,
            style: kUnselectedTextStyle,
            textAlign: TextAlign.center,
          ),
        ),
      ));
    }
    return Container(
      height: size.height * 0.6,
      width: size.width,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(15),
          topRight: Radius.circular(15),
        ),
      ),
      child: ListView(
        physics: const BouncingScrollPhysics(),
        children: announcementWidgets,
      ),
    );
  }
}
