import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/post_recipe.dart';
import 'custom_text_field.dart';

class AddRecipeScreen extends StatefulWidget {
  const AddRecipeScreen({this.postRecipe, Key? key}) : super(key: key);
  final PostRecipe? postRecipe;

  @override
  State<AddRecipeScreen> createState() => _AddRecipeScreenState();
}

class _AddRecipeScreenState extends State<AddRecipeScreen> {
  String title = '';
  // String language = kEnglishLocale;
  // TextDirection textDirection = TextDirection.ltr;
  String? _titleErrorText;
  List<String> ingredients = [];
  String? _ingredientsErrorText;
  List<String> steps = [];
  String category = '';
  String? _stepsErrorText;
  String? _categoryErrorText;
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _ingredientsController = TextEditingController();
  final TextEditingController _stepsController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.postRecipe != null) {
      final rec = widget.postRecipe!;
      title = rec.title;
      _titleController.text = rec.title;
      category = rec.category;
      ingredients = List.from(rec.ingredients);
      steps = List.from(rec.steps);
    }
  }

  @override
  dispose() {
    _titleController.dispose();
    _ingredientsController.dispose();
    _stepsController.dispose();
    super.dispose();
  }

  _validateAllFields() {
    if (title.isEmpty) {
      _titleErrorText = 'required_field_err'.tr;
    } else {
      _titleErrorText = null;
    }
    if (ingredients.isEmpty) {
      _ingredientsErrorText = 'add_1_ingredient_err'.tr;
    } else {
      _ingredientsErrorText = null;
    }
    if (steps.isEmpty) {
      _stepsErrorText = 'add_1_step_err'.tr;
    } else {
      _stepsErrorText = null;
    }
    if (category.isEmpty) {
      _categoryErrorText = 'slct_one_err'.tr;
    } else {
      _categoryErrorText = null;
    }
    setState(() {});
  }

  List<Widget> drawIngredientsColumn() {
    List<Widget> ingredientsColumnList = <Widget>[];
    if (ingredients.isNotEmpty) {
      for (String ingredient in ingredients) {
        ingredientsColumnList.add(Container(
          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 2),
          padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 10),
          decoration: kSelectedBoxDecoration,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                ingredient,
                // textDirection: textDirection,
                style: kSelectedTextStyle,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 3),
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      ingredients.remove(ingredient);
                    });
                  },
                  child: const Icon(
                    Icons.remove_circle_outline,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
              ),
            ],
          ),
        ));
      }
    }
    return ingredientsColumnList;
  }

  List<Widget> drawRecipeSteps() {
    List<Widget> stepsColumnList = <Widget>[];
    if (steps.isNotEmpty) {
      for (int i = 0; i < steps.length; i++) {
        stepsColumnList.add(Container(
          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 2),
          padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 10),
          decoration: kSelectedBoxDecoration,
          child: Column(
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    'steps'.trArgs(['${i + 1}']),
                    textDirection: Get.locale?.languageCode == 'en' ? TextDirection.rtl : TextDirection.ltr,
                    style: const TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 3, right: 3),
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          steps.removeAt(i);
                        });
                      },
                      child: const Icon(
                        Icons.remove_circle_outline,
                        color: Colors.white,
                        size: 22,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Text(
                steps[i],
                // textDirection: textDirection,
                style: kSelectedTextStyle,
              )
            ],
          ),
        ));
      }
    }
    return stepsColumnList;
  }

  Widget getCategoryWidget(int i) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        GestureDetector(
          onTap: () {
            _categoryErrorText = null;
            setState(() => category = PostRecipe.categoriesList[i]);
          },
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 15),
            decoration: BoxDecoration(
              color: PostRecipe.categoriesList[i] == category ? kAppColor.withOpacity(0.7) : Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black26,
                  offset: Offset(0, 2),
                  blurRadius: 4,
                )
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Container(
                height: 55,
                width: 55,
                padding: const EdgeInsets.all(10),
                color: Colors.transparent,
                child: Image.asset(
                  '$assets/icons${i + 1}.png',
                  color: PostRecipe.categoriesList[i] == category ? Colors.white : null,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 5),
        Text(
          PostRecipe.categoriesList[i].toLowerCase().tr,
          textAlign: TextAlign.center,
          style: kUnselectedTextStyle.copyWith(fontWeight: FontWeight.w500),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.25,
        maxChildSize: 1,
        builder: (_, scrollController) {
          return ClipRRect(
            borderRadius: kTLRBorderRadius,
            child: Container(
              color: Colors.white,
              child: SingleChildScrollView(
                controller: scrollController,
                child: Padding(
                  padding: EdgeInsets.only(top: 10, bottom: MediaQuery.of(context).viewInsets.bottom + 10),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: Text(
                              'add_recipe'.tr,
                              style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w500, color: kDarkGrey),
                            ),
                          ),
                          TextButton(
                            child: Text(
                              'done'.tr,
                              style: const TextStyle(color: kAppColor, fontWeight: FontWeight.bold),
                            ),
                            onPressed: () {
                              _validateAllFields();
                              if (_titleErrorText == null && _ingredientsErrorText == null && _stepsErrorText == null) {
                                AppStateController.controller.newRecipe = PostRecipe(
                                  language: Get.locale!.languageCode == 'en' ? kEnglishLocale : kHebrewLocale,
                                  title: title,
                                  category: category,
                                  ingredients: ingredients,
                                  steps: steps,
                                );
                                Navigator.of(context).pop();
                              }
                            },
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                        child: Row(
                          children: [
                            Text(
                              'select_type'.tr,
                              style: kBodyStyle,
                            ),
                            const SizedBox(width: 10),
                            _categoryErrorText == null
                                ? const SizedBox.shrink()
                                : Text(
                                    _categoryErrorText!,
                                    style: const TextStyle(height: 1.5, fontSize: 13, color: Colors.red),
                                  )
                          ],
                        ),
                      ),
                      Container(
                        height: 100,
                        decoration: BoxDecoration(
                          color: _categoryErrorText == null ? kAppColor.withAlpha(20) : Colors.red.shade50,
                          borderRadius: kFocusedBorderRadius,
                        ),
                        alignment: Alignment.center,
                        width: double.infinity,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: PostRecipe.categoriesList.length,
                          itemBuilder: (context, i) {
                            return getCategoryWidget(i);
                          },
                        ),
                      ),
                      const SizedBox(height: 20),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 5),
                        child: CustomTextField(
                          width: size.width * 0.85,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          textController: _titleController,
                          labelText: 'add_title'.tr,
                          // textDirection: textDirection,
                          // textAlign: language == kEnglishLocale ? TextAlign.left : TextAlign.right,
                          errorText: _titleErrorText,
                          textInputAction: TextInputAction.done,
                          onChanged: (value) {
                            title = value;
                            if (_titleErrorText != null) {
                              _validateAllFields();
                            }
                          },
                        ),
                      ),
                      const SizedBox(height: 20),
                      CustomTextField(
                        height: 55,
                        width: size.width * 0.85,
                        textController: _ingredientsController,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        // textDirection: textDirection,
                        // textAlign: language == kEnglishLocale ? TextAlign.left : TextAlign.right,
                        labelText: 'add_ingredients'.tr,
                        helperText: "",
                        hintText: null,
                        errorText: _ingredientsErrorText,
                        textInputAction: TextInputAction.done,
                        obscureText: false,
                        suffix: IconButton(
                            icon: Icon(
                              Icons.add_circle_outline,
                              color: Colors.lime.shade700,
                              size: 24,
                            ),
                            onPressed: () {
                              if (_ingredientsController.text.isNotEmpty && !ingredients.contains(_ingredientsController.text.trim())) {
                                setState(() {
                                  ingredients.add(_ingredientsController.text.trim());
                                });
                                _ingredientsController.clear();
                              }
                              if (_ingredientsErrorText != null) {
                                _validateAllFields();
                              }
                            }),
                      ),
                      ingredients.isNotEmpty
                          ? Container(
                              width: size.width,
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: kAppColor.withAlpha(20),
                                borderRadius: kFocusedBorderRadius,
                              ),
                              child: Wrap(
                                alignment: WrapAlignment.center,
                                children: drawIngredientsColumn(),
                              ),
                            )
                          : const SizedBox.shrink(),
                      const SizedBox(height: 20),
                      CustomTextField(
                        height: 55,
                        width: size.width * 0.85,
                        textController: _stepsController,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        // textDirection: textDirection,
                        // textAlign: language == kEnglishLocale ? TextAlign.left : TextAlign.right,
                        labelText: 'add_steps'.tr,
                        helperText: "",
                        hintText: null,
                        errorText: _stepsErrorText,
                        textInputAction: TextInputAction.done,
                        obscureText: false,
                        suffix: IconButton(
                            icon: Icon(
                              Icons.add_circle_outline,
                              color: Colors.lime.shade700,
                              size: 24,
                            ),
                            onPressed: () {
                              if (_stepsController.text.isNotEmpty) {
                                setState(() {
                                  steps.add(_stepsController.text.trim());
                                });
                                _stepsController.clear();
                              }
                              if (_stepsErrorText != null) {
                                _validateAllFields();
                              }
                            }),
                      ),
                      steps.isNotEmpty
                          ? Container(
                              width: size.width,
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: kAppColor.withAlpha(20),
                                borderRadius: kFocusedBorderRadius,
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: drawRecipeSteps(),
                              ),
                            )
                          : const SizedBox.shrink(),
                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }
}
