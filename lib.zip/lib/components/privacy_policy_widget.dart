import 'package:flutter/material.dart';

import '../constants.dart';

class PrivacyPolicy extends StatelessWidget {
  const PrivacyPolicy({Key? key}) : super(key: key);
  final mainTitleStyle = const TextStyle(fontFamily: 'Trajan', color: kAppColor, fontSize: 30, decoration: TextDecoration.underline);
  final textBodyStyle = const TextStyle(fontFamily: 'Montserrat', color: Colors.black, fontSize: 17, height: 1.5);
  final spanBodyStyle = const TextStyle(fontFamily: 'Montserrat', color: Colors.black, fontSize: 14, height: 1.5);
  final smallTitleStyle = const TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.w600, decoration: TextDecoration.underline);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Align(
          alignment: Alignment.center,
          child: Text(
            'Privacy Policy',
            style: mainTitleStyle,
          ),
        ),
        const SizedBox(height: 20),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: 'WE, AT ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'Regeneration ("WE")',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: ' TAKE YOUR PRIVACY SERIOUSLY. WE RESPECT AND PROTECT THE PRIVACY OF OUR USERS AND TAKE APPROPRIATE STEPS TO SAFEGUARD THEIR PERSONAL INFORMATION. THIS PRIVACY POLICY ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: '(THE “POLICY”)',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: ' EXPLAINS THE TYPES OF INFORMATION THAT WE RECEIVE AND COLLECT WHEN YOU USE OUR APPLICATION AND THE RELATED SERVICES OFFERED BY US AS PART OF THE APPLICATION ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: '(THE "SERVICES"),',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: ' AND DESCRIBE THE WAYS WE USE AND PROTECT THEM.',
                style: spanBodyStyle,
              ),
              TextSpan(
                text:
                    '\n\nTHE USE OF THE APPLICATION AND/OR ANY OF THE SERVICES, IS SUBJECT TO THE PROVISIONS OF THIS POLICY.\n\nTHIS POLICY MAY BE UPDATED FROM TIME TO TIME, THEREFORE WE ASK YOU TO CHECK BACK PERIODICALLY FOR THE MOST UPDATED POLICY, AS INDICATED BELOW. YOUR USE IN THE APPLICATION AND/OR YOUR USE OF ANY OF OUR SERVICES, AFTER THIS POLICY HAS BEEN AMENDED, SHALL BE DEEMED TO BE YOUR CONTINUED ACCEPTANCE OF THE TERMS OF THIS POLICY, AS AMENDED.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'Information we collect',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Our primary goal in collecting personal information is to provide You, the user of the Application and/or receiving Services therein, with a customized and efficient experience, and therefore We only collect personal information that is relevant for such purpose.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Personal Information means information that identifies or could be used to identify an individual, directly or indirectly.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'We collect the following types of information from our users (collectively the "Information"):',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: '   1.	Registration Data. ',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: 'As a condition for the use of the Application, and engaging with us, You will be required to provide certain information concerning You, and provide certain Personal Information such as Email, phone number (the ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: '"Registration Data"',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: ') We will not sell, trade or rent your Registration Data to others, except as specified in this Policy. You may review and edit your Registration Data by using your login details (username and Password).',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: '   2.  Automatic Tracking. ',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text:
                    'By the nature of its functionality, the Application will be able to, and may track certain information about You, in order to perform internal research on our users demographics, interests, site usage patterns and behavior. This information is collected in an aggregate form, without usually identifying any user individually, except with respect to user IP Address that is considered as personal information. Non-personally identifiable information may be analyzed by us for the purpose of improving and expanding the functionality of our Services as well as to improve the Application.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: '   3. Personal Information. ',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w600),
              ),
              TextSpan(
                text: 'As part of your use of the Application, You shall be required to provide information concerning You, that includes Weight, height, blood test values that part of it is mandatory and part is voluntary.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'Cookies',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'What are cookies?\n\nCookies are very small text files that are stored on your computer when You visit certain websites and can store information about your use of the Application.\n\nWe use a combination of few types of cookies such as session cookies and persistent cookies, in order to track, how use and experience the Application, build anonymous statistical data about how the Application is performing, to make the Services more customized and to inform us of a repeat visit without knowing who a visitor is or its personal information',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Usage of Information',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: '   a.   ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'Internal Use. ',
                style: spanBodyStyle.copyWith(decoration: TextDecoration.underline),
              ),
              TextSpan(
                text:
                    'We use the Information collected for internal purposes, to improve the Application and the Services we provide, and to better tailor them to meet your needs. In addition, We use the Information collected to analyze usage, and to deliver You information about certain promotions, services or items that might interest You. We may use Your e-mail address to contact You from time to time, in order to notify You about new services and updates. If You do not wish to receive such mailings, simply notify us in You can always unsubscribe from the email within the email.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: '   b.   ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'We will use the Personal Information in order to improve the use of the Application.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: '   c.   ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'Improving Software and Resolving Problems. ',
                style: spanBodyStyle.copyWith(decoration: TextDecoration.underline),
              ),
              TextSpan(
                text: 'We may use Information collected to resolve disputes and troubleshoot problems in the Application or improve the Application.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: '   d.   ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'Advertising. ',
                style: spanBodyStyle.copyWith(decoration: TextDecoration.underline),
              ),
              TextSpan(
                text:
                    'We may advertise and promote the Application or any of the Services and its contents, however, We will not disclose, sell or transfer any Information (other than automatic tracking) or any personal information to any third parties for the purpose of advertising or promotion (e.g., advertisers or business partners), except as specified in this Policy.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: '   e.   ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'Third Parties. ',
                style: spanBodyStyle.copyWith(decoration: TextDecoration.underline),
              ),
              TextSpan(
                text:
                    'We may at any time add affiliate partners or 3rd party content providers to our Application, but the sharing of information with them will be limited to only statistical information. You further consent to permit us, to process and transfer the Information collected by us, as necessary for us to provide You with our Service.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: '   f.   ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'Special Cases. ',
                style: spanBodyStyle.copyWith(decoration: TextDecoration.underline),
              ),
              TextSpan(
                text:
                    'We may disclose Information collected, in special cases when we were ordered to do so by a judicial authority, to respond to subpoenas, court orders and law enforcement or government request or when we have reason to believe that disclosing such information is necessary to identify, contact or bring legal action against someone who may be violating this Policy or may be causing injury to or interference with (either intentionally or unintentionally), our rights or property, other users, or anyone else that could be harmed by such activities.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'Protection of Information',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Personal Information is encrypted and protected by firewall and by Secure Sockets Layer (SSL), the industry standard, for encrypting all personal information, including name, address and credit card numbers.\n\nAlthough, We use industry standard practices to protect your privacy, We do not guarantee, and You should not expect that Information collected will always remain completely private.\n\nWhile we use encryption to protect sensitive information transmitted online, we also protect your information offline. Only employees who need the information to perform a specific work are granted access to personally identifiable information. The computers/servers in which we store personally identifiable information are kept in a secure environment.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Links and Displayed Sites',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'The Application includes sending links or references of third parties. However, we do not have control over such third-party websites and businesses or their information collection practices and we are not responsible for the privacy practices or the content of such linked or otherwise displayed sites.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Disclosure of Information to Third Parties',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Our policy only addresses the use and disclosure of information We collect from You. To the extent that You disclose information to other parties via the Application, different rules may apply to the use or disclosure of the personal information, which You disclose to them. We do not control the privacy policies of third parties and You will be subject to the privacy customs and policies of such third parties.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Disclosure Information in the Event of a Merger',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'We may merge or be acquired by another business entity or may sell all or substantially all of our assets to an acquirer. In the event of such merger, acquisition or sale, We may share some or all or your personally identifiable information with the acquiring company in order to continue serving You the Services. In such event and if applicable, We will provide notice that such information is transferred and becomes subject to a different privacy policy.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Access to your personal information',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: 'You have the right to view, amend, or delete the personal information that we have collected and hold about You, and the way it is processed. To request access, please email ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'regeneration.today.dror@gmail.com',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w500, color: kAppColor),
              ),
              TextSpan(
                text:
                    ' and We will provide the information free of charge in a commonly use and machine readable format within 14 days, and You shall have the right to transmit that data to any third party, except in the event that the request is unfounded, excessive or repetitive, in which case we reserve the right to charge a proportionate administration fee or refuse.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'Rectification of personal information',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'If any of the information we hold on You is inaccurate or incomplete, You may ask us to correct or complete it at any time.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 20),
        Text(
          'Your right of Deletion, or to be forgotten',
          style: smallTitleStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'You may request the deletion of any and all materials that we have collected and saved with respect to You, at any time and to request that we cease further dissemination of the data, and have third parties cease processing of the data.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        Text(
          'Be aware that requesting deletion, unlike unsubscribing, is total and irreversible. This means that we will also lose record of You having ever been on our systems. If You choose in the future to open a new account, You will appear to us as completely new customer.',
          style: textBodyStyle,
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: 'To request deletion of your personal information, contact ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: 'regeneration.today.dror@gmail.com',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w500, color: kAppColor),
              ),
              TextSpan(
                text: ' using the email address, and full name identified in your Account.',
                style: spanBodyStyle,
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: 'If you have any questions about this Policy, please contact us at ',
                style: spanBodyStyle,
              ),
              TextSpan(
                text: '972508714344',
                style: spanBodyStyle.copyWith(fontWeight: FontWeight.w500, color: kAppColor),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'Last Updated September, 2021',
          style: textBodyStyle,
        ),
        const SizedBox(height: 50),
      ],
    );
  }
}
