import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants.dart';

class ShowDialog extends StatelessWidget {
  const ShowDialog({this.title, required this.alertMessage, this.onTap, Key? key}) : super(key: key);
  final String alertMessage;
  final String? title;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        title ?? 'alert'.tr,
        style: const TextStyle(color: kAppColor, fontSize: 25),
      ),
      content: Text(alertMessage),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
      actions: <Widget>[
        GestureDetector(
          child: Container(
            constraints: const BoxConstraints.tightFor(width: 48, height: 48),
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: kAppColor,
                  offset: Offset(0, 0),
                  blurRadius: 4,
                ),
              ],
            ),
            child: Center(
              child: Text(
                'ok'.tr,
                style: TextStyle(
                  fontSize: 22,
                  fontFamily: 'Montserrat',
                  fontWeight: FontWeight.w500,
                  color: kAppColor.withAlpha(200),
                ),
              ),
            ),
          ),
          onTap: onTap ??
              () {
                Navigator.of(context).pop();
              },
        )
      ],
    );
  }
}
