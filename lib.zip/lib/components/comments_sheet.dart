import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/comment_model.dart';
import '../models/post_model.dart';
import '../services/firestore_helper.dart';
import 'comment_card.dart';
import 'custom_text_field.dart';

class CommentsSheet extends StatefulWidget {
  const CommentsSheet(this.post, {Key? key}) : super(key: key);
  final Post post;

  @override
  State<CommentsSheet> createState() => _CommentsSheetState();
}

class _CommentsSheetState extends State<CommentsSheet> {
  final AppStateController _controller = AppStateController.controller;
  final TextEditingController _fieldController = TextEditingController();
  int? _totalComments;

  @override
  void dispose() {
    super.dispose();
    _fieldController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: StreamBuilder<QuerySnapshot<Object?>>(
          stream: FirestoreHelper.forumRef.doc(kForumId).collection('posts').doc(widget.post.id).collection('comments').snapshots(),
          builder: (context, snap) {
            return DraggableScrollableSheet(
                initialChildSize: 0.7,
                minChildSize: 0.25,
                maxChildSize: 1,
                builder: (context, scrollController) {
                  if (snap.data != null) {
                    if ((snap.data?.size ?? -1) > 0) {
                      List<Comment> _comments = snap.data?.docs.map<Comment>((e) => Comment.fromMap(e.data() as Map<String, dynamic>)).toList() ?? [];
                      if (_comments.length > 1) {
                        _comments.sort((a, b) => b.dateTime.compareTo(a.dateTime));
                      }
                      _totalComments = _comments.length;
                      return ClipRRect(
                        borderRadius: kTLRBorderRadius,
                        child: Container(
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            borderRadius: kTLRBorderRadius,
                          ),
                          child: Column(
                            children: [
                              Flexible(
                                child: ListView.builder(
                                  physics: const BouncingScrollPhysics(),
                                  padding: const EdgeInsets.only(left: 10, right: 10, top: 10),
                                  controller: scrollController,
                                  itemCount: _comments.length,
                                  itemBuilder: (_, i) {
                                    return CommentCard(_comments[i]);
                                  },
                                ),
                              ),
                              Flexible(
                                flex: 0,
                                child: Padding(
                                  padding: EdgeInsets.only(top: 4, bottom: MediaQuery.of(context).viewInsets.bottom + 4, left: 8, right: 8),
                                  child: CustomTextField(
                                    height: 45,
                                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                    hintText: 'write_comment'.tr,
                                    textController: _fieldController,
                                    textInputAction: TextInputAction.newline,
                                    maxLines: 10,
                                    suffix: IconButton(
                                        icon: Icon(
                                          Icons.send,
                                          color: kAppColor.withOpacity(0.7),
                                        ),
                                        onPressed: () => _addComment()),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }
                  }

                  _totalComments = 0;
                  return Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: kTLRBorderRadius,
                    ),
                    child: Column(
                      children: [
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.all(15),
                          // margin: const EdgeInsets.only(bottom: 100),
                          decoration: BoxDecoration(
                            color: kAppColor.withAlpha(20),
                            borderRadius: kFocusedBorderRadius,
                          ),
                          child: Text(
                            'no_comments_err'.tr,
                            style: kUnselectedTextStyle,
                            textAlign: TextAlign.center,
                          ),
                        ),
                        const Spacer(),
                        Padding(
                          padding: EdgeInsets.only(top: 4, bottom: MediaQuery.of(context).viewInsets.bottom + 4, left: 8, right: 8),
                          child: CustomTextField(
                            height: 45,
                            hintText: 'write_comment'.tr,
                            textController: _fieldController,
                            onFieldSubmitted: (_) => _addComment(),
                            suffix: IconButton(
                                icon: Icon(
                                  Icons.send,
                                  color: kAppColor.withOpacity(0.7),
                                ),
                                onPressed: () => _addComment()),
                          ),
                        ),
                      ],
                    ),
                  );
                });
          }),
    );
  }

  _addComment() {
    try {
      if (_fieldController.text.isEmpty) {
        return;
      }
      final commentDoc = FirestoreHelper.getNewCommentDoc(widget.post.id);
      final user = _controller.userModel.value;
      Comment comment = Comment(
        id: commentDoc.id,
        comment: _fieldController.text,
        forumID: kForumId,
        postID: widget.post.id,
        userName: user.fName + ' ' + user.lName,
        userImgUrl: user.userImgUrl,
        language: Get.locale!.languageCode == 'en' ? kEnglishLocale : kHebrewLocale,
        dateTime: DateTime.now(),
      );
      commentDoc.set(comment.toMap());
      FirebaseFirestore.instance.collection('forums').doc(kForumId).collection('posts').doc(widget.post.id).update({'comments': (_totalComments ?? 0) + 1});
      _fieldController.clear();
    } catch (e) {
      print(e);
    }
  }
}
