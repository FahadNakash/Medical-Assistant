import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

import '../../components/bmi_gauge.dart';
import '../../components/main_button.dart';
import '../../constants.dart';
import '../../models/batch_model.dart';
import '../../models/questionnaire_model.dart';
import '../../utils/utils.dart';

class EndingSlide extends StatelessWidget {
  const EndingSlide({
    required this.pageController,
    required this.showIndicator,
    required this.onSubmit,
    required this.userQuestionnaire,
    required this.fillLater,
    required this.userBatch,
    Key? key,
  }) : super(key: key);
  final PageController pageController;
  final VoidCallback onSubmit;
  final bool showIndicator;
  final Questionnaire userQuestionnaire;
  final bool fillLater;
  final Batch? userBatch;

  Widget getOption(String key) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      margin: const EdgeInsets.all(6),
      decoration: kSelectedBoxDecoration,
      child: Text(
        key,
        style: kSelectedTextStyle.copyWith(fontSize: 15),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return NotificationListener<OverscrollIndicatorNotification>(
      onNotification: (OverscrollIndicatorNotification scrollEndNotification) {
        scrollEndNotification.disallowGlow();
        return true;
      },
      child: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 10),
              SizedBox(
                width: size.width * 0.9,
                child: Text('endng_slde_hdng'.tr, textAlign: TextAlign.center, style: kBodyStyle.copyWith(color: kDarkGrey, fontWeight: FontWeight.w500)),
              ),
              const SizedBox(height: 15),
              SizedBox(
                width: size.width * 0.9,
                child: Text.rich(
                  TextSpan(text: 'welcome_scr_prep_data'.tr + ':\n', style: kBodyStyle, children: [
                    TextSpan(text: getBatchDate(userBatch!.startingDate.subtract(Duration(days: Questionnaire.coffeeOptions[userQuestionnaire.cupsOfCoffee]!))), style: const TextStyle(fontSize: 20, color: kAppColor, fontWeight: FontWeight.w600, decoration: TextDecoration.underline)),
                  ]),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: size.width * 0.9,
                child: Text.rich(
                  TextSpan(text: 'welcome_scr_hdng2'.tr + ':\n', style: kBodyStyle, children: [
                    TextSpan(text: getBatchDate(userBatch!.startingDate), style: const TextStyle(fontSize: 20, color: kAppColor, fontWeight: FontWeight.w600, decoration: TextDecoration.underline)),
                  ]),
                  textAlign: TextAlign.center,
                ),
              ),
              const Divider(indent: 10, endIndent: 10),
              Text(
                'endng_slde_hdng2'.tr,
                textAlign: TextAlign.center,
                style: kBodyStyle,
              ),
              const SizedBox(height: 10),
              Wrap(
                alignment: WrapAlignment.center,
                children: userQuestionnaire.purpose.map((p) => getOption(Questionnaire.purposeKeyMap[p]!.tr)).toList(),
              ),
              if (!fillLater)
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 15),
                  padding: const EdgeInsets.all(15),
                  decoration: kUnselectedBoxDecoration,
                  width: size.width * 0.9,
                  child: Column(
                    children: [
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Text('q1_slide_height'.tr, style: kPropertyStyle),
                              const SizedBox(width: 10),
                              Text(userQuestionnaire.height.toString() + (userQuestionnaire.isMetric ? ' cm' : ' inch'), style: kBodyStyle.copyWith(color: kAppColor)),
                            ],
                          ),
                          Row(
                            children: [
                              Text('q1_slide_weight'.tr, style: kPropertyStyle),
                              const SizedBox(width: 10),
                              Text(userQuestionnaire.weight.toString() + (userQuestionnaire.isMetric ? ' kg' : ' lbs'), style: kBodyStyle.copyWith(color: kAppColor)),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 15),
                      SizedBox(
                        width: size.width * 0.7,
                        height: 250,
                        child: BMIGauge(
                          title: GaugeTitle(text: 'bmi'.tr, textStyle: kPropertyStyle),
                          bmi: calculateBMI(userQuestionnaire.height!.toInt(), userQuestionnaire.weight!.toInt()),
                          initialAnimation: true,
                          canScaleToFit: true,
                          radiusFactor: 1.2,
                        ),
                      ),
                      SizedBox(width: size.width * 0.8, child: Text('bmi_option_info'.tr, style: const TextStyle(fontSize: 15, color: Colors.grey), textAlign: TextAlign.center)),
                    ],
                  ),
                ),
              const SizedBox(height: 30),
              showIndicator
                  ? Column(
                      children: [
                        const SizedBox(
                          height: 25,
                          width: 25,
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation(kAppColor),
                            strokeWidth: 1,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'pls_wait'.tr,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: kAppColor,
                          ),
                        ),
                      ],
                    )
                  : MainButton(title: 'next'.tr, onTap: onSubmit),
              const SizedBox(height: 50),
            ],
          ),
        ),
      ),
    );
  }

  num calculateBMI(int height, int weight) {
    if (userQuestionnaire.isMetric) {
      return getMetricBMI(height, weight);
    } else {
      return getImperialBMI(height, weight);
    }
  }
}
