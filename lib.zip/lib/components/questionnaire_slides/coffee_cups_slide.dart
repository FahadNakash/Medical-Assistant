import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../constants.dart';
import '../../models/questionnaire_model.dart';

class CoffeeCupsSlide extends StatelessWidget {
  const CoffeeCupsSlide({required this.cupsOfCoffee, required this.coffeeErrTxt, required this.onChanged, Key? key}) : super(key: key);
  final String? cupsOfCoffee;
  final String? coffeeErrTxt;
  final Function onChanged;

  Widget getOption(String key) {
    return GestureDetector(
      onTap: () {
        onChanged(key);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(key, style: TextStyle(color: cupsOfCoffee == key ? Colors.white : kAppColor, fontSize: 25, fontWeight: FontWeight.w700)),
            Text(
              'q4_coffee_$key'.tr,
              textAlign: TextAlign.center,
              style: TextStyle(color: cupsOfCoffee == key ? Colors.white : kAppColor, fontSize: 15, fontWeight: FontWeight.w500),
            ),
          ],
        ),
        decoration: BoxDecoration(
            color: cupsOfCoffee == key ? kAppColor.withAlpha(200) : Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: cupsOfCoffee == key
                ? null
                : Border.all(
                    color: kAppColor.withAlpha(200),
                    width: 3,
                  )),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const SizedBox(height: 30),
        SizedBox(
          width: size.width * 0.8,
          child: Text('q4_slide_hdng'.tr, textAlign: TextAlign.center, style: kHeading2Style),
        ),
        const SizedBox(height: 5),
        SizedBox(
          width: size.width * 0.8,
          child: Text(coffeeErrTxt ?? 'q4_slide_info'.tr, textAlign: TextAlign.center, style: TextStyle(fontSize: 14, color: coffeeErrTxt == null ? kGrey : Colors.red)),
        ),
        const SizedBox(height: 10),
        NotificationListener<OverscrollIndicatorNotification>(
          onNotification: (OverscrollIndicatorNotification scrollEndNotification) {
            scrollEndNotification.disallowGlow();
            return true;
          },
          child: Expanded(
            child: SizedBox(
              width: size.width * 0.8,
              child: Directionality(
                textDirection: TextDirection.ltr,
                child: GridView(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 25, crossAxisSpacing: 25),
                  children: Questionnaire.coffeeOptions.keys.map((key) => getOption(key)).toList(),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
