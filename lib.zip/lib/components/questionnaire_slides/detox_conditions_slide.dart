import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../constants.dart';

// ignore: must_be_immutable
class DetoxConditionsSlide extends StatefulWidget {
  DetoxConditionsSlide(
      {required this.notPregnant,
      required this.notBFeeding,
      required this.noChemo,
      required this.noInflame,
      required this.responsibility,
      required this.isFemale,
      required this.notPregnantCallback,
      required this.notBFeedingCallback,
      required this.noChemoCallback,
      required this.noInflameCallback,
      required this.responsibilityCallback,
      Key? key})
      : super(key: key);

  bool notPregnant;
  bool notBFeeding;
  bool noChemo;
  bool noInflame;
  bool responsibility;
  final bool? isFemale;
  final Function notPregnantCallback;
  final Function notBFeedingCallback;
  final Function noChemoCallback;
  final Function noInflameCallback;
  final Function responsibilityCallback;

  @override
  _DetoxConditionsSlideState createState() => _DetoxConditionsSlideState();
}

class _DetoxConditionsSlideState extends State<DetoxConditionsSlide> {
  final TextStyle optionStyle = const TextStyle(fontSize: 15, color: Colors.black, fontWeight: FontWeight.w500);
  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const SizedBox(height: 30),
        SizedBox(
          width: size.width * 0.8,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'q2_slide_hdng'.tr,
                softWrap: true,
                style: kHeading2Style,
              ),
              Text(
                'q2_slide_info_txt'.tr,
                style: const TextStyle(fontSize: 14, color: Colors.grey),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        if (widget.isFemale!)
          CheckboxListTile(
              controlAffinity: ListTileControlAffinity.leading,
              activeColor: kAppColor.withOpacity(0.8),
              title: Text(
                'q2_slide_not_preg'.tr,
                style: optionStyle,
              ),
              value: widget.notPregnant,
              onChanged: (val) => setState(() {
                    widget.notPregnant = val ?? false;
                    widget.notPregnantCallback(val);
                  })),
        if (widget.isFemale!)
          CheckboxListTile(
              controlAffinity: ListTileControlAffinity.leading,
              activeColor: kAppColor.withOpacity(0.8),
              title: Text(
                'q2_slide_not_bFeed'.tr,
                style: optionStyle,
              ),
              value: widget.notBFeeding,
              onChanged: (val) => setState(() {
                    widget.notBFeeding = val ?? false;
                    widget.notBFeedingCallback(val);
                  })),
        CheckboxListTile(
            controlAffinity: ListTileControlAffinity.leading,
            activeColor: kAppColor.withOpacity(0.8),
            title: Text(
              'q2_slide_not_chemo'.tr,
              style: optionStyle,
            ),
            value: widget.noChemo,
            onChanged: (val) => setState(() {
                  widget.noChemo = val ?? false;
                  widget.noChemoCallback(val);
                })),
        CheckboxListTile(
            controlAffinity: ListTileControlAffinity.leading,
            activeColor: kAppColor.withOpacity(0.8),
            title: Text(
              'q2_slide_no_inFlame'.tr,
              style: optionStyle,
            ),
            value: widget.noInflame,
            onChanged: (val) => setState(() {
                  widget.noInflame = val ?? false;
                  widget.noInflameCallback(val);
                })),
        CheckboxListTile(
            controlAffinity: ListTileControlAffinity.leading,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            activeColor: kAppColor.withOpacity(0.8),
            title: Text(
              'q2_slide_responsibility'.tr,
              style: optionStyle,
            ),
            value: widget.responsibility,
            onChanged: (val) => setState(() {
                  widget.responsibility = val ?? false;
                  widget.responsibilityCallback(val);
                })),
      ],
    );
  }
}
