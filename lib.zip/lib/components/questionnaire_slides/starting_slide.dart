import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../components/main_button.dart';
import '../../constants.dart';

class StartingSlide extends StatelessWidget {
  const StartingSlide({required this.pageController, Key? key}) : super(key: key);
  final PageController pageController;

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Column(
      children: [
        const SizedBox(height: 10),
        Hero(
          tag: 'Logo',
          child: Image.asset(
            '$assets/detox_logo.png',
            height: 200,
            width: 200,
          ),
        ),
        const SizedBox(height: 15),
        SizedBox(
          width: size.width * 0.8,
          child: Text(
            'strtng_slde_hdng'.tr,
            textAlign: TextAlign.center,
            style: kBodyStyle.copyWith(color: kAppColor),
          ),
        ),
        const SizedBox(height: 15),
        SizedBox(
          width: size.width * 0.8,
          child: Text(
            'strtng_slde_hdng2'.tr,
            textAlign: TextAlign.center,
            style: kBodyStyle,
          ),
        ),
        const SizedBox(height: 40),
        MainButton(
            width: 150,
            title: 'strtng_slde_btn'.tr,
            onTap: () {
              pageController.nextPage(duration: slideDuration, curve: slideCurve);
            }),
      ],
    );
  }
}
