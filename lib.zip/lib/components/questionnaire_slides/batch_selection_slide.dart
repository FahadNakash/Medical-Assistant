import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../components/batch_card.dart';
import '../../constants.dart';
import '../../models/batch_model.dart';
import '../../services/firestore_helper.dart';

class BatchSelectionSlide extends StatelessWidget {
  const BatchSelectionSlide({required this.onTap, required this.errorText, required this.prepDays, Key? key}) : super(key: key);
  final String? errorText;
  final Function onTap;
  final int? prepDays;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirestoreHelper.batchesRef.snapshots().distinct(),
      builder: (context, snapshot) {
        List<Batch> batchesList = [];
        if (snapshot.hasData) {
          for (var element in snapshot.data?.docs ?? []) {
            Batch batch = Batch.fromMap(element.data() as Map<String, dynamic>);
            if (!batch.isStarted && batch.startingDate.subtract(Duration(days: prepDays!)).isAfter(DateTime.now())) {
              batchesList.add(batch);
            }
          }
        }
        batchesList.sort((Batch a, Batch b) => a.startingDate.compareTo(b.startingDate));
        return batchesList.isNotEmpty
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 15, right: 15, top: 25, bottom: 5),
                    child: Text(
                      'batch_slct_slde_hdng'.tr,
                      style: kHeading2Style.copyWith(color: kDarkBlue),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 15, right: 15, bottom: 15),
                    child: Text(
                      errorText == null ? 'batch_slct_slde_info_txt'.tr : errorText!,
                      style: kLabelStyle.copyWith(color: errorText == null ? kDarkGrey : Colors.red),
                    ),
                  ),
                  Flexible(
                    child: NotificationListener<OverscrollIndicatorNotification>(
                      onNotification: (notification) {
                        notification.disallowGlow();
                        return true;
                      },
                      child: ListView.builder(
                          itemCount: batchesList.length,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: () => onTap(batchesList[index]),
                              child: BatchCard(batchesList[index]),
                            );
                          }),
                    ),
                  ),
                ],
              )
            : Center(
                child: Container(
                  padding: const EdgeInsets.all(15),
                  margin: const EdgeInsets.only(bottom: 100),
                  decoration: BoxDecoration(
                    color: kAppColor.withAlpha(20),
                    borderRadius: kFocusedBorderRadius,
                  ),
                  child: Text(
                    'batch_slct_slde_err_txt'.tr,
                    style: kUnselectedTextStyle,
                    textAlign: TextAlign.center,
                  ),
                ),
              );
      },
    );
  }
}
