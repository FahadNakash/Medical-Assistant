import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../constants.dart';

class DetoxPurposeSlide extends StatelessWidget {
  const DetoxPurposeSlide({required this.data, required this.errorText, required this.onTap, Key? key}) : super(key: key);
  final List data;
  final Function onTap;
  final String? errorText;

  Widget getOption(String option, String key) {
    return GestureDetector(
      onTap: () => onTap(option),
      child: Container(
        height: 40,
        width: 185,
        margin: const EdgeInsets.only(bottom: 15),
        alignment: Alignment.center,
        decoration: data.contains(option) ? kSelectedBoxDecoration : kUnselectedBoxDecoration,
        child: Text(
          key.tr,
          style: data.contains(option) ? kSelectedTextStyle : kUnselectedTextStyle,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const SizedBox(height: 30),
        SizedBox(
          width: size.width * 0.8,
          child: Text(
            'q3_slide_q'.tr,
            textAlign: TextAlign.center,
            style: kHeading2Style,
          ),
        ),
        const SizedBox(height: 5),
        SizedBox(
          width: size.width * 0.8,
          child: Text(errorText ?? 'q3_slide_info_txt'.tr, textAlign: TextAlign.center, style: TextStyle(fontSize: 14, color: errorText == null ? kGrey : Colors.red)),
        ),
        const SizedBox(height: 25),
        getOption('Blood Pressure', 'blood_pressure'),
        getOption('Cholesterol', 'cholesterol'),
        getOption('Diabetes', 'diabetes'),
        getOption('Weight Loss', 'weight_loss'),
        getOption('Fertility/Family Planning', 'family_planning'),
        getOption('Lifestyle', 'lifestyle'),
      ],
    );
  }
}
