import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:numberpicker/numberpicker.dart';

import '../../components/custom_text_field.dart';
import '../../constants.dart';
import '../profile_selector.dart';

// ignore: must_be_immutable
class PersonalDetailsSlide extends StatefulWidget {
  PersonalDetailsSlide({
    required this.fName,
    required this.fNameErrorText,
    required this.fNameCallback,
    required this.lName,
    required this.lNameErrorText,
    required this.lNameCallback,
    required this.maximumDate,
    required this.dobErrorText,
    required this.dobCallback,
    required this.height,
    required this.heightErrorText,
    required this.heightCallback,
    required this.weight,
    required this.weightErrorText,
    required this.weightCallback,
    required this.isMetric,
    required this.isMetricCallback,
    required this.isFemale,
    required this.isFemaleErrTxt,
    required this.isFemaleCallback,
    required this.fillLater,
    required this.fillLaterCallback,
    required this.image,
    required this.onImgSelect,
    Key? key,
  }) : super(key: key);

  final String fName;
  final String? fNameErrorText;
  final Function(String) fNameCallback;
  final String lName;
  final String? lNameErrorText;
  final Function(String) lNameCallback;
  final DateTime maximumDate;
  final String? dobErrorText;
  final Function(DateTime) dobCallback;
  num? height;
  final String? heightErrorText;
  final Function heightCallback;
  num? weight;
  final String? weightErrorText;
  final Function weightCallback;
  bool isMetric;
  final Function isMetricCallback;
  bool? isFemale;
  final String? isFemaleErrTxt;
  final Function isFemaleCallback;
  bool fillLater;
  final Function fillLaterCallback;
  final File? image;
  final VoidCallback onImgSelect;

  @override
  _PersonalDetailsSlideState createState() => _PersonalDetailsSlideState();
}

class _PersonalDetailsSlideState extends State<PersonalDetailsSlide> {
  final TextStyle unselectedStyle = const TextStyle(fontSize: 16, color: Colors.black54);
  final TextStyle selectedStyle = const TextStyle(fontSize: 17, color: Colors.white, fontWeight: FontWeight.w600);

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final String locale = Get.locale!.languageCode + '_' + Get.locale!.countryCode!;
    return NotificationListener<OverscrollIndicatorNotification>(
      onNotification: (OverscrollIndicatorNotification scrollEndNotification) {
        scrollEndNotification.disallowGlow();
        return true;
      },
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 30),
            SizedBox(
              width: size.width * 0.8,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'q1_slide_hdng'.tr,
                    style: kHeading2Style,
                  ),
                  Text(
                    'q1_slide_info_txt'.tr,
                    style: const TextStyle(fontSize: 14, color: kGrey),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            ProfileSelector(
              image: widget.image,
              onSelect: widget.onImgSelect,
            ),
            const SizedBox(height: 10),
            Container(
              height: 35,
              width: 180,
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () {
                        setState(() {
                          widget.isFemale = false;
                          widget.isFemaleCallback(false);
                        });
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: widget.isFemale == null
                              ? Colors.white
                              : !widget.isFemale!
                                  ? kAppColor.withAlpha(220)
                                  : Colors.white,
                          borderRadius: locale == kEnglishLocale ? const BorderRadius.only(topLeft: Radius.circular(25), bottomLeft: Radius.circular(25)) : const BorderRadius.only(topRight: Radius.circular(25), bottomRight: Radius.circular(25)),
                        ),
                        alignment: Alignment.center,
                        child: Text('male'.tr,
                            style: widget.isFemale == null
                                ? unselectedStyle
                                : !widget.isFemale!
                                    ? selectedStyle
                                    : unselectedStyle),
                      ),
                    ),
                  ),
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () {
                        setState(() {
                          widget.isFemale = true;
                          widget.isFemaleCallback(true);
                        });
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: widget.isFemale == null
                              ? Colors.white
                              : widget.isFemale!
                                  ? kAppColor.withAlpha(220)
                                  : Colors.white,
                          borderRadius: locale == kEnglishLocale ? const BorderRadius.only(topRight: Radius.circular(25), bottomRight: Radius.circular(25)) : const BorderRadius.only(topLeft: Radius.circular(25), bottomLeft: Radius.circular(25)),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'female'.tr,
                          style: widget.isFemale == null
                              ? unselectedStyle
                              : !widget.isFemale!
                                  ? unselectedStyle
                                  : selectedStyle,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                border: Border.all(
                  color: widget.isFemaleErrTxt == null ? kAppColor.withAlpha(220) : Colors.red,
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              height: 15,
              alignment: Alignment.topCenter,
              width: size.width * 0.8,
              child: Text(
                widget.isFemaleErrTxt ?? '',
                style: const TextStyle(height: 1.3, color: Colors.red, fontSize: 10),
              ),
            ),
            CustomTextField(
              width: size.width * 0.8,
              height: 45,
              initialValue: widget.fName,
              textInputAction: TextInputAction.done,
              onChanged: widget.fNameCallback,
              onEditingComplete: () {
                FocusScope.of(context).unfocus();
              },
              labelText: 'f_name'.tr,
              isError: widget.fNameErrorText != null,
              contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              height: 15,
              width: size.width * 0.8,
              child: Text(
                widget.fNameErrorText ?? '',
                style: const TextStyle(height: 1.3, color: Colors.red, fontSize: 10),
              ),
            ),
            CustomTextField(
              width: size.width * 0.8,
              height: 45,
              initialValue: widget.lName,
              textInputAction: TextInputAction.done,
              onChanged: widget.lNameCallback,
              onEditingComplete: () {
                FocusScope.of(context).unfocus();
              },
              labelText: 'l_name'.tr,
              isError: widget.lNameErrorText != null,
              contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              height: 15,
              width: size.width * 0.8,
              child: Text(
                widget.lNameErrorText ?? '',
                style: const TextStyle(height: 1.3, color: Colors.red, fontSize: 10),
              ),
            ),
            SizedBox(
              width: size.width * 0.8,
              height: 15,
              child: Text(
                'q1_slide_dob'.tr,
                style: kPropertyStyle,
              ),
            ),
            Container(
              height: 100,
              width: size.width * 0.8,
              margin: const EdgeInsets.only(top: 5),
              decoration: BoxDecoration(
                color: widget.dobErrorText == null ? kAppColor.withAlpha(20) : Colors.red.shade50,
                borderRadius: kFocusedBorderRadius,
              ),
              child: CupertinoDatePicker(
                initialDateTime: widget.maximumDate,
                mode: CupertinoDatePickerMode.date,
                onDateTimeChanged: widget.dobCallback,
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              height: 15,
              width: size.width * 0.8,
              child: Text(
                widget.dobErrorText ?? '',
                style: const TextStyle(height: 1.3, color: Colors.red, fontSize: 10),
              ),
            ),
            Container(
              height: 35,
              width: 180,
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () {
                        setState(() {
                          widget.isMetric = true;
                          widget.isMetricCallback(true);
                        });
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: widget.isMetric ? kAppColor.withAlpha(220) : Colors.white,
                          borderRadius: locale == kEnglishLocale ? const BorderRadius.only(topLeft: Radius.circular(25), bottomLeft: Radius.circular(25)) : const BorderRadius.only(topRight: Radius.circular(25), bottomRight: Radius.circular(25)),
                        ),
                        alignment: Alignment.center,
                        child: Text('metric'.tr, style: widget.isMetric ? selectedStyle : unselectedStyle),
                      ),
                    ),
                  ),
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () {
                        setState(() {
                          widget.isMetric = false;
                          widget.isMetricCallback(false);
                        });
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: !widget.isMetric ? kAppColor.withAlpha(220) : Colors.white,
                          borderRadius: locale == kEnglishLocale ? const BorderRadius.only(topRight: Radius.circular(25), bottomRight: Radius.circular(25)) : const BorderRadius.only(topLeft: Radius.circular(25), bottomLeft: Radius.circular(25)),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'imperial'.tr,
                          style: widget.isMetric ? unselectedStyle : selectedStyle,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                border: Border.all(
                  color: kAppColor.withAlpha(220),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Checkbox(
                    fillColor: MaterialStateColor.resolveWith((states) => kAppColor.withOpacity(0.8)),
                    value: widget.fillLater,
                    onChanged: (val) {
                      setState(() {
                        widget.fillLater = val ?? false;
                        widget.fillLaterCallback(val);
                        if (widget.fillLater) {
                          widget.heightCallback(null);
                          widget.weightCallback(null);
                        } else {
                          widget.heightCallback(widget.height);
                          widget.weightCallback(widget.weight);
                        }
                      });
                    }),
                Text(
                  'q1_slide_info_txt2'.tr,
                  style: const TextStyle(fontSize: 16, color: kDarkGrey),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Column(
                          children: [
                            Text(
                              'q1_slide_height'.tr,
                              style: kPropertyStyle,
                            ),
                            const SizedBox(height: 5),
                            Container(
                              width: 70,
                              margin: const EdgeInsets.symmetric(horizontal: 5),
                              decoration: BoxDecoration(
                                color: widget.heightErrorText != null ? Colors.red.shade50 : const Color(0xffF5F6EC),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  Container(
                                    height: 35,
                                    width: 60,
                                    decoration: BoxDecoration(
                                      color: widget.heightErrorText != null ? const Color(0xffEFDDE1) : const Color(0xffE6E7DF),
                                      borderRadius: BorderRadius.circular(7),
                                    ),
                                  ),
                                  NumberPicker(
                                    value: widget.height?.toInt() ?? 60,
                                    minValue: 0,
                                    maxValue: 999,
                                    textStyle: const TextStyle(color: Colors.grey, fontWeight: FontWeight.w500, fontSize: 23),
                                    selectedTextStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.w500, fontSize: 25),
                                    onChanged: (val) => setState(() {
                                      widget.height = val;
                                      if (!widget.fillLater) {
                                        widget.heightCallback(val);
                                      }
                                    }),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        Container(width: 30, alignment: Alignment.bottomLeft, height: 40, child: Text(widget.isMetric ? 'cm'.tr : 'inch'.tr, style: const TextStyle(fontWeight: FontWeight.w600))),
                      ],
                    ),
                    const SizedBox(height: 5),
                    SizedBox(
                      height: 15,
                      child: Text(
                        widget.heightErrorText ?? '',
                        style: const TextStyle(height: 1.3, color: Colors.red, fontSize: 10),
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Column(
                          children: [
                            Text('q1_slide_weight'.tr, style: kPropertyStyle),
                            const SizedBox(height: 5),
                            Container(
                              width: 70,
                              margin: const EdgeInsets.symmetric(horizontal: 5),
                              decoration: BoxDecoration(
                                color: widget.weightErrorText != null ? Colors.red.shade50 : const Color(0xffF5F6EC),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  Container(
                                    height: 35,
                                    width: 60,
                                    decoration: BoxDecoration(
                                      color: widget.weightErrorText != null ? const Color(0xffEFDDE1) : const Color(0xffE6E7DF),
                                      borderRadius: BorderRadius.circular(7),
                                    ),
                                  ),
                                  NumberPicker(
                                    value: widget.weight?.toInt() ?? 60,
                                    minValue: 0,
                                    maxValue: 999,
                                    textStyle: const TextStyle(color: Colors.grey, fontWeight: FontWeight.w500, fontSize: 23),
                                    selectedTextStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.w500, fontSize: 25),
                                    onChanged: (val) => setState(() {
                                      widget.weight = val;
                                      if (!widget.fillLater) {
                                        widget.weightCallback(val);
                                      }
                                    }),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        Container(width: 30, alignment: Alignment.bottomLeft, height: 40, child: Text(widget.isMetric ? 'kg'.tr : 'lbs'.tr, style: const TextStyle(fontWeight: FontWeight.w600))),
                      ],
                    ),
                    const SizedBox(height: 5),
                    SizedBox(
                      height: 15,
                      child: Text(
                        widget.weightErrorText ?? '',
                        style: const TextStyle(height: 1.3, color: Colors.red, fontSize: 10),
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
