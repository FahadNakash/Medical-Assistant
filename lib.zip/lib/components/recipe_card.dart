import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:transparent_image/transparent_image.dart';

import '../constants.dart';
import '../controller/app_state_controller.dart';
import '../models/recipe_model.dart';
import '../screens/view_recipe_screen.dart';
import '../services/storage_helper.dart';

class RecipeCard extends StatefulWidget {
  const RecipeCard(this.recipe, {Key? key}) : super(key: key);
  final Recipe recipe;

  @override
  _RecipeCardState createState() => _RecipeCardState();
}

class _RecipeCardState extends State<RecipeCard> {
  File? recipeImage;

  @override
  void initState() {
    getRecipeImage(context);
    super.initState();
  }

  Future<void> getRecipeImage(BuildContext context) async {
    File? temp = await StorageHelper.checkImageIsPresent(imageName: widget.recipe.imgName, url: widget.recipe.imgUrl);
    recipeImage = temp;
    if (mounted) {
      setState(() {});
      if (temp != null) {
        precacheImage(FileImage(temp), context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => ViewRecipeScreen(
                  recipe: widget.recipe,
                  recipeImage: recipeImage,
                )));
      },
      child: Container(
        margin: const EdgeInsets.only(top: 10),
        height: 80,
        color: Colors.white,
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GetBuilder(builder: (AppStateController controller) {
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 5),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black26,
                          offset: Offset(0, 2),
                          blurRadius: 4,
                        )
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Container(
                        height: 60,
                        width: 60,
                        alignment: Alignment.center,
                        color: Colors.white,
                        child: recipeImage != null
                            ? FadeInImage(
                                placeholder: MemoryImage(kTransparentImage),
                                image: FileImage(recipeImage!),
                                fadeInDuration: const Duration(milliseconds: 500),
                                fit: BoxFit.fill,
                              )
                            : SvgPicture.asset('$assets/icon-recipes.svg', height: 45, width: 55, color: kAppColor.withAlpha(100)),
                      ),
                    ),
                  );
                }),
                Expanded(
                  child: Container(
                    height: 75,
                    padding: const EdgeInsets.only(top: 5, left: 5, right: 5),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Flexible(
                          child: Text(
                            widget.recipe.title,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: kAppColor,
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        Flexible(
                          child: Text(
                            'ingredients'.tr + widget.recipe.ingredients.toString().replaceAll('[', '').replaceAll(']', ''),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 2,
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: kDarkGrey),
                          ),
                        ),
                        Divider(
                          height: 5,
                          color: kAppColor.withAlpha(200),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
