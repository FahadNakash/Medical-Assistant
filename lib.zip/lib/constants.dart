import 'package:flutter/material.dart';

//    Settings
const Duration slideDuration = Duration(milliseconds: 300);
const Curve slideCurve = Curves.linear;
const String assets = 'assets/images';
const String kEnglishLocale = 'en_US';
const String kHebrewLocale = 'he_IL';
const String kAppEmail = 'regeneration.today.dror@gmail.com';
const String diabetes = 'Diabetes';
const String weightLoss = 'Weight Loss';
const String kForumId = 'generalForum';

//    Paddings
const EdgeInsets kRecipeMargin = EdgeInsets.symmetric(vertical: 8, horizontal: 4);
const EdgeInsets kRecipePadding = EdgeInsets.symmetric(vertical: 10, horizontal: 15);

//    Colors
const Color kAppColor = Color(0xff7b8610);
const Color kGrey = Color(0xffAEB6C1);
const Color kDarkGrey = Color(0xff5A5A5A);
const Color kDarkBlue = Color(0xff2C385B);
const List<Color> kColors = [
  Color(0xfffe9c8f),
  Color(0xfffeb2a8),
  Color(0xfffec8c1),
  Color(0xfffad9c1),
  Color(0xfff9caa7),
  Color(0xffd2d4dc),
  Color(0xffafafaf),
  Color(0xfff8f8fa),
  Color(0xffe5e6eb),
  Color(0xffc0c2ce),
  Color(0xffa8e6cf),
  Color(0xffdcedc1),
  Color(0xffffd3b6),
  Color(0xffffaaa5),
  Color(0xffff8b94),
];
//    TextStyles
const TextStyle kHeading1Style = TextStyle(fontFamily: 'Trajan', color: kAppColor, fontSize: 38, letterSpacing: 1.2);
const TextStyle kHeading2Style = TextStyle(fontWeight: FontWeight.w600, color: Colors.black, fontSize: 22);
const TextStyle kBodyStyle = TextStyle(fontSize: 19, color: Colors.black);
const TextStyle kAppBarAppNameStyle = TextStyle(color: Colors.white, fontSize: 25, fontFamily: 'Trajan', fontWeight: FontWeight.w600);
const TextStyle kIndicatorStyle = TextStyle(fontSize: 17, color: kDarkBlue, fontFamily: 'Trajan', fontWeight: FontWeight.w700);
const TextStyle kUnselectedTextStyle = TextStyle(color: kAppColor, fontSize: 16);
const TextStyle kSelectedTextStyle = TextStyle(color: Colors.white, fontSize: 16);
final TextStyle kTextActionStyle = TextStyle(fontSize: 14, color: kAppColor.withAlpha(200), fontFamily: 'Comfortaa', fontWeight: FontWeight.w600);
const TextStyle kHintStyle = TextStyle(fontSize: 15, height: 1.2, color: kDarkGrey);
const TextStyle kLabelStyle = TextStyle(color: kDarkGrey, fontSize: 15, height: 1.2);
const TextStyle kErrorStyle = TextStyle(height: 0.08, color: Colors.red, fontSize: 10);
const TextStyle kCardBodyStyle = TextStyle(fontSize: 14, color: kDarkBlue);
const TextStyle kPropertyStyle = TextStyle(color: Colors.black87, fontSize: 17, fontWeight: FontWeight.w600);
const TextStyle kPostBodyStyle = TextStyle(color: Colors.black, fontFamily: 'Poppins', fontSize: 15, fontWeight: FontWeight.w400);
const TextStyle kPostNameStyle = TextStyle(color: Colors.black, fontFamily: 'Poppins', fontSize: 14, fontWeight: FontWeight.w600);

//    BorderRadius
final BorderRadius kFocusedBorderRadius = BorderRadius.circular(10);
final BorderRadius kEnabledBorderRadius = BorderRadius.circular(25);
const BorderRadius kTLRBorderRadius = BorderRadius.only(topRight: Radius.circular(25), topLeft: Radius.circular(25));
const BorderRadius kBLRBorderRadius = BorderRadius.only(bottomRight: Radius.circular(25), bottomLeft: Radius.circular(25));

//    BoxShadow
final BoxShadow kTextFieldShadow = BoxShadow(color: kAppColor.withAlpha(100), offset: const Offset(0, 3), blurRadius: 6);

//    BoxDecoration
final BoxDecoration kOutlineContainerDecoration = BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(5), border: Border.all(color: kAppColor, width: 0.7));
final BoxDecoration kUnselectedBoxDecoration = BoxDecoration(
  color: Colors.white,
  border: Border.all(color: kAppColor, width: 1),
  borderRadius: kEnabledBorderRadius,
);
final BoxDecoration kSelectedBoxDecoration = BoxDecoration(
  color: kAppColor.withAlpha(200),
  borderRadius: kEnabledBorderRadius,
  border: Border.all(color: Colors.transparent, width: 1),
  boxShadow: <BoxShadow>[kTextFieldShadow],
);

final BoxDecoration pinSelectedDecoration = BoxDecoration(
  color: Colors.white,
  borderRadius: BorderRadius.circular(20),
  border: Border.all(
    color: kAppColor.withAlpha(200),
    width: 2,
  ),
);
final BoxDecoration pinFollowingDecoration = BoxDecoration(
  color: Colors.white,
  borderRadius: BorderRadius.circular(15),
  border: Border.all(
    color: kAppColor.withAlpha(150),
    width: 1.5,
  ),
);
