import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../constants.dart';
import '../models/method_practice_model.dart';
import '../models/recipe_model.dart';
import '../models/shopping_item_model.dart';
import '../models/user_model.dart';

class Preferences {
  static late SharedPreferences _preferences;
  static const String _session = 'user';
  static const String _watchedVideos = 'watched_videos';
  static const String _initMethods = 'init_methods';
  static const String _initPractices = 'init_practices';
  static const String _initRecipes = 'init_recipes';
  static const String _shoppingList = 'shopping_list';
  static const String _showAnnouncement = 'show_announcement';
  static const String _locale = 'locale';

  static Future<void> init() async {
    _preferences = await SharedPreferences.getInstance();
  }

  static Locale fetchAppLocale() {
    List locale = (_preferences.getString(_locale) ?? kEnglishLocale).split('_');
    return Locale(locale[0], locale[1]);
  }

  static String getAppLocale() {
    return _preferences.getString(_locale) ?? kEnglishLocale;
  }

  static Future<void> saveAppLocale(String locale) async {
    await _preferences.setString(_locale, locale);
  }

  /// saves User session
  static Future<void> saveUserSession(UserModel user) async {
    await _preferences.setString(_session, jsonEncode(user.toMap()));
  }

  /// returns a UserModel object or null if there is no session saved
  static UserModel? loadUserSession() {
    String? encodedString = _preferences.getString(_session);
    return encodedString != null ? UserModel.fromMap(jsonDecode(encodedString)) : null;
  }

  /// deletes the current user's session from storage
  static Future<void> deleteUserSession() async {
    await _preferences.remove(_session);
    await _preferences.remove(_watchedVideos);
    await _preferences.remove(_initMethods);
    await _preferences.remove(_initPractices);
    await _preferences.remove(_initRecipes);
    await _preferences.remove(_showAnnouncement);
    await _preferences.remove(_locale);
  }

  /// saves the given list of watched videos
  static Future<void> saveWatchedVideos(List<String> videos) async {
    await _preferences.setStringList(_watchedVideos, videos);
  }

  /// return's the list of watched Videos
  static List<String> getWatchedVideos() {
    return _preferences.getStringList(_watchedVideos) ?? [];
  }

  /// saves the init methods list in persistent storage
  static Future<void> saveInitMethods(List<MethodPractice> methods) async {
    List<Map<String, dynamic>> temp = [];
    for (var element in methods) {
      temp.add(element.toMap());
    }
    await _preferences.setString(_initMethods, jsonEncode(temp));
  }

  /// gets the init methods list from persistent storage
  static List<MethodPractice> getInitMethods() {
    List<MethodPractice> methods = [];
    String? dataString = _preferences.getString(_initMethods);
    if (dataString != null) {
      List<dynamic> temp = jsonDecode(dataString);
      for (var element in temp) {
        methods.add(MethodPractice.fromMap(element));
      }
    }
    return methods;
  }

  /// saves the init practices list in persistent storage
  static Future<void> saveInitPractices(List<MethodPractice> practices) async {
    List<Map<String, dynamic>> temp = [];
    for (var element in practices) {
      temp.add(element.toMap());
    }
    await _preferences.setString(_initPractices, jsonEncode(temp));
  }

  /// gets the init practices list from persistent storage
  static List<MethodPractice> getInitPractices() {
    List<MethodPractice> practices = [];
    String? dataString = _preferences.getString(_initPractices);
    if (dataString != null) {
      List<dynamic> temp = jsonDecode(dataString);
      for (var element in temp) {
        practices.add(MethodPractice.fromMap(element));
      }
    }
    return practices;
  }

  /// saves the init recipes list in persistent storage
  static Future<void> saveInitRecipes(List<Recipe> recipes) async {
    List<Map<String, dynamic>> temp = [];
    for (var element in recipes) {
      temp.add(element.toMap());
    }
    await _preferences.setString(_initRecipes, jsonEncode(temp));
  }

  /// gets the init recipes list from persistent storage
  static List<Recipe> getInitRecipes() {
    List<Recipe> recipes = [];
    String? dataString = _preferences.getString(_initRecipes);
    if (dataString != null) {
      List<dynamic> temp = jsonDecode(dataString);
      for (var element in temp) {
        recipes.add(Recipe.fromMap(element));
      }
    }
    return recipes;
  }

  /// saves the shopping items list in persistent storage
  static Future<void> saveShoppingList(List<ShoppingItem> shoppingItem) async {
    List<Map<String, dynamic>> temp = [];
    for (var element in shoppingItem) {
      temp.add(element.toMap());
    }
    await _preferences.setString(_shoppingList, jsonEncode(temp));
  }

  /// gets the shopping items list from persistent storage
  static List<ShoppingItem> getShoppingList() {
    List<ShoppingItem> shoppingList = [];
    String? dataString = _preferences.getString(_shoppingList);
    if (dataString != null) {
      List<dynamic> temp = jsonDecode(dataString);
      for (var element in temp) {
        shoppingList.add(ShoppingItem.fromMap(element));
      }
    }
    return shoppingList;
  }

  static Future<bool> showAnnouncements() async {
    String now = DateTime.now().toString().split(' ')[0];
    String? date = _preferences.getString(_showAnnouncement);
    bool showAnnouncements;
    if (now == date) {
      showAnnouncements = false;
    } else {
      showAnnouncements = true;
      await _preferences.setString(_showAnnouncement, now);
    }
    return showAnnouncements;
  }
}
